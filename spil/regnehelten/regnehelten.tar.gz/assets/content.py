"""
Matematikindholdet. Hver opgave er pakket ind i en situation fra en helt
almindelig skoledag – og hver opgave har sin egen minispilstype, så man
ikke bare skriver i en kasse hver gang.

Blooms taksonomi styrer rækkefølgen:
HUSK -> FORSTÅ -> ANVEND -> ANALYSÉR -> VURDÉR -> SKAB.

Hver opgave peger på en side i Regnebogen (feltet "book"), så hjælpen
slår op på det rigtige sted.
"""

import random
import re
from collections import Counter

TIERS = {
    "lille": {"lo": 1, "hi": 20, "tab": 5, "kr": 50},
    "mellem": {"lo": 2, "hi": 100, "tab": 10, "kr": 200},
    "stor": {"lo": 5, "hi": 1000, "tab": 12, "kr": 500},
}


def tier_for_age(age):
    if age <= 8:
        return "lille"
    if age <= 10:
        return "mellem"
    return "stor"


def check_numeric(user, answer):
    """Tilgivende talkontrol: 12, 12,5, 12.5, 1.234 og '45 kr' virker alle."""
    raw = str(user).strip().lower().replace("kr", "")
    raw = re.sub(r"[^0-9.,\-]", "", raw)
    if not raw or raw in ("-", ".", ","):
        return False
    for c in {raw.replace(".", "").replace(",", "."), raw.replace(",", "")}:
        try:
            if abs(float(c) - float(answer)) < 0.011:
                return True
        except ValueError:
            continue
    return False


def fmt(n):
    if float(n).is_integer():
        return str(int(n))
    return f"{n:.2f}".replace(".", ",").rstrip("0").rstrip(",")


# --- Kreative opgaver (SKAB) --------------------------------------------

ALLOWED_EXPR = re.compile(r"^[0-9+\-*/(). ]+$")


def make_creative(tier):
    for _ in range(400):
        if tier == "lille":
            nums = [random.randint(2, 9) for _ in range(2)]
            ops = [random.choice("+-")]
            min_ops, allowed = 1, "+-"
        elif tier == "mellem":
            nums = [random.randint(2, 9) for _ in range(3)]
            ops = [random.choice("+-*") for _ in range(2)]
            min_ops, allowed = 2, "+-*"
        else:
            nums = [random.randint(2, 9) for _ in range(random.choice([3, 4]))]
            ops = [random.choice("+-*/") for _ in range(len(nums) - 1)]
            min_ops, allowed = 2, "+-*/"
        expr = str(nums[0])
        for i, op in enumerate(ops):
            expr += op + str(nums[i + 1])
        try:
            val = eval(expr, {"__builtins__": {}}, {})
        except ZeroDivisionError:
            continue
        if not isinstance(val, (int, float)) or not float(val).is_integer() or val <= 0:
            continue
        if len(set(ops)) >= min_ops:
            return {"numbers": nums, "target": int(val), "min_ops": min_ops,
                    "allowed": allowed, "expr": expr}
    return {"numbers": [3, 4], "target": 7, "min_ops": 1, "allowed": "+-", "expr": "3+4"}


def check_creative(expr, puzzle):
    e = expr.strip().replace("x", "*").replace("X", "*").replace(":", "/").replace("÷", "/")
    e = e.replace(",", ".")
    if not e:
        return False, "Skriv et regnestykke først."
    if not ALLOWED_EXPR.match(e):
        return False, "Brug kun tal og + - x : ( )"
    used = [int(n) for n in re.findall(r"\d+", e)]
    if Counter(used) != Counter(puzzle["numbers"]):
        need = ", ".join(str(n) for n in puzzle["numbers"])
        return False, f"Du skal bruge hvert af tallene {need} præcis én gang."
    ops = [c for c in e if c in "+-*/"]
    if len(set(ops)) < puzzle["min_ops"]:
        return False, f"Brug mindst {puzzle['min_ops']} forskellige regnearter."
    try:
        val = eval(e, {"__builtins__": {}}, {})
    except ZeroDivisionError:
        return False, "Du kan ikke dividere med 0."
    except Exception:
        return False, "Det regnestykke kan jeg ikke regne ud. Prøv igen."
    if abs(val - puzzle["target"]) < 1e-6:
        return True, "Præcis!"
    return False, f"Det giver {fmt(val)} – vi skal ramme {puzzle['target']}."


# --- Byggeklodser til opgaver -------------------------------------------

def _write(speaker, q, answer, hint, unit="", book="plus"):
    return {"kind": "write", "speaker": speaker, "q": q, "answer": answer,
            "hint": hint, "unit": unit, "book": book}


def _choice(speaker, q, choices, answer, hint, book="plus"):
    return {"kind": "choice", "speaker": speaker, "q": q, "choices": choices,
            "answer": answer, "hint": hint, "book": book}


def _balance(speaker, q, a, op, answer, hint, book="gange"):
    target = a * answer if op == "x" else (a + answer if op == "+" else a - answer)
    return {"kind": "balance", "speaker": speaker, "q": q, "a": a, "op": op,
            "target": target, "answer": answer, "hint": hint, "book": book,
            "min": 0, "max": max(20, answer + 8), "start": max(1, answer // 2)}


def _sequence(speaker, q, seq, answer, hint, book="monstre"):
    return {"kind": "sequence", "speaker": speaker, "q": q, "seq": seq,
            "answer": answer, "hint": hint, "book": book}


def _truefalse(speaker, q, statement, is_true, hint, book="tjek"):
    return {"kind": "truefalse", "speaker": speaker, "q": q, "statement": statement,
            "is_true": is_true, "hint": hint, "book": book}


def _coins(speaker, q, target, hint, book="penge"):
    return {"kind": "coins", "speaker": speaker, "q": q, "target": target,
            "hint": hint, "book": book}


def _build(speaker, q, puzzle, hint, book="raekkefolge"):
    return {"kind": "build", "speaker": speaker, "q": q, "puzzle": puzzle,
            "hint": hint, "book": book}


def _expr_for(value):
    """Et tilfældigt regnestykke, der giver netop value."""
    forms = []
    if value > 1:
        a = random.randint(1, value - 1)
        forms.append(f"{a} + {value - a}")
    b = random.randint(1, 9)
    forms.append(f"{value + b} - {b}")
    divs = [d for d in range(2, 10) if value % d == 0 and 2 <= value // d <= 12]
    if divs:
        d = random.choice(divs)
        forms.append(f"{d} x {value // d}")
    return random.choice(forms)


def _findall(speaker, q, target, hint, n_correct=3, n_total=8, book="gange"):
    labels = set()
    tiles = []
    guard = 0
    while len([t for t in tiles if t[1] == target]) < n_correct and guard < 200:
        guard += 1
        lab = _expr_for(target)
        if lab not in labels:
            labels.add(lab)
            tiles.append((lab, target))
    while len(tiles) < n_total and guard < 400:
        guard += 1
        off = random.choice([-6, -4, -3, -2, -1, 1, 2, 3, 4, 6])
        v = target + off
        if v < 1:
            continue
        lab = _expr_for(v)
        if lab not in labels:
            labels.add(lab)
            tiles.append((lab, v))
    random.shuffle(tiles)
    return {"kind": "findall", "speaker": speaker, "q": q, "target": target,
            "tiles": tiles, "hint": hint, "book": book}


# --- 1. HUSK: morgen på værelset ----------------------------------------

def husk(tier):
    c = TIERS[tier]
    qs = []

    t = random.choice([7, 8])
    minutter = random.choice([15, 20, 25, 30])
    qs.append(_write("Dig selv",
                     f"Klokken er {t}:{60 - minutter:02d}, og bussen kører {t + 1}:00.\n"
                     f"Hvor mange minutter har jeg?",
                     minutter, f"Fra {60 - minutter} minutter over til den hele time.",
                     "min", "plus"))

    a, b = random.randint(c["lo"], c["hi"] // 2), random.randint(c["lo"], c["hi"] // 2)
    qs.append(_write("Dig selv",
                     f"Der ligger {a} kr i sparegrisen, og jeg får {b} kr i lommepenge i dag.\n"
                     f"Hvor meget har jeg så?",
                     a + b, "Læg de to beløb sammen.", "kr", "plus"))

    target = random.randint(3, c["tab"]) * random.randint(2, 4)
    qs.append(_findall("Dig selv",
                       f"På forsiden af hæftet har jeg kradset en masse regnestykker.\n"
                       f"Hvilke af dem giver {target}?",
                       target, "Regn dem ud én ad gangen, og vælg dem der passer."))

    per = random.randint(2, min(6, c["tab"]))
    dage = random.randint(3, 6)
    qs.append(_balance("Dig selv",
                       f"Der skal {per} stykker frugt i madpakken hver dag.\n"
                       f"Hvor mange dage rækker {per * dage} stykker til?",
                       per, "x", dage,
                       f"Hvor mange gange går {per} op i {per * dage}?", "gange"))

    total = random.randint(max(8, c["hi"] // 3), c["hi"])
    brugt = random.randint(2, max(3, total // 2))
    qs.append(_write("Dig selv",
                     f"Jeg havde {total} kr, men brugte {brugt} kr på en sodavand i går.\n"
                     f"Hvor meget er der tilbage?",
                     total - brugt, "Træk det brugte fra det, du havde.", "kr", "plus"))
    return qs


# --- 2. FORSTÅ: køkkenet med Mor ----------------------------------------

def forstaa(tier):
    qs = []

    hold = random.choice([6, 8, 10])
    ialt = hold + random.choice([4, 6, 8])
    qs.append(_write("Mor",
                     f"Der skal {ialt} boller i alt, men der er kun plads til {hold} i ovnen\n"
                     f"ad gangen. Hvor mange må vente til næste hold?",
                     ialt - hold, "Hvor mange bliver der tilovers, når ovnen er fuld?",
                     "stk", "plus"))

    plader = random.choice([2, 3, 4])
    pr_plade = random.choice([4, 6, 8])
    qs.append(_balance("Mor",
                       f"Vi sætter {plader} plader i ovnen og får {plader * pr_plade} boller ud.\n"
                       f"Hvor mange lå der på hver plade?",
                       plader, "x", pr_plade,
                       f"Del {plader * pr_plade} med {plader}.", "division"))

    dl = random.choice([4, 6, 8])
    qs.append(_write("Mor",
                     f"Opskriften siger {dl} dl mælk, men vi laver kun den halve portion.\n"
                     f"Hvor mange dl skal du hælde op?",
                     dl // 2, "Den halve portion betyder delt med 2.", "dl", "halve"))

    vg = random.choice([12, 16, 20, 24])
    qs.append(_write("Ida",
                     f"Vi deler posen lige over! Der er {vg} vingummier.\n"
                     f"Hvor mange får jeg så?",
                     vg // 2, "Lige over betyder delt i to lige store dele.", "stk", "halve"))

    minutter = random.choice([12, 15, 18])
    qs.append(_choice("Mor",
                      f"Bollerne skal have {minutter} minutter, og de kom ind for\n"
                      f"{minutter - 5} minutter siden. Hvad passer?",
                      ["De er færdige nu",
                       "De skal have 5 minutter mere",
                       f"De skal have {minutter} minutter mere",
                       f"De skal have {minutter + 5} minutter mere"], 1,
                      "Hvor meget mangler der, før tiden er gået?", "plus"))
    return qs


# --- 3. ANVEND: indkøb med Far ------------------------------------------

def anvend(tier):
    qs = []

    pris = random.choice([12, 14, 15, 18])
    antal = random.randint(3, 5)
    qs.append(_write("Far",
                     f"Æblerne koster {pris} kr for en pose, og vi tager {antal} poser.\n"
                     f"Hvad bliver det?",
                     pris * antal, f"{pris} kr gange {antal} poser.", "kr", "gange"))

    beloeb = random.choice([17, 23, 28, 34, 41])
    qs.append(_coins("Far",
                     f"Bollerne koster {beloeb} kr, og manden vil helst have det præcist.\n"
                     f"Vil du lægge pengene op?",
                     beloeb, "Start med de store mønter, og fyld op med de små."))

    total = pris * antal
    seddel = ((total // 50) + 1) * 50
    qs.append(_write("Far",
                     f"Jeg betaler med {seddel} kr, og varerne koster {total} kr.\n"
                     f"Hvor meget får vi tilbage?",
                     seddel - total, "Byttepenge = det du giver minus prisen.", "kr", "penge"))

    kg_pris = random.choice([20, 24, 30])
    kg = random.choice([2, 3])
    qs.append(_write("Far",
                     f"Kartoflerne koster {kg_pris} kr pr. kilo, og vi skal bruge {kg} kilo.\n"
                     f"Hvad koster det?",
                     kg_pris * kg, "Gang kiloprisen med antal kilo.", "kr", "gange"))

    stk_pris = random.choice([6, 8, 9])
    tilbud = stk_pris * 3 - random.choice([3, 4, 5])
    qs.append(_choice("Far",
                      f"Yoghurt koster {stk_pris} kr stykket, men der er tilbud:\n"
                      f"3 for {tilbud} kr. Hvad er billigst, hvis vi skal have 3?",
                      ["3 stykker enkeltvis", f"Tilbuddet: 3 for {tilbud} kr",
                       "Det koster det samme"], 1,
                      f"Regn {stk_pris} gange 3, og sammenlign med {tilbud}.", "penge"))
    return qs


# --- 4. ANALYSÉR: skolegården med Oskar ---------------------------------

def analyser(tier):
    qs = []

    start, step = random.randint(2, 6), random.randint(3, 7)
    seq = [start + i * step for i in range(5)]
    blank = random.choice([3, 4])
    answer = seq[blank]
    shown = list(seq)
    shown[blank] = None
    qs.append(_sequence("Oskar",
                        "Kig på fliserne – der står tal på dem hele vejen hen.\n"
                        "Hvilket tal mangler?",
                        shown, answer,
                        "Find ud af, hvor meget der lægges til hver gang."))

    maal = random.randint(2, 5)
    qs.append(_write("Oskar",
                     f"Vi scorede {maal} mål før pausen og dobbelt så mange efter.\n"
                     f"Hvor mange blev det i alt?",
                     maal * 3, "Find først anden halvleg, og læg så sammen.", "mål", "gange"))

    hold = random.choice([3, 4, 5])
    spillere = hold * random.randint(3, 5)
    qs.append(_write("Oskar",
                     f"Vi er {spillere} i klassen og skal deles i {hold} lige store hold.\n"
                     f"Hvor mange er der på hvert hold?",
                     spillere // hold, f"Del {spillere} med {hold}.", "stk", "division"))

    target = random.choice([12, 16, 18, 20, 24])
    qs.append(_findall("Oskar",
                       f"Se her – jeg har skrevet regnestykker over hele bordet.\n"
                       f"Find alle dem, der giver {target}.",
                       target, "Regn hvert stykke ud, og sammenlign med tallet."))

    raekker, pr = random.randint(3, 6), random.randint(4, 8)
    qs.append(_write("Oskar",
                     f"Der står {raekker} rækker med {pr} cykler i stativet.\n"
                     f"Hvis en hel række kører hjem, hvor mange står der så?",
                     raekker * pr - pr,
                     f"Regn {raekker} gange {pr}, og træk én række fra.", "stk", "gange"))
    return qs


# --- 5. VURDÉR: kantinen ------------------------------------------------

def vurder(tier):
    qs = []

    a, b = random.randint(4, 9), random.randint(4, 9)
    rigtigt = random.random() < 0.5
    vist = a * b if rigtigt else a * b + random.choice([-2, -1, 1, 2])
    qs.append(_truefalse("Oskar",
                         "Jeg har lavet lektier i frikvarteret. Er den her rigtig?",
                         f"{a} x {b} = {vist}", rigtigt,
                         f"Regn {a} gange {b} selv, og sammenlign."))

    x, y = random.randint(20, 90), random.randint(5, 19)
    qs.append(_write("Oskar",
                     f"Og her har jeg skrevet {x} - {y} = {(x - y) + random.choice([-2, -1, 1, 2])}.\n"
                     f"Den tror jeg ikke på. Hvad skal der stå?",
                     x - y, "Regn det selv, og sammenlign med det, der står.", "", "tjek"))

    pris_a = random.choice([12, 16])
    pris_b = round(pris_a / 4 * 6) + random.choice([-3, -2, 2, 3])
    qs.append(_choice("Emma",
                      f"I kiosken: 4 boller for {pris_a} kr, eller 6 boller for {pris_b} kr.\n"
                      f"Hvor er prisen pr. bolle lavest?",
                      [f"4 for {pris_a} kr", f"6 for {pris_b} kr", "De er lige gode"],
                      0 if pris_a / 4 < pris_b / 6 else 1,
                      "Regn ud, hvad ÉN bolle koster hvert sted.", "penge"))

    stykker, folk = random.choice([8, 12]), random.choice([2, 4])
    rigtigt2 = random.random() < 0.5
    vist2 = stykker // folk if rigtigt2 else stykker // folk + random.choice([-1, 1, 2])
    qs.append(_truefalse("Emma",
                         f"Pizzaen er skåret i {stykker} stykker, og vi er {folk}.\n"
                         f"Oskar siger, vi får {vist2} stykker hver. Passer det?",
                         f"{stykker} : {folk} = {vist2}", rigtigt2,
                         f"Del {stykker} ligeligt mellem {folk}, og se efter."))

    target = random.choice([14, 18, 21, 27])
    qs.append(_findall("Emma",
                       f"Vi laver en quiz til de andre. Find alle de regnestykker,\n"
                       f"der giver {target} – så bruger vi dem.",
                       target, "Tjek hvert stykke grundigt, også dem der ligner."))
    return qs


# --- 6. SKAB: fremlæggelsen for Hr. Poulsen -----------------------------

def boss(tier):
    qs = []

    pris = random.choice([35, 45, 60])
    elever = random.choice([20, 24, 25])
    qs.append(_write("Hr. Poulsen",
                     f"Klassekassen: hver elev lægger {pris} kr, og vi er {elever} i klassen.\n"
                     f"Hvor mange kroner har vi så?",
                     pris * elever, f"{pris} kr gange {elever} elever.", "kr", "gange"))

    total = pris * elever
    bus = round(total * 0.6 / 10) * 10
    qs.append(_write("Hr. Poulsen",
                     f"Bussen til udflugten koster {bus} kr af vores {total} kr.\n"
                     f"Hvor meget er der tilbage til mad?",
                     total - bus, "Træk busprisen fra det samlede beløb.", "kr", "penge"))

    grupper = random.choice([3, 4])
    pr_gruppe = random.choice([6, 8])
    qs.append(_balance("Hr. Poulsen",
                       f"Vi har {grupper * pr_gruppe} opgaveark, som skal deles ligeligt\n"
                       f"mellem {grupper} grupper. Hvor mange ark til hver gruppe?",
                       grupper, "x", pr_gruppe,
                       f"Del {grupper * pr_gruppe} med {grupper}.", "division"))

    a, b = random.randint(6, 9), random.randint(6, 9)
    rigtigt = random.random() < 0.5
    vist = a * b if rigtigt else a * b + random.choice([-3, 3])
    qs.append(_truefalse("Hr. Poulsen",
                         "Der står stadig noget på tavlen fra i går. Holder det?",
                         f"{a} x {b} = {vist}", rigtigt,
                         f"Regn {a} gange {b} omhyggeligt."))

    for _ in range(2):
        p = make_creative(tier)
        nums = ", ".join(str(n) for n in p["numbers"])
        qs.append(_build("Hr. Poulsen",
                         f"Og så den sidste, som er din egen.\n"
                         f"Byg et regnestykke, der giver {p['target']}, med tallene {nums}\n"
                         f"– hvert tal én gang – og mindst {p['min_ops']} forskellige regnearter.",
                         p, "Husk: gange og dividere regnes før plus og minus."))
    return qs


ENCOUNTERS = {
    "husk": {"bloom": "HUSK", "gen": husk},
    "forstaa": {"bloom": "FORSTÅ", "gen": forstaa},
    "anvend": {"bloom": "ANVEND", "gen": anvend},
    "analyser": {"bloom": "ANALYSÉR", "gen": analyser},
    "vurder": {"bloom": "VURDÉR", "gen": vurder},
    "boss": {"bloom": "SKAB", "gen": boss},
}

BLOOM_ORDER = ["HUSK", "FORSTÅ", "ANVEND", "ANALYSÉR", "VURDÉR", "SKAB"]

# Kan-mål i elevplan-sprog – vises til sidst i stedet for en karakter.
CAN_STATEMENTS = [
    ("HUSK", "Jeg kan mine tal-fakta uden at tælle på fingre"),
    ("FORSTÅ", "Jeg kan forstå, hvad en opgave spørger om"),
    ("ANVEND", "Jeg kan bruge matematik, når jeg handler ind"),
    ("ANALYSÉR", "Jeg kan finde mønstre og regne i flere trin"),
    ("VURDÉR", "Jeg kan tjekke, om et svar er rigtigt"),
    ("SKAB", "Jeg kan selv bygge et regnestykke"),
]


# --- Sidequests ---------------------------------------------------------
# Korte opgaver (3 stk) hos folk rundt omkring i verdenen. De er frivillige,
# og man får en ting i tasken, hvis man rammer mindst 85 % i første forsøg.

def sq_kiosk(tier):
    pris = random.choice([12, 17, 23, 28])
    antal = random.randint(2, 4)
    stk = random.choice([4, 6, 7])
    return [
        _coins("Kioskmanden",
               f"Så er det {pris} kr for isen. Har du lige pengene?\n"
               f"Jeg er løbet tør for byttepenge i dag.",
               pris, "Tag de store mønter først, og fyld op med de små."),
        _write("Kioskmanden",
               f"Og hvis I er {antal} om at dele regningen på {pris * antal} kr –\n"
               f"hvor meget skal hver især give?",
               pris, f"Del {pris * antal} med {antal}.", "kr", "division"),
        _findall("Kioskmanden",
                 f"Jeg skal have prismærker på. Hvilke af dem her giver {stk * 3}?",
                 stk * 3, "Regn hvert stykke ud, ét ad gangen."),
    ]


def sq_bibliotek(tier):
    hylder = random.choice([4, 5, 6])
    pr = random.choice([6, 8, 9])
    start, step = random.randint(2, 5), random.randint(2, 5)
    seq_vals = [start + i * step for i in range(5)]
    blank = random.choice([2, 3])
    shown = list(seq_vals)
    answer = seq_vals[blank]
    shown[blank] = None
    return [
        _write("Bibliotekaren",
               f"Der skal stå {pr} bøger på hver af de {hylder} hylder.\n"
               f"Hvor mange bøger skal jeg hente?",
               hylder * pr, f"{pr} gange {hylder}.", "stk", "gange"),
        _sequence("Bibliotekaren",
                  "Bognumrene på reolen står i en fast rækkefølge.\n"
                  "Hvilket nummer mangler?",
                  shown, answer, "Se, hvor meget numrene stiger hver gang."),
        _write("Bibliotekaren",
               f"{hylder * pr} bøger skal deles ligeligt i {hylder} kasser.\n"
               f"Hvor mange kommer der i hver kasse?",
               pr, f"Del {hylder * pr} med {hylder}.", "stk", "division"),
    ]


def sq_park_barn(tier):
    slik = random.choice([12, 16, 20])
    venner = random.choice([2, 4])
    paastand_rigtig = random.random() < 0.5
    vist = slik // 4 if paastand_rigtig else slik // 4 + 1
    return [
        _write("Viggo",
               f"Jeg har {slik} vingummier, og vi er {venner}.\n"
               f"Hvor mange får vi hver, hvis vi deler lige?",
               slik // venner, f"Del {slik} med {venner}.", "stk", "division"),
        _write("Viggo",
               f"Hvis jeg giver halvdelen af mine {slik} væk,\n"
               f"hvor mange har jeg så tilbage?",
               slik // 2, "Halvdelen betyder delt med 2.", "stk", "halve"),
        _truefalse("Viggo",
                   "Min storebror siger, det her passer. Gør det?",
                   f"{slik} : 4 = {vist}", paastand_rigtig,
                   "Regn det selv, og se efter."),
    ]


def sq_hund(tier):
    ture = random.choice([3, 4, 5])
    min_pr = random.choice([10, 15, 20])
    return [
        _write("Hundelufteren",
               f"Jeg går {ture} ture om dagen, og hver tur tager {min_pr} minutter.\n"
               f"Hvor mange minutter bliver det i alt?",
               ture * min_pr, f"{min_pr} gange {ture}.", "min", "gange"),
        _balance("Hundelufteren",
                 f"På en uge går jeg {ture * 7} ture.\n"
                 f"Hvor mange dage er der gået, når jeg har gået {ture * 4} ture?",
                 ture, "x", 4, f"Hvor mange gange går {ture} op i {ture * 4}?",
                 "division"),
        _choice("Hundelufteren",
                f"Hunden vejede {random.choice([8, 12, 16])} kg sidste år\n"
                f"og vejer det dobbelte nu. Hvad skal jeg regne?",
                ["Lægge 2 til", "Gange med 2", "Dividere med 2", "Trække 2 fra"], 1,
                "Dobbelt så meget betyder gange med 2.", "gange"),
    ]


def sq_pedel(tier):
    raekker = random.choice([4, 5, 6])
    pr = random.choice([5, 6, 8])
    tilovers = random.choice([4, 6, 8])
    return [
        _write("Pedellen",
               f"Der skal stilles {raekker} rækker med {pr} stole til morgensang.\n"
               f"Hvor mange stole skal jeg hente?",
               raekker * pr, f"{raekker} gange {pr}.", "stk", "gange"),
        _write("Pedellen",
               f"Vi har {raekker * pr + tilovers} stole i alt.\n"
               f"Hvor mange bliver der tilovers, når jeg har stillet {raekker * pr} op?",
               tilovers, "Træk det opstillede fra det samlede antal.",
               "stk", "plus"),
        _findall("Pedellen",
                 f"Jeg har kridtet tal på gulvet. Hvilke giver {raekker * pr // 2}?",
                 raekker * pr // 2, "Regn dem igennem ét ad gangen."),
    ]


def sq_sport(tier):
    maal = random.choice([3, 4, 5])
    kampe = random.choice([4, 6])
    return [
        _write("Sportslæreren",
               f"Holdet har scoret {maal} mål i hver af de {kampe} kampe.\n"
               f"Hvor mange mål er det i alt?",
               maal * kampe, f"{maal} gange {kampe}.", "mål", "gange"),
        _write("Sportslæreren",
               f"Vi skal dele {kampe * 4} spillere i {kampe // 2} lige store hold.\n"
               f"Hvor mange på hvert hold?",
               (kampe * 4) // (kampe // 2), f"Del {kampe * 4} med {kampe // 2}.",
               "stk", "division"),
        _truefalse("Sportslæreren",
                   "En elev har regnet målscoren sammen. Passer det?",
                   f"{maal} x {kampe} = {maal * kampe}", True,
                   f"Regn {maal} gange {kampe} efter."),
    ]


SIDE_ENCOUNTERS = {
    "sq_kiosk": {"bloom": "ANVEND", "gen": sq_kiosk},
    "sq_bibliotek": {"bloom": "ANALYSÉR", "gen": sq_bibliotek},
    "sq_park_barn": {"bloom": "FORSTÅ", "gen": sq_park_barn},
    "sq_hund": {"bloom": "ANVEND", "gen": sq_hund},
    "sq_pedel": {"bloom": "HUSK", "gen": sq_pedel},
    "sq_sport": {"bloom": "ANALYSÉR", "gen": sq_sport},
}

ENCOUNTERS.update(SIDE_ENCOUNTERS)

# Hvilken ting man får, hvis man rammer mindst 85 % i første forsøg.
REWARD_PCT = 0.85

REWARDS = {
    "husk": "guldmoent",
    "forstaa": "toejpose",      # låser klæd-om op
    "anvend": "is",
    "analyser": "fodbold",      # låser fodbold op
    "vurder": "kridt",
    "boss": "pokal",
    "sq_kiosk": "slik",
    "sq_bibliotek": "bog",
    "sq_park_barn": "toejpose",
    "sq_hund": "hundeben",
    "sq_pedel": "noegle",
    "sq_sport": "fodbold",
}
