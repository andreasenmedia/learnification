"""
Matematikindholdet. Hver opgave er pakket ind i en situation fra en helt
almindelig skoledag – og hver opgave har sin egen minispilstype, så man
ikke bare skriver i en kasse hver gang.

Blooms taksonomi styrer rækkefølgen:
HUSK -> FORSTÅ -> ANVEND -> ANALYSÉR -> VURDÉR -> SKAB.

Sværhedsgraden følger KLASSETRIN, ikke alder. Et barn i 3. klasse kan være
8 eller 10 år, men det, det har lært, følger klassen – og det er dét,
Fælles Mål er skrevet efter. TRIN nedenfor er én profil pr. klassetrin, og
den bestemmer både talområde, hvilke regningsarter der overhovedet dukker
op, og hvilke emner der er i spil.

Hver opgave peger på en side i Regnebogen (feltet "book"), så hjælpen
slår op på det rigtige sted.
"""

import random
import re
from collections import Counter

# --- Klassetrin ---------------------------------------------------------
#
# Profilerne er lagt efter Fælles Mål for matematik, faserne i indskolingen
# (1.-3. klasse) og på mellemtrinnet (4.-6. klasse). Det afgørende er ikke
# kun HVOR STORE tallene er, men HVAD der er lært endnu: en elev i 1. klasse
# har ikke mødt gangetabellen, og derfor må der ikke komme et gangestykke –
# heller ikke et nemt et.
#
# "maal" er den korte udgave af, hvad trinnet dækker. Den bliver vist i
# spillet, når klassetrinnet vælges, så en voksen kan se, hvad barnet møder.
#
# Der er forskel på, hvor store tal et barn KENDER, og hvor store tal det
# kan REGNE MED I HOVEDET. En elev i 3. klasse kender tal op til 1000, men
# skal ikke stå og lægge 296 og 284 sammen uden papir. Derfor har hvert
# trin både et talområde (`hi`, `sum`) og et regneloft:
#
#   plus       største tal i et plus- eller minusstykke, man regner i hovedet
#   gange_top  største produkt, et gangestykke må give (0 = ingen gange endnu)
#   del_top    største tal, der bliver delt i et divisionsstykke
#   kr         største beløb i en pengeopgave
#
# Regneloftet er dét, der afgør, om en opgave føles til at gå til. Er
# opgaverne for svære, er det her, der skal skrues ned – ikke i `hi`.

TRIN = {
    1: {
        "klasse": 1, "navn": "1. klasse",
        "maal": "Tal op til 20. Plus og minus. Dobbelt og halvdelen. "
                "Tælle med 2, 5 og 10. Klokken hele timer. Mønter.",
        "hi": 20, "sum": 20, "kr": 20,
        "plus": 10, "gange_top": 0, "del_top": 0,
        "tabeller": [], "spring": [1, 2, 5, 10],
        "gange": False, "division": False, "rest": False,
        "halve": True, "fjerdedele": False, "broek": False,
        "decimal": False, "procent": False, "ligning": False,
        "hierarki": False, "negative": False, "areal": False,
        "gennemsnit": False, "klokke": "hel",
    },
    2: {
        "klasse": 2, "navn": "2. klasse",
        "maal": "Tal op til 100. Plus og minus med tiere-overgang. "
                "2-, 5- og 10-tabellen. Dele i lige store bunker. "
                "Klokken hel, halv og kvarter.",
        "hi": 100, "sum": 100, "kr": 100,
        "plus": 50, "gange_top": 50, "del_top": 50,
        "tabeller": [2, 5, 10], "spring": [2, 5, 10],
        "gange": True, "division": True, "rest": False,
        "halve": True, "fjerdedele": False, "broek": False,
        "decimal": False, "procent": False, "ligning": False,
        "hierarki": False, "negative": False, "areal": False,
        "gennemsnit": False, "klokke": "kvarter",
    },
    3: {
        "klasse": 3, "navn": "3. klasse",
        "maal": "Tal op til 1000. Hele gangetabellen. Division uden rest. "
                "Halve og fjerdedele. Omkreds. Klokken på minuttet.",
        "hi": 1000, "sum": 1000, "kr": 200,
        "plus": 100, "gange_top": 100, "del_top": 100,
        "tabeller": [2, 3, 4, 5, 6, 7, 8, 9, 10], "spring": [2, 3, 4, 5, 10],
        "gange": True, "division": True, "rest": False,
        "halve": True, "fjerdedele": True, "broek": False,
        "decimal": False, "procent": False, "ligning": False,
        "hierarki": False, "negative": False, "areal": False,
        "gennemsnit": False, "klokke": "minut",
    },
    4: {
        "klasse": 4, "navn": "4. klasse",
        "maal": "Tal op til 10.000. Gange flercifret med etcifret. "
                "Division med rest. Kroner og øre. Brøkdele. "
                "Areal og omkreds af et rektangel.",
        "hi": 10000, "sum": 5000, "kr": 400,
        "plus": 200, "gange_top": 200, "del_top": 200,
        "tabeller": [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], "spring": [3, 4, 6, 7, 8, 25],
        "gange": True, "division": True, "rest": True,
        "halve": True, "fjerdedele": True, "broek": True,
        "decimal": True, "procent": False, "ligning": False,
        "hierarki": False, "negative": False, "areal": True,
        "gennemsnit": False, "klokke": "minut",
    },
    5: {
        "klasse": 5, "navn": "5. klasse",
        "maal": "Store tal. Gange flercifret med etcifret. Division. "
                "Brøk, decimaltal og procent hænger sammen. "
                "Parenteser og gange før plus. Negative tal.",
        "hi": 100000, "sum": 20000, "kr": 800,
        "plus": 1000, "gange_top": 600, "del_top": 600,
        "tabeller": [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], "spring": [6, 7, 8, 9, 12, 25, 50],
        "gange": True, "division": True, "rest": True,
        "halve": True, "fjerdedele": True, "broek": True,
        "decimal": True, "procent": True, "ligning": False,
        "hierarki": True, "negative": True, "areal": True,
        "gennemsnit": True, "klokke": "minut",
    },
    6: {
        "klasse": 6, "navn": "6. klasse",
        "maal": "Procent og rabat. Brøkregning. Simple ligninger. "
                "Areal af en trekant. Gennemsnit. Negative tal. "
                "Regnearternes rækkefølge.",
        "hi": 100000, "sum": 50000, "kr": 1200,
        "plus": 1000, "gange_top": 900, "del_top": 900,
        "tabeller": [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], "spring": [7, 8, 9, 12, 15, 25, 50],
        "gange": True, "division": True, "rest": True,
        "halve": True, "fjerdedele": True, "broek": True,
        "decimal": True, "procent": True, "ligning": True,
        "hierarki": True, "negative": True, "areal": True,
        "gennemsnit": True, "klokke": "minut",
    },
}

KLASSER = [1, 2, 3, 4, 5, 6]
STANDARD_KLASSE = 3


def trin_for_klasse(klasse):
    """Profilen for et klassetrin. Ukendte trin lander på et midterniveau."""
    return TRIN.get(int(klasse), TRIN[STANDARD_KLASSE])


# --- Små hjælpere til tallene ------------------------------------------

def _r(a, b):
    a, b = int(a), int(b)
    return random.randint(min(a, b), max(a, b))


def regneloft(t):
    """Det største tal, barnet selv skal regne sig frem til på trinnet.

    Talområdet (`hi`) siger, hvilke tal barnet KENDER. Regneloftet siger,
    hvor store tal det skal regne MED – og det er dét, der afgør, om
    opgaverne er til at gå til. Prøven i tools/tjek_klassetrin.py måler
    hver eneste opgave mod det her tal.
    """
    return max(t["plus"], t["gange_top"], t["kr"])


def _fak(t, mindst=2, hoejst=None):
    """En faktor, man må gange med på det her klassetrin."""
    bud = [n for n in t["tabeller"] if n >= mindst and (hoejst is None or n <= hoejst)]
    if not bud:
        bud = [n for n in t["tabeller"]] or [2]
    return random.choice(bud)


def _spring(t, top):
    """Et spring i en talrække, der kan være der fem tal i træk."""
    bud = [s for s in t["spring"] if 2 + 4 * s <= top]
    return random.choice(bud) if bud else min(t["spring"])


def _pr_gruppe(t, antal, mindst=2, hoejst=None):
    """Hvor mange der må ligge i hver af `antal` grupper.

    Produktet skal holde sig under trinnets gangeloft: seks rækker med ti
    stole er tres stole, og det er over stregen i 2. klasse.
    """
    loft = max(2, t["gange_top"] // max(1, antal))
    tabel = t["tabeller"] or [2]
    bud = [n for n in tabel
           if n >= mindst and n <= loft and (hoejst is None or n <= hoejst)]
    if not bud:
        bud = [n for n in tabel if n <= loft] or [min(tabel)]
    return random.choice(bud)


def _gang_par(t, loft=None):
    """Et gangestykke, trinnet både har mødt og kan regne: (a, b).

    Fra 4. klasse må den ene faktor være flercifret – det er dét, trinnet
    hedder – men produktet bliver under gangeloftet, så det stadig kan
    regnes uden papir.
    """
    top = min(t["gange_top"], loft) if loft else t["gange_top"]
    if top < 4:
        return 2, 2
    b = _fak(t, 2, 9)
    if t["klasse"] >= 4 and random.random() < .6:
        a = _r(2, max(2, min(99, top // b)))
        if a > 20 and random.random() < .5:
            a = max(2, round(a / 5) * 5)
    else:
        a = _fak(t)
        if a * b > top:
            a = max(2, top // b)
    return a, b


def _del_par(t, loft=None):
    """Et divisionsstykke, der går op: (hvor mange i alt, hvor mange bunker).

    Stykket bliver inden for trinnets deleloft, og resultatet holder sig i
    tabellen – ellers står en elev i 3. klasse med 172 delt med 4.
    """
    top = min(t["del_top"], loft) if loft else t["del_top"]
    if top < 4:
        return 4, 2
    delere = [d for d in (t["tabeller"] or [2]) if 2 <= d <= 10] or [2]
    d = random.choice(delere)
    kvotient = _r(2, max(2, min(12, top // d)))
    return d * kvotient, d


def _beloeb(t, andel=1.0, loft=None):
    """Et pænt beløb i trinnets størrelsesorden.

    Store beløb bliver runde. 240 kr kan regnes i hovedet, 237 kan ikke,
    og opgaven skal handle om at handle ind – ikke om at cifre går op.
    `loft` sætter et loft oveni, fx når beløbet skal lægges op i mønter.
    """
    top = max(5, int(t["kr"] * andel))
    if loft:
        top = max(5, min(top, loft))
    if top <= 20:
        return _r(2, top)
    if top <= 60:
        return _r(1, top // 5) * 5
    if top <= 300:
        return _r(2, top // 10) * 10
    return _r(2, top // 25) * 25


def _tal(t, andel=1.0):
    """Et tal, barnet selv skal regne med – altså inden for regneloftet.

    Regneloftet (`plus`) er lavere end talområdet (`hi`) med vilje: en elev
    i 3. klasse kender tallet 964, men skal ikke lægge det sammen med 287
    i hovedet.
    """
    top = max(5, int(t["plus"] * andel))
    if top <= 20:
        return _r(2, top)
    if top <= 100:
        return _r(2, top) if random.random() < .5 else _r(1, top // 5) * 5
    if top <= 500:
        return _r(2, top // 10) * 10
    return _r(2, top // 50) * 50


def _plus_par(t, andel=1.0):
    """To tal, der må lægges sammen i hovedet på trinnet.

    Summen holder sig under regneloftet – ellers kommer 3. klasse til at
    lægge 96 og 87 sammen, og det er ikke dét, opgaven handler om.
    """
    top = max(4, int(t["plus"] * andel))
    # det første tal må gerne fylde noget: 4 + 15 er ikke en opgave i
    # 3. klasse, men 45 + 30 er
    a = _r(max(2, top // 3), max(3, top - 2))
    b = _r(1, max(1, top - a))
    if top > 100:
        # over hundrede regner man med hele tiere, ikke med 501 + 143
        a, b = max(10, round(a / 10) * 10), max(10, round(b / 10) * 10)
    elif a >= 20 and random.random() < .5:
        b = max(1, round(b / 5) * 5)
    return a, b


def check_numeric(user, answer):
    """Tilgivende talkontrol: 12, 12,5, 12.5, 1.234 og '45 kr' virker alle."""
    raw = str(user).strip().lower().replace("kr", "")
    raw = re.sub(r"[^0-9.,\-]", "", raw)
    if not raw or raw in ("-", ".", ","):
        return False
    for c in {raw.replace(".", "").replace(",", "."), raw.replace(",", "")}:
        try:
            if abs(float(c) - float(answer)) < 0.011:
                return True
        except ValueError:
            continue
    return False


def fmt(n):
    if float(n).is_integer():
        return str(int(n))
    return f"{n:.2f}".replace(".", ",").rstrip("0").rstrip(",")


def kr(n):
    """Et beløb, som det står på en prisskilt: 22,50 – ikke 22,5."""
    if float(n).is_integer():
        return str(int(n))
    return f"{n:.2f}".replace(".", ",")


# --- Kreative opgaver (SKAB) --------------------------------------------

ALLOWED_EXPR = re.compile(r"^[0-9+\-*/(). ]+$")


def make_creative(t):
    """Byg-selv-opgave med de regnearter, klassetrinnet har mødt."""
    if not t["gange"]:
        antal, tegn, min_ops = 2, "+-", 1
    elif not t["hierarki"]:
        antal, tegn, min_ops = 3, "+-*", 2
    else:
        antal, tegn, min_ops = random.choice([3, 4]), "+-*/", 2
    top = 9 if t["klasse"] <= 3 else 12

    for _ in range(400):
        nums = [random.randint(2, top) for _ in range(antal)]
        ops = [random.choice(tegn) for _ in range(len(nums) - 1)]
        expr = str(nums[0])
        for i, op in enumerate(ops):
            expr += op + str(nums[i + 1])
        try:
            val = eval(expr, {"__builtins__": {}}, {})
        except ZeroDivisionError:
            continue
        if not isinstance(val, (int, float)) or not float(val).is_integer() or val <= 0:
            continue
        if not t["gange"] and val > t["sum"]:
            continue
        if len(set(ops)) >= min_ops:
            return {"numbers": nums, "target": int(val), "min_ops": min_ops,
                    "allowed": tegn, "expr": expr}
    return {"numbers": [3, 4], "target": 7, "min_ops": 1, "allowed": "+-", "expr": "3+4"}


def check_creative(expr, puzzle):
    e = expr.strip().replace("x", "*").replace("X", "*").replace(":", "/").replace("÷", "/")
    e = e.replace(",", ".")
    if not e:
        return False, "Skriv et regnestykke først."
    if not ALLOWED_EXPR.match(e):
        return False, "Brug kun tal og + - x : ( )"
    used = [int(n) for n in re.findall(r"\d+", e)]
    if Counter(used) != Counter(puzzle["numbers"]):
        need = ", ".join(str(n) for n in puzzle["numbers"])
        return False, f"Du skal bruge hvert af tallene {need} præcis én gang."
    ops = [c for c in e if c in "+-*/"]
    if len(set(ops)) < puzzle["min_ops"]:
        return False, f"Brug mindst {puzzle['min_ops']} forskellige regnearter."
    try:
        val = eval(e, {"__builtins__": {}}, {})
    except Exception:
        return False, "Det regnestykke kan ikke regnes ud. Tjek parenteserne."
    if abs(val - puzzle["target"]) < 0.001:
        return True, ""
    return False, f"Det giver {fmt(val)} – og det skulle gerne give {puzzle['target']}."


# --- Opgavetyper --------------------------------------------------------

def _write(speaker, q, answer, hint, unit="", book="plus"):
    return {"kind": "write", "speaker": speaker, "q": q, "answer": answer,
            "hint": hint, "unit": unit, "book": book}


def _choice(speaker, q, choices, answer, hint, book="plus"):
    return {"kind": "choice", "speaker": speaker, "q": q, "choices": choices,
            "answer": answer, "hint": hint, "book": book}


def _balance(speaker, q, a, op, answer, hint, book="gange"):
    target = a * answer if op == "x" else (a + answer if op == "+" else a - answer)
    return {"kind": "balance", "speaker": speaker, "q": q, "a": a, "op": op,
            "target": target, "answer": answer, "hint": hint, "book": book,
            "min": 0, "max": max(20, answer + 8), "start": max(1, answer // 2)}


def _sequence(speaker, q, seq, answer, hint, book="monstre"):
    return {"kind": "sequence", "speaker": speaker, "q": q, "seq": seq,
            "answer": answer, "hint": hint, "book": book}


def _truefalse(speaker, q, statement, is_true, hint, book="tjek"):
    return {"kind": "truefalse", "speaker": speaker, "q": q, "statement": statement,
            "is_true": is_true, "hint": hint, "book": book}


def _coins(speaker, q, target, hint, book="penge"):
    return {"kind": "coins", "speaker": speaker, "q": q, "target": target,
            "hint": hint, "book": book}


def _build(speaker, q, puzzle, hint, book="raekkefolge"):
    return {"kind": "build", "speaker": speaker, "q": q, "puzzle": puzzle,
            "hint": hint, "book": book}


def _expr_for(value, t):
    """Et tilfældigt regnestykke, der giver netop value.

    Kun med regnearter, klassetrinnet har mødt – ellers står der et
    gangestykke på en flise foran en elev i 1. klasse.
    """
    forms = []
    if value > 1:
        if value <= 20:
            a = random.randint(1, value - 1)
        else:
            # Fliserne skal kunne regnes i hovedet, otte ad gangen. Derfor
            # lægger vi enten et lille tal eller et rundt tiertal til.
            a = random.choice([random.randint(1, 9),
                               random.randint(1, max(1, value // 10)) * 10])
            a = min(max(1, a), value - 1)
        forms.append(f"{a} + {value - a}")
    # Trækstykket må ikke starte over trinnets talområde: en elev i 1. klasse
    # skal ikke stå med "27 - 9", bare fordi facit er 18.
    plads = max(0, t["sum"] - value)
    if plads >= 1:
        b = random.randint(1, min(9, plads))
        forms.append(f"{value + b} - {b}")
    if t["gange"]:
        top = max(t["tabeller"]) if t["tabeller"] else 10
        divs = [d for d in range(2, top + 1)
                if value % d == 0 and 2 <= value // d <= top]
        if divs:
            d = random.choice(divs)
            forms.append(f"{d} x {value // d}")
    return random.choice(forms)


def _findall(speaker, q, target, hint, t, n_correct=3, n_total=8, book=None):
    # Uden gange er det plus og minus, der står på fliserne – så skal
    # Regnebogen også slå op på den rigtige side.
    if book is None:
        book = "gange" if t["gange"] else "plus"
    labels = set()
    tiles = []
    guard = 0
    while len([x for x in tiles if x[1] == target]) < n_correct and guard < 200:
        guard += 1
        lab = _expr_for(target, t)
        if lab not in labels:
            labels.add(lab)
            tiles.append((lab, target))
    loft = regneloft(t)
    while len(tiles) < n_total and guard < 400:
        guard += 1
        off = random.choice([-6, -4, -3, -2, -1, 1, 2, 3, 4, 6])
        v = target + off
        # de forkerte fliser skal også kunne regnes på trinnet: en flise til
        # 24 hører ikke hjemme foran en elev i 1. klasse
        if v < 1 or v > loft:
            continue
        lab = _expr_for(v, t)
        if lab not in labels:
            labels.add(lab)
            tiles.append((lab, v))
    random.shuffle(tiles)
    return {"kind": "findall", "speaker": speaker, "q": q, "target": target,
            "tiles": tiles, "hint": hint, "book": book}


# --- 1. HUSK: morgen på værelset ----------------------------------------

def husk(t):
    qs = []

    # Klokken – præcis så fint et urskive-skridt, som trinnet er nået til
    time = random.choice([7, 8])
    if t["klokke"] == "hel":
        qs.append(_write("Dig selv",
                         f"Klokken er {time}, og bussen kører en time senere.\n"
                         f"Hvad er klokken, når bussen kører?",
                         time + 1, "En time senere er ét tal længere frem.",
                         "", "plus"))
    elif t["klokke"] == "kvarter":
        minutter = random.choice([15, 30, 45])
        qs.append(_write("Dig selv",
                         f"Klokken er {time}:{60 - minutter:02d}, og bussen kører {time + 1}:00.\n"
                         f"Hvor mange minutter har jeg?",
                         minutter, "Tæl op til den hele time – et kvarter ad gangen.",
                         "min", "plus"))
    else:
        minutter = random.choice([15, 20, 25, 35, 40, 50])
        qs.append(_write("Dig selv",
                         f"Klokken er {time}:{60 - minutter:02d}, og bussen kører {time + 1}:00.\n"
                         f"Hvor mange minutter har jeg?",
                         minutter, f"Fra {60 - minutter} minutter over til den hele time.",
                         "min", "plus"))

    # Lommepenge i sparegrisen
    a, b = _plus_par(t, .9)
    qs.append(_write("Dig selv",
                     f"Der ligger {a} kr i sparegrisen, og jeg får {b} kr i lommepenge i dag.\n"
                     f"Hvor meget har jeg så?",
                     a + b, "Læg de to beløb sammen.", "kr", "plus"))

    # Find alle regnestykker, der giver det samme
    if t["gange"]:
        # HUSK-niveauet er tal-fakta, ikke hovedregning i flere trin – så
        # fliserne her holder sig i den lille ende
        a, b = _gang_par(t, min(30 if t["klasse"] <= 3 else 60,
                                regneloft(t) - 6))
        target = a * b
    else:
        target = _r(8, min(14, t["sum"] - 6))
    qs.append(_findall("Dig selv",
                       f"På forsiden af hæftet har jeg kradset en masse regnestykker.\n"
                       f"Hvilke af dem giver {target}?",
                       target, "Regn dem ud én ad gangen, og vælg dem der passer.", t))

    # Madpakken: gentagen addition i 1. klasse, deling derefter
    if not t["gange"]:
        per, dage = _r(2, 3), _r(3, 4)
        qs.append(_write("Dig selv",
                         f"Der skal {per} stykker frugt i madpakken hver dag.\n"
                         f"Hvor mange stykker skal der bruges på {dage} dage?",
                         per * dage,
                         "Læg " + str(per) + " sammen for hver dag: " +
                         " + ".join([str(per)] * dage) + ".", "stk", "plus"))
    else:
        dage = _r(3, 6)
        per = _pr_gruppe(t, dage, 2, 6)
        qs.append(_balance("Dig selv",
                           f"Der skal {per} stykker frugt i madpakken hver dag.\n"
                           f"Hvor mange dage rækker {per * dage} stykker til?",
                           per, "x", dage,
                           f"Hvor mange gange går {per} op i {per * dage}?", "gange"))

    # Hvad er der tilbage
    total = max(6, _beloeb(t, .5))
    brugt = _r(2, max(2, total // 2))
    if total > 60:
        brugt = max(5, round(brugt / 5) * 5)
    qs.append(_write("Dig selv",
                     f"Jeg havde {total} kr, men brugte {brugt} kr på en sodavand i går.\n"
                     f"Hvor meget er der tilbage?",
                     total - brugt, "Træk det brugte fra det, du havde.", "kr", "plus"))
    return qs


# --- 2. FORSTÅ: køkkenet med Mor ----------------------------------------

def forstaa(t):
    qs = []

    # Hvor mange må vente
    hold = random.choice([6, 8, 10]) if t["klasse"] <= 3 else random.choice([12, 16, 20])
    ialt = hold + random.choice([4, 6, 8])
    qs.append(_write("Mor",
                     f"Der skal {ialt} boller i alt, men der er kun plads til {hold} i ovnen\n"
                     f"ad gangen. Hvor mange må vente til næste hold?",
                     ialt - hold, "Hvor mange bliver der tilovers, når ovnen er fuld?",
                     "stk", "plus"))

    # Plader i ovnen
    if not t["gange"]:
        paa_plade, paa_bord = _r(4, 9), _r(3, 8)
        qs.append(_write("Mor",
                         f"Der ligger {paa_plade} boller på pladen og {paa_bord} på bordet.\n"
                         f"Hvor mange er der i alt?",
                         paa_plade + paa_bord, "Læg de to tal sammen.", "stk", "plus"))
    else:
        plader = random.choice([2, 3, 4])
        pr_plade = _pr_gruppe(t, plader, 2, 8)
        qs.append(_balance("Mor",
                           f"Vi sætter {plader} plader i ovnen og får {plader * pr_plade} boller ud.\n"
                           f"Hvor mange lå der på hver plade?",
                           plader, "x", pr_plade,
                           f"Del {plader * pr_plade} med {plader}.", "division"))

    # Den halve portion – og fjerdedele, når de er lært
    if t["fjerdedele"] and random.random() < .5:
        dl = random.choice([8, 12, 16, 20])
        qs.append(_write("Mor",
                         f"Opskriften siger {dl} dl mælk, men vi laver kun en fjerdedel.\n"
                         f"Hvor mange dl skal du hælde op?",
                         dl // 4, "En fjerdedel betyder delt i 4 lige store dele.",
                         "dl", "halve"))
    else:
        dl = random.choice([4, 6, 8, 10])
        qs.append(_write("Mor",
                         f"Opskriften siger {dl} dl mælk, men vi laver kun den halve portion.\n"
                         f"Hvor mange dl skal du hælde op?",
                         dl // 2,
                         "Den halve portion betyder delt med 2." if t["division"]
                         else "Den halve portion er lige så meget i to bunker.",
                         "dl", "halve"))

    # Del posen
    if t["broek"]:
        vg = random.choice([12, 16, 20, 24])
        del_ = random.choice([3, 4])
        ental, flertal = {3: ("tredjedel", "tredjedele"),
                          4: ("fjerdedel", "fjerdedele")}[del_]
        qs.append(_write("Ida",
                         f"Der er {vg} vingummier, og jeg får "
                         f"{'to' if del_ == 3 else 'tre'} {flertal} af dem.\n"
                         f"Hvor mange er det?",
                         vg // del_ * (del_ - 1),
                         f"Find først én {ental}: {vg} delt med {del_}.", "stk", "halve"))
    else:
        vg = random.choice([12, 16, 20, 24]) if t["klasse"] >= 2 else random.choice([6, 8, 10, 12])
        qs.append(_write("Ida",
                         f"Vi deler posen lige over! Der er {vg} vingummier.\n"
                         f"Hvor mange får jeg så?",
                         vg // 2, "Lige over betyder to lige store bunker.",
                         "stk", "halve"))

    # Ovntiden
    minutter = random.choice([12, 15, 18])
    qs.append(_choice("Mor",
                      f"Bollerne skal have {minutter} minutter, og de kom ind for\n"
                      f"{minutter - 5} minutter siden. Hvad passer?",
                      ["De er færdige nu",
                       "De skal have 5 minutter mere",
                       f"De skal have {minutter} minutter mere",
                       f"De skal have {minutter + 5} minutter mere"], 1,
                      "Hvor meget mangler der, før tiden er gået?", "plus"))
    return qs


# --- 3. ANVEND: indkøb med Far ------------------------------------------

def anvend(t):
    qs = []

    # Flere ens varer
    if not t["gange"]:
        pris = random.choice([4, 5, 6, 8])
        qs.append(_write("Far",
                         f"En pose æbler koster {pris} kr, og vi tager to poser.\n"
                         f"Hvad bliver det?",
                         pris * 2, f"To poser er det dobbelte: {pris} + {pris}.",
                         "kr", "plus"))
        total = pris * 2
    else:
        pris, antal = _gang_par(t, t["kr"])
        # prisen er det største af de to tal: en pose æbler til 2 kr og ni
        # poser er et mærkeligt indkøb
        pris, antal = max(pris, antal), max(2, min(pris, antal))
        qs.append(_write("Far",
                         f"Æblerne koster {pris} kr for en pose, og vi tager {antal} poser.\n"
                         f"Hvad bliver det?",
                         pris * antal, f"{pris} kr gange {antal} poser.", "kr", "gange"))
        total = pris * antal

    # Læg pengene op. Beløbet skal stå ÉT sted, ellers kommer der et tal i
    # teksten og et andet i kassen – og så kan opgaven ikke løses.
    op = _beloeb(t, .25, 100)
    qs.append(_coins("Far",
                     f"Bollerne koster {op} kr, og manden vil helst have det præcist.\n"
                     f"Vil du lægge pengene op?",
                     op, "Start med de store mønter, og fyld op med de små."))

    # Byttepenge. Sedlen er den første runde seddel over beløbet, så
    # byttepengene bliver et tal, man kan tælle sig op til.
    sedler = [20, 50] if t["klasse"] == 1 else [50, 100, 200, 500, 1000]
    seddel = next((n for n in sedler if n > total), ((total // 50) + 1) * 50)
    qs.append(_write("Far",
                     f"Jeg betaler med {seddel} kr, og varerne koster {total} kr.\n"
                     f"Hvor meget får vi tilbage?",
                     seddel - total, "Byttepenge = det du giver minus prisen.", "kr", "penge"))

    # Kilopris, kroner og øre, eller rabat i procent
    if t["procent"]:
        fuld = random.choice([200, 240, 300, 400, 500])
        pct = random.choice([10, 25, 50])
        qs.append(_write("Far",
                         f"Grillen koster {fuld} kr, men der er {pct} % rabat i dag.\n"
                         f"Hvor mange kroner sparer vi?",
                         fuld * pct // 100,
                         f"{pct} % er {pct} ud af 100. Find først 1 %: {fuld} delt med 100.",
                         "kr", "penge"))
    elif t["decimal"]:
        kg_pris = random.choice([12.50, 14.50, 22.50])
        kg = random.choice([2, 4])
        qs.append(_write("Far",
                         f"Kartoflerne koster {kr(kg_pris)} kr pr. kilo, og vi skal bruge {kg} kilo.\n"
                         f"Hvad koster det?",
                         kg_pris * kg, "Gang kiloprisen med antal kilo — også ørerne.",
                         "kr", "gange"))
    elif t["gange"]:
        kg = random.choice([2, 3])
        kg_pris = random.choice([p for p in (10, 12, 15, 20, 24, 30)
                                 if p * kg <= t["gange_top"]] or [10])
        qs.append(_write("Far",
                         f"Kartoflerne koster {kg_pris} kr pr. kilo, og vi skal bruge {kg} kilo.\n"
                         f"Hvad koster det?",
                         kg_pris * kg, "Gang kiloprisen med antal kilo.", "kr", "gange"))
    else:
        haves, koster = _r(12, 20), _r(4, 11)
        qs.append(_write("Far",
                         f"Du har {haves} kr med, og mælken koster {koster} kr.\n"
                         f"Hvor meget har du tilbage bagefter?",
                         haves - koster, "Træk prisen fra det, du har.", "kr", "penge"))

    # Er tilbuddet en god idé
    if t["gange"]:
        # 2. klasse har mødt 2-, 5- og 10-tabellen, ikke 3-tabellen – så der
        # står "2 for" i stedet for "3 for" på det trin.
        pakke = 3 if 3 in t["tabeller"] else 2
        stk_pris = random.choice([6, 8, 9])
        tilbud = stk_pris * pakke - random.choice([3, 4, 5])
        qs.append(_choice("Far",
                          f"Yoghurt koster {stk_pris} kr stykket, men der er tilbud:\n"
                          f"{pakke} for {tilbud} kr. Hvad er billigst, hvis vi skal have {pakke}?",
                          [f"{pakke} stykker enkeltvis",
                           f"Tilbuddet: {pakke} for {tilbud} kr",
                           "Det koster det samme"], 1,
                          f"Regn {stk_pris} gange {pakke}, og sammenlign med {tilbud}.",
                          "penge"))
    else:
        a, b = random.choice([(7, 9), (6, 8), (9, 12)])
        qs.append(_choice("Far",
                          f"Den lille pose koster {a} kr, og den store koster {b} kr.\n"
                          f"Hvor meget dyrere er den store?",
                          [f"{b - a} kr", f"{a} kr", f"{a + b} kr"], 0,
                          f"Træk {a} fra {b}.", "penge"))
    return qs


# --- 4. ANALYSÉR: skolegården med Oskar ---------------------------------

def analyser(t):
    qs = []

    # Talrækken på fliserne
    # Rækken må ikke løbe ud over trinnets talområde: fem tal med spring på
    # 10 ender i 40'erne, og det er over stregen i 1. klasse.
    # Rækken er fem tal lang, så springet skal kunne være der fire gange
    # inden for trinnets talområde. Ellers ender 1. klasse på 42.
    top = t["sum"] if t["klasse"] <= 2 else t["hi"]
    step = _spring(t, top)
    hoejst_start = max(2, min(9 if t["klasse"] <= 3 else 40, top - 4 * step))
    start = _r(2, hoejst_start)
    seq = [start + i * step for i in range(5)]
    blank = random.choice([3, 4])
    shown = list(seq)
    answer = seq[blank]
    shown[blank] = None
    qs.append(_sequence("Oskar",
                        "Kig på fliserne – der står tal på dem hele vejen hen.\n"
                        "Hvilket tal mangler?",
                        shown, answer,
                        "Find ud af, hvor meget der lægges til hver gang."))

    # Dobbelt så mange
    maal = _r(2, 5) if t["klasse"] <= 2 else _r(4, 12)
    qs.append(_write("Oskar",
                     f"Vi scorede {maal} mål før pausen og dobbelt så mange efter.\n"
                     f"Hvor mange blev det i alt?",
                     maal * 3, "Find først anden halvleg, og læg så sammen.",
                     "mål", "gange" if t["gange"] else "plus"))

    # Hold – eller halvdelen, hvis division ikke er mødt endnu
    if t["division"]:
        # holdene skal være til at stille op i en skolegård: tre til fem hold
        # og et antal i klassen, der ligner en klasse
        hold = random.choice([3, 4, 5]) if 3 in t["tabeller"] else 2
        spillere = hold * _pr_gruppe(t, hold, 2, 6)
        qs.append(_write("Oskar",
                         f"Vi er {spillere} i klassen og skal deles i {hold} lige store hold.\n"
                         f"Hvor mange er der på hvert hold?",
                         spillere // hold, f"Del {spillere} med {hold}.", "stk", "division"))
    else:
        spillere = random.choice([8, 10, 12, 14])
        qs.append(_write("Oskar",
                         f"Vi er {spillere} og skal være to lige store hold.\n"
                         f"Hvor mange er der på hvert hold?",
                         spillere // 2, "To lige store hold er halvdelen til hver.",
                         "stk", "halve"))

    # Find alle
    if t["gange"]:
        target = random.choice([12, 16, 18, 20, 24]) if t["klasse"] <= 3 \
            else random.choice([24, 30, 36, 42])
    else:
        target = random.choice([10, 12, 14, 16])
    qs.append(_findall("Oskar",
                       f"Se her – jeg har skrevet regnestykker over hele bordet.\n"
                       f"Find alle dem, der giver {target}.",
                       target, "Regn hvert stykke ud, og sammenlign med tallet.", t))

    # Areal, negative tal eller cykelstativet
    if t["areal"] and random.random() < .6:
        laengde, bredde = _r(7, 12), _r(3, 6)
        if t["klasse"] >= 6 and random.random() < .5:
            qs.append(_write("Oskar",
                             f"Det skrå bed ved muren er en trekant: {laengde} m langs muren\n"
                             f"og {bredde} m ud. Hvor stort er arealet?",
                             laengde * bredde / 2,
                             "Areal af en trekant: grundlinje gange højde, delt med 2.",
                             "m²", "areal"))
        else:
            qs.append(_write("Oskar",
                             f"Boldbanen er {laengde} m lang og {bredde} m bred.\n"
                             f"Hvor stort er arealet?",
                             laengde * bredde, "Areal: længden gange bredden.",
                             "m²", "areal"))
    elif t["negative"]:
        morgen = -_r(2, 9)
        stigning = _r(5, 14)
        qs.append(_write("Oskar",
                         f"Der var {morgen} grader i morges, og nu er det steget {stigning} grader.\n"
                         f"Hvor mange grader er der nu?",
                         morgen + stigning,
                         "Tæl op ad tallinjen fra minus og forbi nul.", "grader", "plus"))
    elif t["gange"]:
        raekker = _r(3, 6)
        pr = _pr_gruppe(t, raekker, 4, 8)
        qs.append(_write("Oskar",
                         f"Der står {raekker} rækker med {pr} cykler i stativet.\n"
                         f"Hvis en hel række kører hjem, hvor mange står der så?",
                         raekker * pr - pr,
                         f"Regn {raekker} gange {pr}, og træk én række fra.", "stk", "gange"))
    else:
        cykler, hjem = _r(12, 18), _r(3, 6)
        qs.append(_write("Oskar",
                         f"Der står {cykler} cykler i stativet, og {hjem} af dem kører hjem.\n"
                         f"Hvor mange står der så?",
                         cykler - hjem, "Træk dem, der kører hjem, fra.", "stk", "plus"))
    return qs


# --- 5. VURDÉR: kantinen ------------------------------------------------

def vurder(t):
    qs = []

    # Er lektien rigtig?
    if t["gange"]:
        a, b = _gang_par(t, min(100, regneloft(t)))
        rigtigt = random.random() < 0.5
        vist = a * b if rigtigt else a * b + random.choice([-2, -1, 1, 2])
        qs.append(_truefalse("Oskar",
                             "Jeg har lavet lektier i frikvarteret. Er den her rigtig?",
                             f"{a} x {b} = {vist}", rigtigt,
                             f"Regn {a} gange {b} selv, og sammenlign."))
    else:
        a, b = _r(5, 9), _r(4, 9)
        rigtigt = random.random() < 0.5
        vist = a + b if rigtigt else a + b + random.choice([-2, -1, 1, 2])
        qs.append(_truefalse("Oskar",
                             "Jeg har lavet lektier i frikvarteret. Er den her rigtig?",
                             f"{a} + {b} = {vist}", rigtigt,
                             f"Læg {a} og {b} sammen selv, og sammenlign."))

    # Ret fejlen
    x = max(8, _tal(t, .6))
    y = _r(2, min(19, x - 2))
    qs.append(_write("Oskar",
                     f"Og her har jeg skrevet {x} - {y} = {(x - y) + random.choice([-2, -1, 1, 2])}.\n"
                     f"Den tror jeg ikke på. Hvad skal der stå?",
                     x - y, "Regn det selv, og sammenlign med det, der står.", "", "tjek"))

    # Hvad er billigst - eller hvad er gennemsnittet
    if t["gennemsnit"] and random.random() < .5:
        dage = [_r(10, 40) for _ in range(4)]
        while sum(dage) % 4 != 0:
            dage[0] += 1
        qs.append(_write("Emma",
                         "Vi har talt, hvor mange der spiser i kantinen:\n"
                         f"{dage[0]}, {dage[1]}, {dage[2]} og {dage[3]}.\n"
                         "Hvad er gennemsnittet?",
                         sum(dage) // 4,
                         "Læg dem sammen, og del med hvor mange tal der er.", "", "tjek"))
    elif t["division"]:
        pris_a = random.choice([12, 16])
        pris_b = round(pris_a / 4 * 6) + random.choice([-3, -2, 2, 3])
        qs.append(_choice("Emma",
                          f"I kiosken: 4 boller for {pris_a} kr, eller 6 boller for {pris_b} kr.\n"
                          f"Hvor er prisen pr. bolle lavest?",
                          [f"4 for {pris_a} kr", f"6 for {pris_b} kr", "De er lige gode"],
                          0 if pris_a / 4 < pris_b / 6 else 1,
                          "Regn ud, hvad ÉN bolle koster hvert sted.", "penge"))
    else:
        a, b = random.choice([(6, 9), (7, 10), (5, 8)])
        qs.append(_choice("Emma",
                          f"Den ene bolle koster {a} kr, den anden {b} kr.\n"
                          f"Hvor meget koster de to tilsammen?",
                          [f"{a + b} kr", f"{b - a} kr", f"{a + b + 2} kr"], 0,
                          f"Læg {a} og {b} sammen.", "penge"))

    # Passer delingen?
    stykker = random.choice([8, 12]) if t["klasse"] <= 3 else random.choice([12, 16, 24])
    folk = random.choice([2, 4]) if t["division"] else 2
    rigtigt2 = random.random() < 0.5
    vist2 = stykker // folk if rigtigt2 else stykker // folk + random.choice([-1, 1, 2])
    if t["division"]:
        paastand = f"{stykker} : {folk} = {vist2}"
        hjaelp = f"Del {stykker} ligeligt mellem {folk}, og se efter."
    else:
        paastand = f"Halvdelen af {stykker} er {vist2}"
        hjaelp = f"Læg {stykker} i to lige store bunker, og tæl den ene."
    qs.append(_truefalse("Emma",
                         f"Pizzaen er skåret i {stykker} stykker, og vi er {folk}.\n"
                         f"Oskar siger, vi får {vist2} stykker hver. Passer det?",
                         paastand, rigtigt2, hjaelp))

    # Byg en quiz
    if t["gange"]:
        target = random.choice([14, 18, 21, 27]) if t["klasse"] <= 3 \
            else random.choice([27, 32, 36, 45])
    else:
        target = random.choice([11, 13, 15, 17])
    qs.append(_findall("Emma",
                       f"Vi laver en quiz til de andre. Find alle de regnestykker,\n"
                       f"der giver {target} – så bruger vi dem.",
                       target, "Tjek hvert stykke grundigt, også dem der ligner.", t))
    return qs


# --- 6. SKAB: fremlæggelsen for Hr. Poulsen -----------------------------

def boss(t):
    qs = []

    # Klassekassen
    if t["gange"]:
        # Klassekassen skal blive inden for trinnets talområde: 25 elever
        # med 60 kr hver er 1500 kr, og det er over stregen i 3. klasse.
        elever = random.choice([10, 20]) if t["klasse"] <= 3 else random.choice([20, 24, 25])
        loft = max(2, t["gange_top"] // elever)
        pris = max(p for p in [2, 5, 10, 20, 25, 35, 45, 60] if p <= loft)
        qs.append(_write("Hr. Poulsen",
                         f"Klassekassen: hver elev lægger {pris} kr, og vi er {elever} i klassen.\n"
                         f"Hvor mange kroner har vi så?",
                         pris * elever, f"{pris} kr gange {elever} elever.", "kr", "gange"))
        total = pris * elever
    else:
        laagt, mangler = _r(6, 14), _r(2, 5)
        qs.append(_write("Hr. Poulsen",
                         f"Der ligger {laagt} kr i klassekassen, og vi mangler {mangler} kr\n"
                         f"til isene. Hvor mange kroner skal der være i alt?",
                         laagt + mangler, "Læg det, der mangler, til det, I har.",
                         "kr", "plus"))
        total = laagt + mangler

    # Hvad er der tilbage
    bus = round(total * 0.6 / 10) * 10 if total >= 50 else total // 2
    qs.append(_write("Hr. Poulsen",
                     f"Bussen til udflugten koster {bus} kr af vores {total} kr.\n"
                     f"Hvor meget er der tilbage til mad?",
                     total - bus, "Træk busprisen fra det samlede beløb.", "kr", "penge"))

    # Del opgavearkene
    if t["division"]:
        grupper = random.choice([3, 4])
        pr_gruppe = _pr_gruppe(t, grupper, 5, 8)
        qs.append(_balance("Hr. Poulsen",
                           f"Vi har {grupper * pr_gruppe} opgaveark, som skal deles ligeligt\n"
                           f"mellem {grupper} grupper. Hvor mange ark til hver gruppe?",
                           grupper, "x", pr_gruppe,
                           f"Del {grupper * pr_gruppe} med {grupper}.", "division"))
    else:
        ark, brugt = random.choice([16, 18, 20]), _r(4, 9)
        qs.append(_write("Hr. Poulsen",
                         f"Vi har {ark} opgaveark, og {brugt} af dem er brugt.\n"
                         f"Hvor mange er der tilbage?",
                         ark - brugt, "Træk de brugte fra.", "stk", "plus"))

    # Tavlen – eller en ligning i 6. klasse
    if t["ligning"]:
        x = _r(4, 12)
        a = _fak(t, 3, 9)
        qs.append(_write("Hr. Poulsen",
                         f"Der står stadig noget på tavlen fra i går: {a} · x = {a * x}.\n"
                         f"Hvad er x?",
                         x, f"Hvad skal {a} ganges med for at give {a * x}?", "", "raekkefolge"))
    elif t["gange"]:
        a, b = _gang_par(t, min(100, regneloft(t)))
        rigtigt = random.random() < 0.5
        vist = a * b if rigtigt else a * b + random.choice([-3, 3])
        qs.append(_truefalse("Hr. Poulsen",
                             "Der står stadig noget på tavlen fra i går. Holder det?",
                             f"{a} x {b} = {vist}", rigtigt,
                             f"Regn {a} gange {b} omhyggeligt."))
    else:
        a, b = _r(6, 12), _r(4, 8)
        rigtigt = random.random() < 0.5
        vist = a + b if rigtigt else a + b + random.choice([-2, 2])
        qs.append(_truefalse("Hr. Poulsen",
                             "Der står stadig noget på tavlen fra i går. Holder det?",
                             f"{a} + {b} = {vist}", rigtigt,
                             f"Læg {a} og {b} sammen omhyggeligt."))

    # Byg selv
    for _ in range(2):
        p = make_creative(t)
        nums = ", ".join(str(n) for n in p["numbers"])
        hjaelp = ("Husk: gange og dividere regnes før plus og minus."
                  if t["hierarki"] else "Prøv dig frem – regn fra venstre mod højre.")
        qs.append(_build("Hr. Poulsen",
                         f"Og så den sidste, som er din egen.\n"
                         f"Byg et regnestykke, der giver {p['target']}, med tallene {nums}\n"
                         f"– hvert tal én gang – og "
                         + ("mindst én regneart." if p["min_ops"] < 2
                            else f"mindst {p['min_ops']} forskellige regnearter."),
                         p, hjaelp))
    return qs


ENCOUNTERS = {
    "husk": {"bloom": "HUSK", "gen": husk},
    "forstaa": {"bloom": "FORSTÅ", "gen": forstaa},
    "anvend": {"bloom": "ANVEND", "gen": anvend},
    "analyser": {"bloom": "ANALYSÉR", "gen": analyser},
    "vurder": {"bloom": "VURDÉR", "gen": vurder},
    "boss": {"bloom": "SKAB", "gen": boss},
}

BLOOM_ORDER = ["HUSK", "FORSTÅ", "ANVEND", "ANALYSÉR", "VURDÉR", "SKAB"]

# Kan-mål i elevplan-sprog – vises til sidst i stedet for en karakter.
CAN_STATEMENTS = [
    ("HUSK", "Jeg kan mine tal-fakta uden at tælle på fingre"),
    ("FORSTÅ", "Jeg kan forstå, hvad en opgave spørger om"),
    ("ANVEND", "Jeg kan bruge matematik, når jeg handler ind"),
    ("ANALYSÉR", "Jeg kan finde mønstre og regne i flere trin"),
    ("VURDÉR", "Jeg kan tjekke, om et svar er rigtigt"),
    ("SKAB", "Jeg kan selv bygge et regnestykke"),
]


# --- Sidequests ---------------------------------------------------------
# Korte opgaver (3 stk) hos folk rundt omkring i verdenen. De er frivillige,
# og man får en ting i tasken, hvis man rammer mindst 85 % i første forsøg.

def sq_kiosk(t):
    pris = _beloeb(t, .15, 60)
    # regningen, der skal deles, skal blive under trinnets deleloft – ellers
    # står en elev i 3. klasse med 172 delt med 4
    antal = max(2, min(4, t["del_top"] // max(1, pris)))
    if t["division"]:
        anden = _write("Kioskmanden",
                       f"Og hvis I er {antal} om at dele regningen på {pris * antal} kr –\n"
                       f"hvor meget skal hver især give?",
                       pris, f"Del {pris * antal} med {antal}.", "kr", "division")
    else:
        anden = _write("Kioskmanden",
                       f"Og hvis I er to om at dele regningen på {pris * 2} kr –\n"
                       f"hvor meget skal hver især give?",
                       pris, "Halvdelen af beløbet til hver.", "kr", "halve")
    loft = regneloft(t)
    stk = random.choice([s for s in (4, 6, 7) if s * 3 <= loft] or [3]) \
        if t["gange"] else random.choice([s for s in (4, 5, 6) if s * 3 <= loft] or [3])
    return [
        _coins("Kioskmanden",
               f"Så er det {pris} kr for isen. Har du lige pengene?\n"
               f"Jeg er løbet tør for byttepenge i dag.",
               pris, "Tag de store mønter først, og fyld op med de små."),
        anden,
        _findall("Kioskmanden",
                 f"Jeg skal have prismærker på. Hvilke af dem her giver {stk * 3}?",
                 stk * 3, "Regn hvert stykke ud, ét ad gangen.", t),
    ]


def sq_bibliotek(t):
    hylder = random.choice([4, 5, 6])
    pr = _pr_gruppe(t, hylder, 4, 9) if t["gange"] else _r(3, 6)
    top = t["sum"] if t["klasse"] <= 2 else t["hi"]
    step = _spring(t, top)
    start = _r(2, max(2, min(9, top - 4 * step)))
    seq_vals = [start + i * step for i in range(5)]
    blank = random.choice([2, 3])
    shown = list(seq_vals)
    answer = seq_vals[blank]
    shown[blank] = None

    if t["gange"]:
        foerste = _write("Bibliotekaren",
                         f"Der skal stå {pr} bøger på hver af de {hylder} hylder.\n"
                         f"Hvor mange bøger skal jeg hente?",
                         hylder * pr, f"{pr} gange {hylder}.", "stk", "gange")
        sidste = _write("Bibliotekaren",
                        f"{hylder * pr} bøger skal deles ligeligt i {hylder} kasser.\n"
                        f"Hvor mange kommer der i hver kasse?",
                        pr, f"Del {hylder * pr} med {hylder}.", "stk", "division")
    else:
        paa_hylde, i_kasse = _r(6, 12), _r(3, 8)
        foerste = _write("Bibliotekaren",
                         f"Der står {paa_hylde} bøger på hylden, og jeg sætter {i_kasse} mere op.\n"
                         f"Hvor mange står der så?",
                         paa_hylde + i_kasse, "Læg de to tal sammen.", "stk", "plus")
        sidste = _write("Bibliotekaren",
                        f"Der er {paa_hylde + i_kasse} bøger, og {i_kasse} bliver lånt ud.\n"
                        f"Hvor mange er tilbage?",
                        paa_hylde, "Træk de udlånte fra.", "stk", "plus")
    return [
        foerste,
        _sequence("Bibliotekaren",
                  "Bognumrene på reolen står i en fast rækkefølge.\n"
                  "Hvilket nummer mangler?",
                  shown, answer, "Se, hvor meget numrene stiger hver gang."),
        sidste,
    ]


def sq_park_barn(t):
    slik = random.choice([12, 16, 20])
    venner = random.choice([2, 4]) if t["division"] else 2
    paastand_rigtig = random.random() < 0.5
    naevner = 4 if t["fjerdedele"] else 2
    vist = slik // naevner if paastand_rigtig else slik // naevner + 1
    return [
        _write("Viggo",
               f"Jeg har {slik} vingummier, og vi er {venner}.\n"
               f"Hvor mange får vi hver, hvis vi deler lige?",
               slik // venner,
               f"Del {slik} med {venner}." if venner > 2 else "Halvdelen til hver.",
               "stk", "division" if venner > 2 else "halve"),
        _write("Viggo",
               f"Hvis jeg giver halvdelen af mine {slik} væk,\n"
               f"hvor mange har jeg så tilbage?",
               slik // 2,
               "Halvdelen betyder delt med 2." if t["division"]
               else "Halvdelen er lige så mange i to bunker.", "stk", "halve"),
        _truefalse("Viggo",
                   "Min storebror siger, det her passer. Gør det?",
                   f"{slik} : {naevner} = {vist}" if t["division"]
                   else f"Halvdelen af {slik} er {vist}", paastand_rigtig,
                   "Regn det selv, og se efter."),
    ]


def sq_hund(t):
    ture = random.choice([3, 4, 5])
    if t["gange"]:
        min_pr = random.choice([m for m in (5, 10, 15, 20)
                                if m * ture <= t["gange_top"]] or [5])
    else:
        min_pr = random.choice([5, 10])
    if t["gange"]:
        foerste = _write("Hundelufteren",
                         f"Jeg går {ture} ture om dagen, og hver tur tager {min_pr} minutter.\n"
                         f"Hvor mange minutter bliver det i alt?",
                         ture * min_pr, f"{min_pr} gange {ture}.", "min", "gange")
        anden = _balance("Hundelufteren",
                         f"På en uge går jeg {ture * 7} ture.\n"
                         f"Hvor mange dage er der gået, når jeg har gået {ture * 4} ture?",
                         ture, "x", 4, f"Hvor mange gange går {ture} op i {ture * 4}?",
                         "division")
        tredje = _choice("Hundelufteren",
                         f"Hunden vejede {random.choice([8, 12, 16])} kg sidste år\n"
                         f"og vejer det dobbelte nu. Hvad skal jeg regne?",
                         ["Lægge 2 til", "Gange med 2", "Dividere med 2", "Trække 2 fra"], 1,
                         "Dobbelt så meget betyder gange med 2.", "gange")
    else:
        foerste = _write("Hundelufteren",
                         f"Turen om formiddagen tog {min_pr} minutter, og turen om eftermiddagen\n"
                         f"tog {min_pr} minutter. Hvor mange minutter blev det?",
                         min_pr * 2, f"Læg {min_pr} og {min_pr} sammen.", "min", "plus")
        anden = _write("Hundelufteren",
                       f"Jeg skulle gå {ture + 3} ture i dag, og jeg har gået {ture}.\n"
                       f"Hvor mange mangler jeg?",
                       3, "Træk dem, du har gået, fra dem, du skulle.", "stk", "plus")
        tredje = _choice("Hundelufteren",
                         f"Hunden vejede {random.choice([8, 10, 12])} kg sidste år\n"
                         f"og vejer det dobbelte nu. Hvad skal jeg regne?",
                         ["Lægge det samme til én gang til", "Trække 2 fra",
                          "Dele med 2"], 0,
                         "Dobbelt så meget er det samme lagt til én gang til.", "plus")
    return [foerste, anden, tredje]


def sq_pedel(t):
    raekker = random.choice([4, 5, 6])
    pr = _pr_gruppe(t, raekker, 5, 8) if t["gange"] else _r(3, 6)
    tilovers = random.choice([4, 6, 8])
    if t["gange"]:
        foerste = _write("Pedellen",
                         f"Der skal stilles {raekker} rækker med {pr} stole til morgensang.\n"
                         f"Hvor mange stole skal jeg hente?",
                         raekker * pr, f"{raekker} gange {pr}.", "stk", "gange")
        i_alt = raekker * pr
    else:
        stillet, mangler = _r(8, 14), _r(3, 6)
        foerste = _write("Pedellen",
                         f"Jeg har stillet {stillet} stole op, og der mangler {mangler}.\n"
                         f"Hvor mange skal der være i alt?",
                         stillet + mangler, "Læg det, der mangler, til.", "stk", "plus")
        i_alt = stillet + mangler
    maal = i_alt // 2 if i_alt // 2 > 3 else i_alt
    return [
        foerste,
        _write("Pedellen",
               f"Vi har {i_alt + tilovers} stole i alt.\n"
               f"Hvor mange bliver der tilovers, når jeg har stillet {i_alt} op?",
               tilovers, "Træk det opstillede fra det samlede antal.", "stk", "plus"),
        _findall("Pedellen",
                 f"Jeg har kridtet tal på gulvet. Hvilke giver {maal}?",
                 maal, "Regn dem igennem ét ad gangen.", t),
    ]


def sq_sport(t):
    maal = random.choice([3, 4, 5])
    kampe = random.choice([k for k in (4, 6) if k * 5 <= t["gange_top"]] or [4])
    if t["gange"]:
        foerste = _write("Sportslæreren",
                         f"Holdet har scoret {maal} mål i hver af de {kampe} kampe.\n"
                         f"Hvor mange mål er det i alt?",
                         maal * kampe, f"{maal} gange {kampe}.", "mål", "gange")
        anden = _write("Sportslæreren",
                       f"Vi skal dele {kampe * 4} spillere i {kampe // 2} lige store hold.\n"
                       f"Hvor mange på hvert hold?",
                       (kampe * 4) // (kampe // 2), f"Del {kampe * 4} med {kampe // 2}.",
                       "stk", "division")
        tredje = _truefalse("Sportslæreren",
                            "En elev har regnet målscoren sammen. Passer det?",
                            f"{maal} x {kampe} = {maal * kampe}", True,
                            f"Regn {maal} gange {kampe} efter.")
    else:
        foerste = _write("Sportslæreren",
                         f"Vi scorede {maal} mål i første kamp og {maal + 2} i anden.\n"
                         f"Hvor mange mål blev det i alt?",
                         maal * 2 + 2, f"Læg {maal} og {maal + 2} sammen.", "mål", "plus")
        anden = _write("Sportslæreren",
                       f"Vi er {kampe * 2} spillere og skal være to lige store hold.\n"
                       f"Hvor mange på hvert hold?",
                       kampe, "To lige store hold er halvdelen til hver.", "stk", "halve")
        tredje = _truefalse("Sportslæreren",
                            "En elev har regnet målscoren sammen. Passer det?",
                            f"{maal} + {maal + 2} = {maal * 2 + 2}", True,
                            f"Læg {maal} og {maal + 2} sammen efter.")
    return [foerste, anden, tredje]


SIDE_ENCOUNTERS = {
    "sq_kiosk": {"bloom": "ANVEND", "gen": sq_kiosk},
    "sq_bibliotek": {"bloom": "ANALYSÉR", "gen": sq_bibliotek},
    "sq_park_barn": {"bloom": "FORSTÅ", "gen": sq_park_barn},
    "sq_hund": {"bloom": "ANVEND", "gen": sq_hund},
    "sq_pedel": {"bloom": "HUSK", "gen": sq_pedel},
    "sq_sport": {"bloom": "ANALYSÉR", "gen": sq_sport},
}

ENCOUNTERS.update(SIDE_ENCOUNTERS)

# Hvilken ting man får, hvis man rammer mindst 85 % i første forsøg.
REWARD_PCT = 0.85

REWARDS = {
    "husk": "guldmoent",
    "forstaa": "toejpose",      # låser klæd-om op
    "anvend": "is",
    "analyser": "fodbold",      # låser fodbold op
    "vurder": "kridt",
    "boss": "pokal",
    "sq_kiosk": "slik",
    "sq_bibliotek": "bog",
    "sq_park_barn": "toejpose",
    "sq_hund": "hundeben",
    "sq_pedel": "noegle",
    "sq_sport": "fodbold",
}
