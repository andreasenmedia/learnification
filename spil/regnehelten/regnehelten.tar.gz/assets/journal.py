"""
Regnebogen – en gammel, slidt matematikbog man kan slå op i når som helst,
også midt i en opgave. Hver side forklarer én type regnestykke med et
eksempel og en lille tegning.
"""

import pygame

import ui

PAPER = (238, 228, 199)
PAPER_DARK = (222, 209, 172)
PAPER_EDGE = (198, 182, 142)
BOOK_CLOTH = (108, 68, 58)
BOOK_CLOTH_DARK = (78, 46, 40)
INK = (58, 44, 34)
INK_FADED = (122, 104, 82)
RED_INK = (168, 72, 58)
BLUE_INK = (62, 86, 142)

_SERIF = ["Georgia", "Cambria", "Book Antiqua", "Times New Roman", "DejaVu Serif"]
_cache = {}


def serif(size, bold=False, italic=False):
    key = (size, bold, italic)
    if key not in _cache:
        f = None
        for face in _SERIF:
            try:
                f = pygame.font.SysFont(face, size, bold=bold, italic=italic)
                if f:
                    break
            except Exception:
                continue
        _cache[key] = f or pygame.font.Font(None, size)
    return _cache[key]


def _wrap(text, font, width):
    lines = []
    for para in text.split("\n"):
        if not para:
            lines.append("")
            continue
        cur = ""
        for word in para.split(" "):
            trial = word if not cur else cur + " " + word
            if font.size(trial)[0] <= width:
                cur = trial
            else:
                if cur:
                    lines.append(cur)
                cur = word
        if cur:
            lines.append(cur)
    return lines


# --- Tegninger i bogen ---------------------------------------------------

def _d_numberline(s, r):
    y = r.centery + 10
    pygame.draw.line(s, INK, (r.x + 10, y), (r.right - 10, y), 2)
    step = (r.w - 20) / 10
    for i in range(11):
        x = r.x + 10 + i * step
        pygame.draw.line(s, INK, (x, y - 5), (x, y + 5), 2)
        f = serif(13)
        s.blit(f.render(str(i), True, INK_FADED), (x - 4, y + 8))
    for start, end, col in ((3, 7, RED_INK),):
        x0 = r.x + 10 + start * step
        x1 = r.x + 10 + end * step
        pygame.draw.arc(s, col, (x0, y - 34, x1 - x0, 60), 0.35, 2.79, 2)
        pygame.draw.polygon(s, col, [(x1, y - 6), (x1 - 6, y - 14), (x1 + 2, y - 15)])
        s.blit(serif(14, italic=True).render("+4", True, col), ((x0 + x1) / 2 - 10, y - 46))


def _d_array(s, r):
    rows, cols = 3, 4
    size, gap = 15, 8
    w = cols * (size + gap) - gap
    x0 = r.centerx - w // 2
    y0 = r.y + 16
    for row in range(rows):
        for col in range(cols):
            cx = x0 + col * (size + gap) + size // 2
            cy = y0 + row * (size + gap) + size // 2
            pygame.draw.circle(s, BLUE_INK, (cx, cy), size // 2)
            pygame.draw.circle(s, INK, (cx, cy), size // 2, 1)
    f = serif(15, italic=True)
    s.blit(f.render("3 rækker x 4 = 12", True, INK_FADED),
           (r.centerx - 62, y0 + rows * (size + gap) + 4))


def _d_share(s, r):
    f = serif(14, italic=True)
    x0, y0 = r.x + 20, r.y + 18
    for g in range(3):
        gx = x0 + g * 92
        pygame.draw.rect(s, PAPER_DARK, (gx, y0, 76, 40), border_radius=8)
        pygame.draw.rect(s, INK_FADED, (gx, y0, 76, 40), 1, border_radius=8)
        for i in range(4):
            cx = gx + 14 + (i % 2) * 24
            cy = y0 + 12 + (i // 2) * 18
            pygame.draw.circle(s, RED_INK, (cx, cy), 6)
    s.blit(f.render("12 delt i 3 bunker = 4 i hver", True, INK_FADED), (x0, y0 + 48))


def _d_half(s, r):
    w, h = 220, 46
    x0 = r.centerx - w // 2
    y0 = r.y + 18
    pygame.draw.rect(s, PAPER_DARK, (x0, y0, w, h))
    pygame.draw.rect(s, BLUE_INK, (x0, y0, w // 2, h))
    pygame.draw.rect(s, INK, (x0, y0, w, h), 2)
    pygame.draw.line(s, INK, (x0 + w // 2, y0), (x0 + w // 2, y0 + h), 2)
    f = serif(15, italic=True)
    s.blit(f.render("halvdelen", True, (250, 246, 236)), (x0 + 16, y0 + 13))
    s.blit(f.render("den anden halvdel", True, INK_FADED), (x0 + w // 2 + 10, y0 + 13))


def _d_coins(s, r):
    f = serif(15, bold=True)
    for i, (val, col) in enumerate([(1, (198, 186, 160)), (2, (198, 186, 160)),
                                    (5, (206, 176, 120)), (10, (186, 160, 120)),
                                    (20, (176, 148, 108))]):
        cx = r.x + 40 + i * 70
        cy = r.y + 40
        pygame.draw.circle(s, col, (cx, cy), 24)
        pygame.draw.circle(s, INK, (cx, cy), 24, 2)
        lab = f.render(str(val), True, INK)
        s.blit(lab, (cx - lab.get_width() // 2, cy - 10))
    s.blit(serif(14, italic=True).render("10 + 5 + 2 = 17 kr", True, INK_FADED),
           (r.x + 40, r.y + 74))


def _d_pattern(s, r):
    f = serif(19, bold=True)
    vals = ["3", "7", "11", "15", "?"]
    for i, v in enumerate(vals):
        x = r.x + 24 + i * 78
        y = r.y + 22
        pygame.draw.rect(s, PAPER_DARK, (x, y, 52, 44), border_radius=6)
        pygame.draw.rect(s, INK if v != "?" else RED_INK, (x, y, 52, 44), 2, border_radius=6)
        img = f.render(v, True, INK if v != "?" else RED_INK)
        s.blit(img, (x + 26 - img.get_width() // 2, y + 10))
        if i < len(vals) - 1:
            pygame.draw.line(s, BLUE_INK, (x + 56, y + 22), (x + 72, y + 22), 2)
            s.blit(serif(13, italic=True).render("+4", True, BLUE_INK), (x + 56, y - 2))


def _d_rect(s, r):
    w, h = 190, 70
    x0, y0 = r.centerx - w // 2, r.y + 20
    pygame.draw.rect(s, PAPER_DARK, (x0, y0, w, h))
    pygame.draw.rect(s, INK, (x0, y0, w, h), 2)
    f = serif(14, italic=True)
    s.blit(f.render("8 m", True, RED_INK), (x0 + w // 2 - 12, y0 - 18))
    s.blit(f.render("3 m", True, RED_INK), (x0 - 34, y0 + h // 2 - 8))
    s.blit(f.render("areal = 8 x 3 = 24", True, INK_FADED), (x0 + 22, y0 + h // 2 - 9))


def _d_order(s, r):
    f = serif(26, bold=True)
    txt = "2 + 3 x 4"
    img = f.render(txt, True, INK)
    x0 = r.centerx - img.get_width() // 2
    y0 = r.y + 20
    s.blit(img, (x0, y0))
    pygame.draw.ellipse(s, RED_INK, (x0 + 58, y0 - 4, 66, 42), 2)
    f2 = serif(15, italic=True)
    s.blit(f2.render("gange først: 3 x 4 = 12", True, RED_INK), (r.centerx - 80, y0 + 46))
    s.blit(f2.render("så plus: 2 + 12 = 14", True, INK_FADED), (r.centerx - 80, y0 + 68))


DIAGRAMS = {
    "numberline": _d_numberline, "array": _d_array, "share": _d_share,
    "half": _d_half, "coins": _d_coins, "pattern": _d_pattern,
    "rect": _d_rect, "order": _d_order,
}


# --- Sider ---------------------------------------------------------------

PAGES = [
    {
        "id": "plus", "title": "Plus og minus", "tag": "At lægge til og trække fra",
        "body": "Plus betyder, at der kommer noget til. Minus betyder, at noget "
                "går væk.\n\nEt trick: du kan altid tælle videre på en tallinje. "
                "Ved plus går du til højre, ved minus går du til venstre.",
        "example": "Du har 3 kr og får 4 kr mere.\n3 + 4 = 7 kr.",
        "diagram": "numberline",
    },
    {
        "id": "gange", "title": "Gangetabellen", "tag": "Mange lige store bunker",
        "body": "At gange er en hurtig måde at lægge det samme tal sammen "
                "mange gange.\n\n4 + 4 + 4 er det samme som 3 x 4.\n\nTricks: "
                "5-tabellen ender altid på 0 eller 5. 10-tabellen sætter bare "
                "et 0 bagpå. Og 2-tabellen er bare det dobbelte.",
        "example": "3 rækker med 4 æbler i hver:\n3 x 4 = 12 æbler.",
        "diagram": "array",
    },
    {
        "id": "division", "title": "Division", "tag": "At dele ligeligt",
        "body": "At dividere er at dele noget i lige store bunker.\n\nSpørg dig "
                "selv: hvor mange gange går det lille tal op i det store?\n\n"
                "Division og gange hører sammen. Hvis 3 x 4 = 12, så er "
                "12 : 3 = 4.",
        "example": "12 bolsjer skal deles mellem 3 børn.\n12 : 3 = 4 til hver.",
        "diagram": "share",
    },
    {
        "id": "halve", "title": "Halve og fjerdedele", "tag": "Dele af et tal",
        "body": "Halvdelen betyder delt i 2 lige store dele. En fjerdedel "
                "betyder delt i 4.\n\nDu finder halvdelen ved at dividere med 2, "
                "og en fjerdedel ved at dividere med 4.",
        "example": "Halvdelen af 18 er 18 : 2 = 9.\nEn fjerdedel af 20 er 20 : 4 = 5.",
        "diagram": "half",
    },
    {
        "id": "penge", "title": "Penge og byttepenge", "tag": "Når du handler",
        "body": "Når du køber flere ting, lægger du priserne sammen.\n\n"
                "Byttepenge er det, du får tilbage: tag det, du betalte med, "
                "og træk prisen fra.\n\nSkal du købe flere ens ting, kan du "
                "gange prisen med antallet.",
        "example": "Varer for 63 kr, du betaler med 100 kr.\n"
                   "100 - 63 = 37 kr tilbage.",
        "diagram": "coins",
    },
    {
        "id": "monstre", "title": "Mønstre og talrækker", "tag": "Hvad kommer så?",
        "body": "I en talrække sker der det samme hele vejen igennem.\n\n"
                "Find ud af, hvor meget der bliver lagt til (eller trukket fra) "
                "mellem to tal ved siden af hinanden. Tjek så, om det passer "
                "hele vejen. Så kan du regne det næste tal ud.",
        "example": "3, 7, 11, 15 ... Der lægges 4 til hver gang.\n"
                   "Næste tal: 15 + 4 = 19.",
        "diagram": "pattern",
    },
    {
        "id": "areal", "title": "Omkreds og areal", "tag": "Rundt om og indeni",
        "body": "Omkredsen er hele vejen rundt om kanten. Læg alle siderne "
                "sammen – eller tag (længde + bredde) og gang med 2.\n\n"
                "Arealet er, hvor meget der er indeni. Gang længden med bredden.",
        "example": "En mark er 8 m lang og 3 m bred.\n"
                   "Omkreds: (8 + 3) x 2 = 22 m.\nAreal: 8 x 3 = 24.",
        "diagram": "rect",
    },
    {
        "id": "raekkefolge", "title": "Hvad regner man først?", "tag": "Regnearternes orden",
        "body": "Man regner ikke altid fra venstre mod højre.\n\nFørst regner "
                "du det, der står i en parentes. Så gange og dividere. Til "
                "sidst plus og minus.\n\nDerfor er 2 + 3 x 4 ikke 20, men 14.",
        "example": "2 + 3 x 4  ->  3 x 4 = 12  ->  2 + 12 = 14.\n"
                   "Med parentes: (2 + 3) x 4 = 20.",
        "diagram": "order",
    },
    {
        "id": "tjek", "title": "Tjek dit svar", "tag": "Gode vaner",
        "body": "Et svar kan tjekkes. Det tager ti sekunder og redder mange "
                "fejl.\n\nRegn den anden vej: har du lagt sammen, så træk fra "
                "igen. Har du ganget, så divider tilbage.\n\nSpørg også: kan "
                "svaret overhovedet passe? Hvis du deler 12 mellem 3, kan svaret "
                "ikke være større end 12.",
        "example": "Du fik 47 + 26 = 73.\nTjek: 73 - 26 = 47. Det passer.",
        "diagram": None,
    },
]

PAGE_BY_ID = {p["id"]: i for i, p in enumerate(PAGES)}


class Journal:
    def __init__(self):
        self.open = False
        self.page = 0
        self.turn = 0.0

    def toggle(self, page_id=None):
        self.open = not self.open
        if self.open and page_id:
            self.goto(page_id)

    def goto(self, page_id):
        if page_id in PAGE_BY_ID:
            self.page = PAGE_BY_ID[page_id]

    def handle_event(self, e, audio=None):
        """Returnerer True hvis bogen lukkede."""
        if e.type != pygame.KEYDOWN:
            return False
        if e.key in (pygame.K_ESCAPE, pygame.K_j, pygame.K_b):
            self.open = False
            if audio:
                audio.back()
            return True
        if e.key in (pygame.K_LEFT, pygame.K_UP, pygame.K_PAGEUP):
            self.page = (self.page - 1) % len(PAGES)
            self.turn = 0.25
            if audio:
                audio.move()
        elif e.key in (pygame.K_RIGHT, pygame.K_DOWN, pygame.K_PAGEDOWN, pygame.K_SPACE):
            self.page = (self.page + 1) % len(PAGES)
            self.turn = 0.25
            if audio:
                audio.move()
        return False

    def update(self, dt):
        if self.turn > 0:
            self.turn -= dt

    def draw(self, surface):
        if not self.open:
            return
        w, h = surface.get_size()
        veil = pygame.Surface((w, h), pygame.SRCALPHA)
        veil.fill((20, 16, 12, 190))
        surface.blit(veil, (0, 0))

        book = pygame.Rect(w // 2 - 380, 40, 760, h - 96)
        # bogbind
        cloth = book.inflate(26, 26)
        pygame.draw.rect(surface, BOOK_CLOTH_DARK, cloth.move(5, 7), border_radius=10)
        pygame.draw.rect(surface, BOOK_CLOTH, cloth, border_radius=10)
        pygame.draw.rect(surface, BOOK_CLOTH_DARK, cloth, 3, border_radius=10)

        # papir
        pygame.draw.rect(surface, PAPER, book)
        pygame.draw.rect(surface, PAPER_EDGE, book, 2)
        # slidt kant + rygskygge
        shade = pygame.Surface((40, book.h), pygame.SRCALPHA)
        for i in range(40):
            a = int(60 * (1 - i / 40))
            pygame.draw.line(shade, (120, 96, 60, a), (i, 0), (i, book.h))
        surface.blit(shade, (book.x, book.y))

        p = PAGES[self.page]
        x = book.x + 56
        width = book.w - 104

        body_lines = _wrap(p["body"], serif(19), width)
        for i in range(len(body_lines) + 1):
            ly = book.y + 122 + i * 26
            pygame.draw.line(surface, (216, 204, 172), (x - 2, ly), (book.right - 40, ly), 1)

        surface.blit(serif(31, bold=True).render(p["title"], True, INK), (x, book.y + 30))
        surface.blit(serif(16, italic=True).render(p["tag"], True, INK_FADED), (x, book.y + 70))
        pygame.draw.line(surface, INK_FADED, (x, book.y + 92), (book.right - 40, book.y + 92), 1)

        f = serif(19)
        y = book.y + 104
        for line in body_lines:
            if line:
                surface.blit(f.render(line, True, INK), (x, y))
            y += 26

        # eksempelkasse
        y += 8
        ex_lines = p["example"].split("\n")
        box = pygame.Rect(x, y, width, 30 + len(ex_lines) * 26)
        pygame.draw.rect(surface, PAPER_DARK, box, border_radius=6)
        pygame.draw.rect(surface, INK_FADED, box, 1, border_radius=6)
        surface.blit(serif(14, bold=True).render("EKSEMPEL", True, RED_INK),
                     (box.x + 14, box.y + 8))
        for i, line in enumerate(ex_lines):
            surface.blit(serif(19, italic=True).render(line, True, INK),
                         (box.x + 14, box.y + 28 + i * 26))
        y = box.bottom + 10

        if p["diagram"] and y < book.bottom - 130:
            drect = pygame.Rect(x, y, width, min(120, book.bottom - y - 46))
            DIAGRAMS[p["diagram"]](surface, drect)

        # sidefod
        foot = f"side {self.page + 1} af {len(PAGES)}"
        img = serif(15, italic=True).render(foot, True, INK_FADED)
        surface.blit(img, (book.centerx - img.get_width() // 2, book.bottom - 32))
        hint_text = ("tryk på siden for at bladre     Luk: luk bogen" if ui.TOUCH
                     else "piletaster: bladr     J eller Esc: luk bogen")
        hint = serif(15).render(hint_text, True, INK_FADED)
        surface.blit(hint, (book.centerx - hint.get_width() // 2, book.bottom - 56))
