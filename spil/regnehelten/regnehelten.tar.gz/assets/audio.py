"""
Bloede, daempede lyde genereret i kode (sinus + envelope i stedet for
skarpe firkantboelger). Master-volumen er lav, og M slaar lyd fra.
"""

import math
import sys
from array import array

import pygame

RATE = 22050
# Browseren har brug for en større lydbuffer end en pc, ellers knitrer det.
BUFFER = 1024 if sys.platform == "emscripten" else 256


class Audio:
    def __init__(self, master=0.30):
        self.ok = False
        self.master = master
        self.muted = False
        self._cache = {}
        try:
            pygame.mixer.pre_init(RATE, -16, 1, BUFFER)
            pygame.mixer.init()
            pygame.mixer.set_num_channels(8)
            self.ok = True
        except Exception:
            self.ok = False

    def _tone(self, freq, ms, vol, harmonic=0.25, attack=0.02, release=0.6):
        key = (round(freq, 1), ms, round(vol, 3), harmonic)
        if key in self._cache:
            return self._cache[key]
        n = int(RATE * ms / 1000)
        buf = array("h")
        amp = 32767 * vol
        a_n = max(1, int(n * attack))
        r_n = max(1, int(n * release))
        two_pi_f = 2 * math.pi * freq
        for i in range(n):
            t = i / RATE
            # grundtone + let overtone giver en blødere klang end firkant
            v = math.sin(two_pi_f * t) + harmonic * math.sin(two_pi_f * 2 * t)
            v /= (1 + harmonic)
            if i < a_n:
                env = i / a_n
            elif i > n - r_n:
                env = (n - i) / r_n
            else:
                env = 1.0
            env *= env
            buf.append(int(max(-32767, min(32767, amp * v * env))))
        try:
            snd = pygame.mixer.Sound(buffer=buf.tobytes())
        except pygame.error:
            snd = None
        self._cache[key] = snd
        return snd

    def _play(self, freq, ms, vol, harmonic=0.25):
        if not self.ok or self.muted:
            return
        snd = self._tone(freq, ms, vol * self.master, harmonic)
        if snd:
            ch = pygame.mixer.find_channel(True)
            if ch:
                ch.play(snd)

    def _sequence(self, notes, gap=0.0):
        """notes: [(freq, ms, vol)] - spilles med lille forskydning."""
        if not self.ok or self.muted:
            return
        delay = 0
        for freq, ms, vol in notes:
            snd = self._tone(freq, ms, vol * self.master)
            if snd:
                ch = pygame.mixer.find_channel(True)
                if ch:
                    if delay:
                        pygame.time.set_timer(pygame.USEREVENT, 0)
                    ch.play(snd)
            delay += ms

    def move(self):
        self._play(320, 45, 0.10, harmonic=0.1)

    def select(self):
        self._play(520, 60, 0.13, harmonic=0.15)

    def back(self):
        self._play(300, 70, 0.12)

    def talk(self):
        self._play(420, 35, 0.06, harmonic=0.1)

    def correct(self):
        for i, f in enumerate((523.25, 659.25, 783.99)):
            self._play(f, 180 + i * 40, 0.16)

    def wrong(self):
        self._play(196, 200, 0.14, harmonic=0.4)
        self._play(147, 260, 0.12, harmonic=0.4)

    def levelup(self):
        for f in (523.25, 622.25, 783.99, 1046.5):
            self._play(f, 260, 0.15)

    def fanfare(self):
        for f in (523.25, 659.25, 783.99, 1046.5, 1318.5):
            self._play(f, 420, 0.16)

    def toggle_mute(self):
        self.muted = not self.muted
        if not self.muted:
            self.select()
        return self.muted
