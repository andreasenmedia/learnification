"""
Pausespil uden matematik.

De koster en spilletur hver, og ture får man kun ved at klare
opgavesættene godt. Derfor kan man ikke sidde og spille fodbold hele
eftermiddagen i stedet for at regne.
"""

import math
import random

import pygame

import art
import ui

GRASS = (96, 158, 78)
GRASS_DARK = (78, 134, 64)
LINE = (238, 240, 236)


class BreakGame:
    title = "Pause"
    keys = [("ENTER", "videre")]

    def __init__(self, game):
        self.game = game
        self.done = False
        self.t = 0.0
        self.summary = ""

    def update(self, dt):
        self.t += dt

    def handle_event(self, e):
        pass

    def draw(self, surface):
        pass


# --- Straffesparkskonkurrence -------------------------------------------

class Football(BreakGame):
    title = "Straffespark"
    SHOTS = 5

    def __init__(self, game):
        super().__init__(game)
        self.shot = 0
        self.goals = 0
        self.aim = 1                  # 0 venstre, 1 midt, 2 højre
        self.power = 0.0
        self.power_dir = 1
        self.phase = "aim"            # aim -> power -> fly -> result
        self.timer = 0.0
        self.keeper = 1
        self.ball = [0.0, 0.0]
        self.last = ""
        self.keys = [("left", ""), ("right", "sigt"), ("ENTER", "skyd")]

    def update(self, dt):
        super().update(dt)
        if self.phase == "power":
            self.power += self.power_dir * dt * 1.6
            if self.power >= 1.0:
                self.power, self.power_dir = 1.0, -1
            elif self.power <= 0.0:
                self.power, self.power_dir = 0.0, 1
        elif self.phase == "fly":
            self.timer += dt
            if self.timer > 0.55:
                self._resolve()
        elif self.phase == "result":
            self.timer += dt
            if self.timer > 1.3:
                self.shot += 1
                if self.shot >= self.SHOTS:
                    self.done = True
                    self.summary = f"Du scorede {self.goals} ud af {self.SHOTS}."
                else:
                    self.phase = "aim"
                    self.power = 0.0
                    self.timer = 0.0

    def _resolve(self):
        saved = self.keeper == self.aim
        too_soft = self.power < 0.25
        too_hard = self.power > 0.95
        if too_hard:
            self.last = "Over mål!"
        elif saved and not too_soft:
            self.last = "Målmanden havde den!"
        elif saved:
            self.last = "For blødt – reddet."
        else:
            self.goals += 1
            self.last = "MÅL!"
        self.phase = "result"
        self.timer = 0.0
        if self.last == "MÅL!":
            self.game.audio.correct()
        else:
            self.game.audio.wrong()

    def handle_event(self, e):
        if e.type != pygame.KEYDOWN:
            return
        if e.key == pygame.K_ESCAPE:
            self.done = True
            self.summary = f"Du scorede {self.goals}, inden du gik."
            return
        if self.phase == "aim":
            if e.key == pygame.K_LEFT:
                self.aim = max(0, self.aim - 1)
                self.game.audio.move()
            elif e.key == pygame.K_RIGHT:
                self.aim = min(2, self.aim + 1)
                self.game.audio.move()
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.phase = "power"
                self.keys = [("ENTER", "ram det grønne felt")]
                self.game.audio.select()
        elif self.phase == "power":
            if e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.keeper = random.randint(0, 2)
                self.phase = "fly"
                self.timer = 0.0
                self.keys = [("left", ""), ("right", "sigt"), ("ENTER", "skyd")]

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(GRASS)
        for y in range(0, h, 64):
            pygame.draw.rect(surface, GRASS_DARK, (0, y, w, 32))
        pygame.draw.arc(surface, LINE, (w // 2 - 130, 300, 260, 160), 3.34, 6.08, 4)

        gx, gy, gw, gh = w // 2 - 230, 96, 460, 190
        pygame.draw.rect(surface, LINE, (gx, gy, gw, gh), 6)
        net = pygame.Surface((gw, gh), pygame.SRCALPHA)
        for x in range(0, gw, 18):
            pygame.draw.line(net, (255, 255, 255, 70), (x, 0), (x, gh))
        for y in range(0, gh, 18):
            pygame.draw.line(net, (255, 255, 255, 70), (0, y), (gw, y))
        surface.blit(net, (gx, gy))

        zones = [gx + 76, gx + gw // 2, gx + gw - 76]

        # målmand
        kx = zones[self.keeper] if self.phase in ("fly", "result") else zones[1]
        keeper_app = {"skin": art.SKIN_TONES[2], "hair": art.HAIR_COLORS[0],
                      "hair_style": "kort", "shirt": (232, 196, 64),
                      "pants": (60, 64, 76), "extra": "ingen"}
        ks = art.character_sprite(keeper_app, "down", 0)
        surface.blit(pygame.transform.scale(ks, (art.CHAR_W * 2, art.CHAR_H * 2)),
                     (kx - art.CHAR_W, gy + gh - art.CHAR_H * 2 + 10))

        # sigtekorn
        if self.phase == "aim":
            tx = zones[self.aim]
            pulse = 4 + 2 * math.sin(self.t * 7)
            pygame.draw.circle(surface, (255, 240, 120), (tx, gy + 70), int(26 + pulse), 4)

        # bold
        if self.phase in ("fly", "result"):
            p = min(1.0, self.timer / 0.55)
            bx = w // 2 + (zones[self.aim] - w // 2) * p
            by = 470 - (470 - (gy + 70)) * p
        else:
            bx, by = w // 2, 470
        pygame.draw.circle(surface, (250, 250, 248), (int(bx), int(by)), 13)
        pygame.draw.circle(surface, (60, 60, 66), (int(bx), int(by)), 13, 2)

        # spiller
        ps = art.character_sprite(self.game.appearance, "up", 0)
        surface.blit(pygame.transform.scale(ps, (art.CHAR_W * 2, art.CHAR_H * 2)),
                     (w // 2 - art.CHAR_W, 486))

        # kraftmåler
        if self.phase == "power":
            bar = pygame.Rect(w // 2 - 160, h - 92, 320, 26)
            pygame.draw.rect(surface, (250, 248, 242), bar, border_radius=8)
            pygame.draw.rect(surface, (120, 200, 130), (bar.x + 80, bar.y, 160, bar.h))
            pygame.draw.rect(surface, ui.INK, bar, 3, border_radius=8)
            px = bar.x + int(self.power * bar.w)
            pygame.draw.rect(surface, (214, 72, 64), (px - 3, bar.y - 6, 6, bar.h + 12),
                             border_radius=3)

        panel = pygame.Rect(20, 16, 300, 64)
        ui.panel(surface, panel, radius=12)
        ui.text(surface, f"Spark {min(self.shot + 1, self.SHOTS)} af {self.SHOTS}",
                (panel.x + 16, panel.y + 10), size=19, bold=True)
        ui.text(surface, f"Mål: {self.goals}", (panel.x + 16, panel.y + 36),
                size=17, color=ui.MUTED)

        if self.phase == "result":
            col = ui.GOOD if self.last == "MÅL!" else ui.BAD
            ui.text(surface, self.last, (w // 2, 300), size=44, color=col,
                    bold=True, center=True, shadow=True)


# --- Klæd om ------------------------------------------------------------

class DressUp(BreakGame):
    title = "Klæd om"
    ROWS = ["Hår", "Hårfarve", "Trøje", "Bukser", "Hudfarve", "Ekstra", "Færdig"]
    PANTS = [(78, 86, 112), (62, 64, 72), (128, 96, 72), (54, 76, 108),
             (150, 96, 120), (92, 108, 90)]
    EXTRAS = ["ingen", "taske", "briller", "briller+taske"]

    def __init__(self, game):
        super().__init__(game)
        self.row = 0
        self.app = dict(game.appearance)
        self.keys = [("up", ""), ("down", "vælg"), ("left", ""), ("right", "skift"),
                     ("ENTER", "færdig")]

    def handle_event(self, e):
        if e.type != pygame.KEYDOWN:
            return
        if e.key == pygame.K_ESCAPE:
            self.done = True
            self.summary = "Du beholdt dit tøj."
            return
        if e.key == pygame.K_UP:
            self.row = (self.row - 1) % len(self.ROWS)
            self.game.audio.move()
        elif e.key == pygame.K_DOWN:
            self.row = (self.row + 1) % len(self.ROWS)
            self.game.audio.move()
        elif e.key in (pygame.K_LEFT, pygame.K_RIGHT):
            self._change(-1 if e.key == pygame.K_LEFT else 1)
            self.game.audio.move()
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            if self.ROWS[self.row] == "Færdig":
                self.game.appearance.update(self.app)
                self.game.player.app = self.game.appearance
                self.done = True
                self.summary = "Nyt tøj på."
                self.game.audio.levelup()
            else:
                self.row = (self.row + 1) % len(self.ROWS)
                self.game.audio.move()

    def _change(self, step):
        row = self.ROWS[self.row]
        a = self.app
        if row == "Hår":
            styles = ["kort", "lang", "kroeller", "kasket"]
            a["hair_style"] = styles[(styles.index(a["hair_style"]) + step) % len(styles)]
        elif row == "Hårfarve":
            i = art.HAIR_COLORS.index(tuple(a["hair"]))
            a["hair"] = art.HAIR_COLORS[(i + step) % len(art.HAIR_COLORS)]
        elif row == "Trøje":
            i = art.CLOTH_COLORS.index(tuple(a["shirt"]))
            a["shirt"] = art.CLOTH_COLORS[(i + step) % len(art.CLOTH_COLORS)]
        elif row == "Bukser":
            cur = tuple(a["pants"])
            i = self.PANTS.index(cur) if cur in self.PANTS else 0
            a["pants"] = self.PANTS[(i + step) % len(self.PANTS)]
        elif row == "Hudfarve":
            i = art.SKIN_TONES.index(tuple(a["skin"]))
            a["skin"] = art.SKIN_TONES[(i + step) % len(art.SKIN_TONES)]
        elif row == "Ekstra":
            i = self.EXTRAS.index(a.get("extra", "ingen"))
            a["extra"] = self.EXTRAS[(i + step) % len(self.EXTRAS)]

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill((58, 52, 74))
        for i in range(0, h, 6):
            pygame.draw.line(surface, (64, 58, 82), (0, i), (w, i))

        ui.text(surface, "Klæd om", (w // 2, 28), size=34, color=(250, 244, 230),
                bold=True, center=True, shadow=True)

        prev = pygame.Rect(90, 92, 300, 430)
        ui.panel(surface, prev)
        sprite = art.character_sprite(self.app, "down", int(self.t * 6) % 4)
        surface.blit(pygame.transform.scale(sprite, (art.CHAR_W * 6, art.CHAR_H * 6)),
                     (prev.centerx - art.CHAR_W * 3, prev.y + 50))
        ui.text(surface, self.game.name or "Dig", (prev.centerx, prev.bottom - 46),
                size=24, bold=True, center=True)

        panel = pygame.Rect(430, 92, w - 520, 430)
        ui.panel(surface, panel)
        for i, row in enumerate(self.ROWS):
            y = panel.y + 20 + i * 56
            sel = i == self.row
            r = pygame.Rect(panel.x + 16, y, panel.w - 32, 46)
            if sel:
                pygame.draw.rect(surface, (246, 234, 208), r, border_radius=10)
                pygame.draw.rect(surface, ui.ACCENT, r, 3, border_radius=10)
            ui.text(surface, row, (r.x + 16, r.y + 12), size=21, bold=sel,
                    color=ui.INK if sel else (110, 104, 98))
            swatch = {"Hårfarve": "hair", "Trøje": "shirt",
                      "Bukser": "pants", "Hudfarve": "skin"}.get(row)
            if swatch:
                sw = pygame.Rect(r.right - 120, r.y + 12, 48, 24)
                pygame.draw.rect(surface, self.app[swatch], sw, border_radius=6)
                pygame.draw.rect(surface, ui.INK, sw, 2, border_radius=6)
                ui.arrow(surface, (r.right - 140, r.y + 24), "left")
                ui.arrow(surface, (r.right - 56, r.y + 24), "right")
            elif row in ("Hår", "Ekstra"):
                val = (self.app["hair_style"] if row == "Hår"
                       else self.app.get("extra", "ingen"))
                val = val.replace("kroeller", "krøller").capitalize()
                ui.text(surface, val,
                        (r.right - 24 - ui.font(19).size(val)[0], r.y + 14),
                        size=19, color=ui.MUTED)


GAMES = {"fodbold": Football, "dressup": DressUp}
LABELS = {"fodbold": "Straffespark", "dressup": "Klæd om"}
