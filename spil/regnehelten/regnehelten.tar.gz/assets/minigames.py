"""
Minispil til kampskærmen. Hver opgavetype har sin egen måde at svare på,
så det ikke bare er en tekstboks hver gang.

Alle minispil deler samme snitflade:
    handle_event(e, audio)  -> spilleren gør noget; sætter .result når der svares
    draw(surface, rect)     -> tegner sig selv inde i rect
    result                  -> None, eller (rigtigt: bool, besked: str)
    answer_text()           -> facit, som kampskærmen kan vise
"""

import math

import pygame

import content
import ui

TILE_BG = (255, 253, 247)
TILE_EDGE = (206, 196, 180)
SEL = (206, 138, 46)
SEL_BG = (250, 238, 212)
PICKED = (58, 148, 92)
PICKED_BG = (226, 244, 232)


def _tile(surface, rect, label, size=24, selected=False, picked=False, dim=False):
    bg = PICKED_BG if picked else (SEL_BG if selected else TILE_BG)
    edge = PICKED if picked else (SEL if selected else TILE_EDGE)
    pygame.draw.rect(surface, bg, rect, border_radius=10)
    pygame.draw.rect(surface, edge, rect, 3 if (selected or picked) else 2, border_radius=10)
    col = (150, 144, 136) if dim else ui.INK
    ui.text(surface, label, rect.center, size=size, color=col, bold=True, center=True)


class MiniGame:
    label = "Opgave"
    keys = "ENTER: svar"
    key_items = [("ENTER", "svar")]
    book = "plus"

    def __init__(self, spec):
        self.spec = spec
        self._hits = []          # [(rect, data)] gemt af draw(), brugt af tap()
        self.prompt = spec.get("q", "")
        self.hint = spec.get("hint", "")
        self.book = spec.get("book", self.book)
        self.result = None
        self.t = 0.0

    def reset(self):
        self.result = None

    def update(self, dt):
        self.t += dt

    def handle_event(self, e, audio):
        pass

    def draw(self, surface, rect):
        pass

    def answer_text(self):
        return ""

    def tap(self, pos, audio):
        """Tryk direkte på en brik. Underklasser bruger self._hits."""
        return False


# --- 1. Skriv svaret -----------------------------------------------------

class WriteGame(MiniGame):
    label = "Skriv svaret"
    keys = "tal-taster: skriv     ENTER: svar"
    key_items = [('0-9', 'skriv'), ('ENTER', 'svar')]

    def __init__(self, spec):
        super().__init__(spec)
        self.text = ""

    def reset(self):
        super().reset()
        self.text = ""

    def handle_event(self, e, audio):
        if e.type == pygame.TEXTINPUT:
            if (e.text.isdigit() or e.text in ",.-") and len(self.text) < 9:
                self.text += e.text
        elif e.type == pygame.KEYDOWN:
            if e.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER) and self.text.strip():
                ok = content.check_numeric(self.text, self.spec["answer"])
                self.result = (ok, "")

    def draw(self, surface, rect):
        # på touch ligger taltastaturet nederst i feltet – skriv derfor højere op
        top = rect.y if ui.TOUCH else rect.y + 40
        field = pygame.Rect(rect.centerx - 170, top, 340, 62)
        pygame.draw.rect(surface, (255, 255, 255), field, border_radius=12)
        pygame.draw.rect(surface, SEL, field, 3, border_radius=12)
        caret = "|" if int(self.t * 2.4) % 2 == 0 else ""
        ui.text(surface, self.text + caret, (field.centerx, field.centery),
                size=34, center=True, bold=True)
        unit = self.spec.get("unit", "")
        if unit:
            ui.text(surface, unit, (field.right + 18, field.centery - 12),
                    size=20, color=ui.MUTED)

    def answer_text(self):
        return content.fmt(self.spec["answer"])


# --- 2. Vælg den rigtige -------------------------------------------------

class ChoiceGame(MiniGame):
    label = "Vælg den rigtige"
    keys = "piletaster: vælg     ENTER: svar"
    key_items = [('up', ''), ('down', 'vælg'), ('ENTER', 'svar')]

    def __init__(self, spec):
        super().__init__(spec)
        self.index = 0

    def handle_event(self, e, audio):
        if e.type != pygame.KEYDOWN:
            return
        n = len(self.spec["choices"])
        if e.key in (pygame.K_UP, pygame.K_LEFT):
            self.index = (self.index - 1) % n
            audio.move()
        elif e.key in (pygame.K_DOWN, pygame.K_RIGHT):
            self.index = (self.index + 1) % n
            audio.move()
        elif pygame.K_1 <= e.key <= pygame.K_9:
            i = e.key - pygame.K_1
            if i < n:
                self.index = i
                audio.move()
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.result = (self.index == self.spec["answer"], "")

    def tap(self, pos, audio):
        for r, i in self._hits:
            if r.collidepoint(pos):
                if self.index == i:
                    self.result = (i == self.spec["answer"], "")
                else:
                    self.index = i
                    audio.move()
                return True
        return False

    def draw(self, surface, rect):
        self._hits = []
        choices = self.spec["choices"]
        h = 46
        gap = 10
        total = len(choices) * (h + gap) - gap
        y0 = rect.centery - total // 2 + 6
        for i, c in enumerate(choices):
            r = pygame.Rect(rect.centerx - 260, y0 + i * (h + gap), 520, h)
            self._hits.append((r, i))
            sel = i == self.index
            pygame.draw.rect(surface, SEL_BG if sel else TILE_BG, r, border_radius=10)
            pygame.draw.rect(surface, SEL if sel else TILE_EDGE, r, 3 if sel else 2,
                             border_radius=10)
            ui.text(surface, f"{i + 1}", (r.x + 24, r.centery), size=18,
                    color=SEL if sel else ui.MUTED, bold=True, center=True)
            ui.text(surface, c, (r.x + 48, r.centery - 12), size=21, bold=sel)

    def answer_text(self):
        return self.spec["choices"][self.spec["answer"]]


# --- 3. Find dem alle ----------------------------------------------------

class FindAllGame(MiniGame):
    label = "Find dem alle"
    keys = "piletaster: flyt     MELLEMRUM: vælg     ENTER: færdig"
    key_items = [('left', ''), ('right', 'flyt'), ('MELLEMRUM', 'vælg'), ('ENTER', 'færdig')]

    def __init__(self, spec):
        super().__init__(spec)
        self.index = 0
        self.picked = set()
        self.cols = 4

    def reset(self):
        super().reset()
        self.picked = set()

    def handle_event(self, e, audio):
        if e.type != pygame.KEYDOWN:
            return
        tiles = self.spec["tiles"]
        n = len(tiles)
        if e.key == pygame.K_RIGHT:
            self.index = (self.index + 1) % n
            audio.move()
        elif e.key == pygame.K_LEFT:
            self.index = (self.index - 1) % n
            audio.move()
        elif e.key == pygame.K_DOWN:
            self.index = (self.index + self.cols) % n
            audio.move()
        elif e.key == pygame.K_UP:
            self.index = (self.index - self.cols) % n
            audio.move()
        elif e.key == pygame.K_SPACE:
            self.picked ^= {self.index}
            audio.select()
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            want = {i for i, t in enumerate(tiles) if t[1] == self.spec["target"]}
            if not self.picked:
                return
            ok = self.picked == want
            msg = ""
            if not ok:
                missed = len(want - self.picked)
                wrong = len(self.picked - want)
                if wrong and missed:
                    msg = f"Du har {wrong} for meget og mangler {missed}."
                elif wrong:
                    msg = f"{wrong} af dem passer ikke."
                else:
                    msg = f"Du mangler {missed} mere."
            self.result = (ok, msg)

    def tap(self, pos, audio):
        for r, i in self._hits:
            if r.collidepoint(pos):
                self.index = i
                self.picked ^= {i}
                audio.select()
                return True
        return False

    def draw(self, surface, rect):
        self._hits = []
        tiles = self.spec["tiles"]
        tw, th, gap = 118, 54, 12
        rows = (len(tiles) + self.cols - 1) // self.cols
        gw = self.cols * (tw + gap) - gap
        gh = rows * (th + gap) - gap
        x0 = rect.centerx - gw // 2
        y0 = rect.centery - gh // 2 + 12
        for i, (lab, _val) in enumerate(tiles):
            r = pygame.Rect(x0 + (i % self.cols) * (tw + gap),
                            y0 + (i // self.cols) * (th + gap), tw, th)
            self._hits.append((r, i))
            _tile(surface, r, lab, size=23, selected=(i == self.index),
                  picked=(i in self.picked))
        ui.text(surface, f"Valgt: {len(self.picked)}", (rect.centerx, y0 + gh + 14),
                size=17, color=ui.MUTED, center=True)

    def answer_text(self):
        want = [t[0] for t in self.spec["tiles"] if t[1] == self.spec["target"]]
        return ", ".join(want)


# --- 4. Vægtskålen -------------------------------------------------------

class BalanceGame(MiniGame):
    label = "Få vægten i balance"
    keys = "op/ned: skift tal     ENTER: prøv vægten"
    key_items = [('up', ''), ('down', 'skift tal'), ('ENTER', 'prøv vægten')]
    book = "gange"

    def __init__(self, spec):
        super().__init__(spec)
        self.value = spec.get("start", 1)
        self.tilt = 0.0
        self.target_tilt = 0.0

    def reset(self):
        super().reset()
        self.tilt = 0.0
        self.target_tilt = 0.0

    def _left_value(self):
        a, op = self.spec["a"], self.spec["op"]
        if op == "x":
            return a * self.value
        if op == "+":
            return a + self.value
        if op == "-":
            return a - self.value
        return a

    def handle_event(self, e, audio):
        if e.type != pygame.KEYDOWN:
            return
        if e.key in (pygame.K_UP, pygame.K_RIGHT):
            self.value = min(self.spec.get("max", 30), self.value + 1)
            audio.move()
        elif e.key in (pygame.K_DOWN, pygame.K_LEFT):
            self.value = max(self.spec.get("min", 0), self.value - 1)
            audio.move()
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            diff = self._left_value() - self.spec["target"]
            self.target_tilt = max(-1.0, min(1.0, diff / max(4, abs(self.spec["target"]) * 0.5)))
            ok = diff == 0
            msg = ""
            if not ok:
                msg = "For tungt i venstre side." if diff > 0 else "For let i venstre side."
            self.result = (ok, msg)

    def update(self, dt):
        super().update(dt)
        self.tilt += (self.target_tilt - self.tilt) * min(1.0, dt * 6)

    def draw(self, surface, rect):
        cx, cy = rect.centerx, rect.centery - 6
        pygame.draw.rect(surface, (150, 142, 130), (cx - 8, cy, 16, 74))
        pygame.draw.polygon(surface, (150, 142, 130),
                            [(cx - 46, cy + 78), (cx + 46, cy + 78), (cx + 28, cy + 66),
                             (cx - 28, cy + 66)])
        ang = self.tilt * 0.22
        dx, dy = math.cos(ang) * 300, math.sin(ang) * 300
        lx, ly = cx - dx / 2, cy - dy / 2
        rx, ry = cx + dx / 2, cy + dy / 2
        pygame.draw.line(surface, (110, 104, 96), (lx, ly), (rx, ry), 7)
        pygame.draw.circle(surface, (90, 84, 78), (cx, cy), 9)

        a, op = self.spec["a"], self.spec["op"]
        for (px, py, txt, col) in (
            (lx, ly, f"{a} {op} {self.value}", SEL),
            (rx, ry, str(self.spec["target"]), (72, 112, 178)),
        ):
            pan = pygame.Rect(px - 70, py + 14, 140, 52)
            pygame.draw.line(surface, (140, 132, 122), (px, py), (pan.centerx, pan.y), 2)
            pygame.draw.rect(surface, TILE_BG, pan, border_radius=10)
            pygame.draw.rect(surface, col, pan, 3, border_radius=10)
            ui.text(surface, txt, pan.center, size=27, center=True, bold=True)

        ui.text(surface, "Hvilket tal skal stå på den tomme plads?",
                (rect.centerx, rect.y + 8), size=18, color=ui.MUTED, center=True)

    def answer_text(self):
        return str(self.spec["answer"])


# --- 5. Talrækken --------------------------------------------------------

class SequenceGame(MiniGame):
    label = "Hvad mangler i rækken?"
    keys = "tal-taster: skriv     ENTER: svar"
    key_items = [('0-9', 'skriv'), ('ENTER', 'svar')]
    book = "monstre"

    def __init__(self, spec):
        super().__init__(spec)
        self.text = ""

    def reset(self):
        super().reset()
        self.text = ""

    def handle_event(self, e, audio):
        if e.type == pygame.TEXTINPUT:
            if e.text.isdigit() and len(self.text) < 5:
                self.text += e.text
        elif e.type == pygame.KEYDOWN:
            if e.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER) and self.text:
                self.result = (content.check_numeric(self.text, self.spec["answer"]), "")

    def draw(self, surface, rect):
        seq = self.spec["seq"]
        cw, gap = 92, 16
        total = len(seq) * (cw + gap) - gap
        x0 = rect.centerx - total // 2
        y = rect.y + 6 if ui.TOUCH else rect.centery - 34
        for i, v in enumerate(seq):
            r = pygame.Rect(x0 + i * (cw + gap), y, cw, 70)
            if v is None:
                pulse = 2 + int(1.5 * (1 + math.sin(self.t * 5)))
                pygame.draw.rect(surface, (255, 255, 255), r, border_radius=10)
                pygame.draw.rect(surface, SEL, r, pulse, border_radius=10)
                caret = "|" if int(self.t * 2.4) % 2 == 0 else ""
                ui.text(surface, (self.text or "?") + caret, r.center, size=30,
                        center=True, bold=True, color=SEL if not self.text else ui.INK)
            else:
                _tile(surface, r, str(v), size=30)
            if i < len(seq) - 1:
                ax = r.right + gap // 2
                pygame.draw.line(surface, (170, 162, 150), (r.right + 3, r.centery),
                                 (r.right + gap - 3, r.centery), 2)

    def answer_text(self):
        return str(self.spec["answer"])


# --- 6. Rigtigt eller forkert -------------------------------------------

class TrueFalseGame(MiniGame):
    label = "Rigtigt eller forkert?"
    keys = "venstre/højre: vælg     ENTER: svar"
    key_items = [('left', ''), ('right', 'vælg'), ('ENTER', 'svar')]
    book = "tjek"

    def __init__(self, spec):
        super().__init__(spec)
        self.index = 0

    def handle_event(self, e, audio):
        if e.type != pygame.KEYDOWN:
            return
        if e.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN):
            self.index = 1 - self.index
            audio.move()
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            chose_true = self.index == 0
            self.result = (chose_true == self.spec["is_true"], "")

    def tap(self, pos, audio):
        for r, i in self._hits:
            if r.collidepoint(pos):
                self.index = i
                self.result = ((i == 0) == self.spec["is_true"], "")
                return True
        return False

    def draw(self, surface, rect):
        self._hits = []
        stmt = pygame.Rect(rect.centerx - 230, rect.y + 20, 460, 66)
        pygame.draw.rect(surface, (255, 255, 255), stmt, border_radius=12)
        pygame.draw.rect(surface, TILE_EDGE, stmt, 2, border_radius=12)
        ui.text(surface, self.spec["statement"], stmt.center, size=32,
                center=True, bold=True)

        for i, (lab, col) in enumerate([("RIGTIGT", PICKED), ("FORKERT", (198, 72, 64))]):
            r = pygame.Rect(rect.centerx - 220 + i * 240, stmt.bottom + 26, 200, 56)
            self._hits.append((r, i))
            sel = i == self.index
            pygame.draw.rect(surface, SEL_BG if sel else TILE_BG, r, border_radius=12)
            pygame.draw.rect(surface, col if sel else TILE_EDGE, r, 4 if sel else 2,
                             border_radius=12)
            ui.text(surface, lab, r.center, size=24, center=True, bold=True,
                    color=col if sel else (140, 134, 126))

    def answer_text(self):
        return "Rigtigt" if self.spec["is_true"] else "Forkert"


# --- 7. Byg regnestykket -------------------------------------------------

class BuildGame(MiniGame):
    label = "Byg regnestykket"
    keys = "piletaster: vælg     MELLEMRUM: sæt ind     BACKSPACE: slet     ENTER: svar"
    key_items = [('left', ''), ('right', 'vælg'), ('MELLEMRUM', 'sæt ind'), ('BACKSPACE', 'slet'), ('ENTER', 'svar')]
    book = "raekkefolge"

    def __init__(self, spec):
        super().__init__(spec)
        p = spec["puzzle"]
        self.parts = [str(n) for n in p["numbers"]]
        ops = [o for o in p["allowed"]]
        sym = {"+": "+", "-": "-", "*": "x", "/": ":"}
        self.ops = [sym[o] for o in ops] + ["(", ")"]
        self.palette = self.parts + self.ops
        self.used = []          # indeks i palette-rækkefølgen for tal
        self.expr = []          # liste af strenge
        self.index = 0

    def reset(self):
        super().reset()
        self.expr = []
        self.used = []

    def _expr_string(self):
        return "".join(self.expr).replace("x", "*").replace(":", "/")

    def handle_event(self, e, audio):
        if e.type != pygame.KEYDOWN:
            return
        n = len(self.palette)
        if e.key == pygame.K_RIGHT:
            self.index = (self.index + 1) % n
            audio.move()
        elif e.key == pygame.K_LEFT:
            self.index = (self.index - 1) % n
            audio.move()
        elif e.key in (pygame.K_UP, pygame.K_DOWN):
            self.index = (self.index + len(self.parts)) % n
            audio.move()
        elif e.key == pygame.K_SPACE:
            token = self.palette[self.index]
            if self.index < len(self.parts):
                if self.index in self.used:
                    return
                self.used.append(self.index)
            self.expr.append(token)
            audio.select()
        elif e.key == pygame.K_BACKSPACE:
            if self.expr:
                tok = self.expr.pop()
                for i in reversed(self.used):
                    if self.palette[i] == tok:
                        self.used.remove(i)
                        break
                audio.back()
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if not self.expr:
                return
            ok, msg = content.check_creative(self._expr_string(), self.spec["puzzle"])
            self.result = (ok, "" if ok else msg)

    def tap(self, pos, audio):
        for r, i in self._hits:
            if r.collidepoint(pos):
                self.index = i
                self.handle_event(
                    pygame.event.Event(pygame.KEYDOWN, key=pygame.K_SPACE), audio)
                return True
        return False

    def draw(self, surface, rect):
        p = self.spec["puzzle"]
        ui.text(surface, f"Byg et regnestykke, der giver {p['target']}",
                (rect.centerx, rect.y + 6), size=20, color=ui.MUTED, center=True,
                bold=True)

        disp = pygame.Rect(rect.centerx - 250, rect.y + 36, 500, 60)
        pygame.draw.rect(surface, (255, 255, 255), disp, border_radius=12)
        pygame.draw.rect(surface, SEL, disp, 3, border_radius=12)
        shown = " ".join(self.expr) if self.expr else "..."
        ui.text(surface, shown, (disp.centerx - 30, disp.centery), size=28,
                center=True, bold=True,
                color=ui.INK if self.expr else (176, 170, 162))
        val = None
        if self.expr:
            try:
                val = eval(self._expr_string(), {"__builtins__": {}}, {})
            except Exception:
                val = None
        if val is not None:
            good = abs(val - p["target"]) < 1e-6
            ui.text(surface, f"= {content.fmt(val)}", (disp.right - 70, disp.centery),
                    size=26, center=True, bold=True, color=PICKED if good else ui.MUTED)

        self._hits = []
        y = disp.bottom + 20
        tw, gap = 66, 10
        total = len(self.palette) * (tw + gap) - gap
        x0 = rect.centerx - total // 2
        for i, tok in enumerate(self.palette):
            r = pygame.Rect(x0 + i * (tw + gap), y, tw, 52)
            self._hits.append((r, i))
            spent = i < len(self.parts) and i in self.used
            _tile(surface, r, tok, size=25, selected=(i == self.index), dim=spent)

    def answer_text(self):
        return self.spec["puzzle"]["expr"].replace("*", " x ").replace("/", " : ")


# --- 8. Betal præcis -----------------------------------------------------

class CoinsGame(MiniGame):
    label = "Betal det præcise beløb"
    keys = "venstre/højre: vælg mønt     op/ned: antal     ENTER: betal"
    key_items = [('left', ''), ('right', 'mønt'), ('up', ''), ('down', 'antal'), ('ENTER', 'betal')]
    book = "penge"

    COINS = [1, 2, 5, 10, 20, 50]

    def __init__(self, spec):
        super().__init__(spec)
        self.counts = [0] * len(self.COINS)
        self.index = 0

    def reset(self):
        super().reset()
        self.counts = [0] * len(self.COINS)

    def total(self):
        return sum(c * v for c, v in zip(self.counts, self.COINS))

    def handle_event(self, e, audio):
        if e.type != pygame.KEYDOWN:
            return
        if e.key == pygame.K_RIGHT:
            self.index = (self.index + 1) % len(self.COINS)
            audio.move()
        elif e.key == pygame.K_LEFT:
            self.index = (self.index - 1) % len(self.COINS)
            audio.move()
        elif e.key == pygame.K_UP:
            self.counts[self.index] = min(9, self.counts[self.index] + 1)
            audio.select()
        elif e.key == pygame.K_DOWN:
            self.counts[self.index] = max(0, self.counts[self.index] - 1)
            audio.select()
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            t = self.total()
            if t == 0:
                return
            diff = t - self.spec["target"]
            ok = diff == 0
            msg = ""
            if diff > 0:
                msg = f"Det er {diff} kr for meget."
            elif diff < 0:
                msg = f"Der mangler {-diff} kr."
            self.result = (ok, msg)

    def tap(self, pos, audio):
        for r, (i, delta) in self._hits:
            if r.collidepoint(pos):
                self.counts[i] = max(0, min(9, self.counts[i] + delta))
                self.index = i
                audio.select()
                return True
        return False

    def draw(self, surface, rect):
        self._hits = []
        target = self.spec["target"]
        ui.text(surface, f"Læg præcis {target} kr på disken",
                (rect.centerx, rect.y + 6), size=20, color=ui.MUTED, center=True, bold=True)

        gap = 18
        cw = 92
        total_w = len(self.COINS) * (cw + gap) - gap
        x0 = rect.centerx - total_w // 2
        y = rect.y + 46
        for i, val in enumerate(self.COINS):
            cx = x0 + i * (cw + gap) + cw // 2
            cy = y + 40
            sel = i == self.index
            shade = (214, 186, 132) if val >= 5 else (204, 200, 190)
            pygame.draw.circle(surface, (150, 130, 96) if val >= 5 else (150, 146, 138),
                               (cx, cy + 3), 33)
            pygame.draw.circle(surface, shade, (cx, cy), 33)
            pygame.draw.circle(surface, SEL if sel else (140, 128, 104),
                               (cx, cy), 33, 4 if sel else 2)
            ui.text(surface, str(val), (cx, cy), size=25, center=True, bold=True)
            self._hits.append((pygame.Rect(cx - 33, cy - 33, 66, 66), (i, 1)))
            cnt = self.counts[i]
            box = pygame.Rect(cx - 26, cy + 42, 52, 30)
            self._hits.append((box, (i, -1)))
            pygame.draw.rect(surface, SEL_BG if sel else TILE_BG, box, border_radius=8)
            pygame.draw.rect(surface, SEL if sel else TILE_EDGE, box, 2, border_radius=8)
            ui.text(surface, f"x{cnt}", box.center, size=18, center=True, bold=True,
                    color=ui.INK if cnt else (168, 162, 154))

        t = self.total()
        col = PICKED if t == target else ui.INK
        ui.text(surface, f"I alt: {t} kr", (rect.centerx, y + 124), size=26,
                center=True, bold=True, color=col)

    def answer_text(self):
        target = self.spec["target"]
        rest = target
        parts = []
        for v in sorted(self.COINS, reverse=True):
            while rest >= v:
                rest -= v
                parts.append(str(v))
        return " + ".join(parts) + f" = {target} kr"


GAMES = {
    "write": WriteGame, "choice": ChoiceGame, "findall": FindAllGame,
    "balance": BalanceGame, "sequence": SequenceGame, "truefalse": TrueFalseGame,
    "build": BuildGame, "coins": CoinsGame,
}


def make(spec):
    return GAMES[spec["kind"]](spec)
