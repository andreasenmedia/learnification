"""
Hvad nåede spilleren at løse?

Spillet samler op undervejs – hvilken opgave, hvilket emne, om den blev
klaret i første forsøg – og sender det til learnification.dk, så en voksen
kan se, hvordan testen gik. Det sker to steder fra:

* herfra, når en runde er slut og når spillet er færdigt, og
* fra siden omkring spillet, hvis fanen bliver lukket midt i det hele.
  Derfor lægger vi hele tiden den nyeste udgave i `window.lfResultat`.

Uden for browseren (på en pc med `python main.py`) sker der ingenting.
Så er der ikke noget at sende til, og modulet holder bare regnskabet.
"""

import json
import random
import time

URL = "/resultat.php"

# Tekstversion af Blooms trin, så filen kan læses uden at slå op
TRINNAVN = {
    "HUSK": "Tal-fakta", "FORSTÅ": "Forstå opgaven", "ANVEND": "Handle ind",
    "ANALYSÉR": "Mønstre og flere trin", "VURDÉR": "Tjekke et svar",
    "SKAB": "Bygge sit eget regnestykke",
}


def _vindue():
    try:
        import platform as _platform
        return getattr(_platform, "window", None)
    except Exception:
        return None


class Resultat:
    def __init__(self):
        self.id = "%d-%04d" % (int(time.time()), random.randint(0, 9999))
        self.start = time.time()
        self.navn = ""
        self.klasse = 0
        self.trin = ""
        self.svar = []           # én post pr. opgave, spilleren er færdig med
        self.faerdig = False
        self.kapitel = 0
        self.regnekraft = 0
        self._sidst_sendt = 0.0

    # --- opsamling ----------------------------------------------------

    def start_spil(self, navn, klasse, trin):
        self.navn = navn
        self.klasse = klasse
        self.trin = trin
        self.start = time.time()

    def noter(self, scene, bloom, spec, forsoeg, klaret):
        """Én opgave er overstået."""
        spoergsmaal = str(spec.get("q", "")).split("\n")[0][:90]
        self.svar.append({
            "scene": scene,
            "trin": TRINNAVN.get(bloom, bloom),
            "type": spec.get("kind", ""),
            "emne": spec.get("book", ""),
            "spoergsmaal": spoergsmaal,
            "facit": str(spec.get("answer", spec.get("target", ""))),
            "forsoeg": forsoeg + 1,
            "foerste_forsoeg": bool(klaret and forsoeg == 0),
            "klaret": bool(klaret),
        })

    # --- hvad der bliver sendt ----------------------------------------

    def opsummering(self):
        rigtige = sum(1 for s in self.svar if s["foerste_forsoeg"])
        klaret = sum(1 for s in self.svar if s["klaret"])
        emner = {}
        for s in self.svar:
            e = emner.setdefault(s["emne"] or "andet", {"opgaver": 0, "foerste": 0})
            e["opgaver"] += 1
            e["foerste"] += 1 if s["foerste_forsoeg"] else 0
        return {
            "id": self.id,
            "navn": self.navn,
            "klasse": self.klasse,
            "trin": self.trin,
            "minutter": round((time.time() - self.start) / 60, 1),
            "opgaver": len(self.svar),
            "foerste_forsoeg": rigtige,
            "klaret": klaret,
            "procent": round(100 * rigtige / len(self.svar)) if self.svar else 0,
            "regnekraft": self.regnekraft,
            "kapitel": self.kapitel,
            "faerdig": self.faerdig,
            "emner": emner,
            "detaljer": self.svar,
        }

    def json(self):
        return json.dumps(self.opsummering(), ensure_ascii=False)

    # --- afsendelse ---------------------------------------------------

    def gem_i_siden(self):
        """Læg den nyeste udgave, hvor siden omkring spillet kan finde den.

        Det er dén, der bliver sendt, hvis nogen lukker fanen midt i spillet.
        """
        win = _vindue()
        if win is None:
            return
        try:
            # json.dumps to gange: så står der en JS-STRENG i window.lfResultat,
            # og der kan ikke smugles kode med ind ad den vej.
            win.eval("window.lfResultat = " + json.dumps(self.json()))
        except Exception:
            pass

    def send(self, tvungen=False):
        """Send med det samme. sendBeacon overlever, at siden lukkes."""
        self.gem_i_siden()
        if not self.svar and not tvungen:
            return
        win = _vindue()
        if win is None:
            return
        try:
            win.navigator.sendBeacon(URL, self.json())
            self._sidst_sendt = time.time()
        except Exception:
            try:
                win.eval("fetch('" + URL + "',{method:'POST',keepalive:true,"
                         "body:window.lfResultat})")
                self._sidst_sendt = time.time()
            except Exception:
                pass
