"""
UI tegnet i fuld oploesning (ikke skaleret sammen med verdenen), saa
tekst altid er skarp og let at laese.
"""

import pygame

# Sættes til True, når spillet bliver rørt ved – så gør opgaverne plads til
# taltastaturet og tegner knapper, man kan trykke på.
TOUCH = False

INK = (38, 34, 44)
PAPER = (250, 247, 240)
PAPER_EDGE = (214, 204, 186)
ACCENT = (206, 138, 46)
ACCENT_DARK = (150, 96, 26)
GOOD = (58, 148, 92)
BAD = (198, 72, 64)
MUTED = (118, 112, 106)
SHADOW = (0, 0, 0, 70)

_FONT_FACES = ["Segoe UI", "Verdana", "Tahoma", "DejaVu Sans", "Arial"]
_cache = {}


def font(size, bold=False):
    key = (size, bold)
    if key not in _cache:
        f = None
        for face in _FONT_FACES:
            try:
                f = pygame.font.SysFont(face, size, bold=bold)
                if f:
                    break
            except Exception:
                continue
        if f is None:
            f = pygame.font.Font(None, size)
        _cache[key] = f
    return _cache[key]


def text(surface, s, pos, size=19, color=INK, bold=False, center=False, shadow=False):
    f = font(size, bold)
    img = f.render(s, True, color)
    rect = img.get_rect()
    setattr(rect, "center" if center else "topleft", pos)
    if shadow:
        sh = f.render(s, True, (0, 0, 0))
        sh.set_alpha(90)
        surface.blit(sh, (rect.x + 2, rect.y + 2))
    surface.blit(img, rect)
    return rect


def wrap(s, size, max_width, bold=False):
    """Ombryder paa pixelbredde, ikke tegn - giver paene linjeskift."""
    f = font(size, bold)
    lines = []
    for para in s.split("\n"):
        if not para:
            lines.append("")
            continue
        words = para.split(" ")
        cur = ""
        for w in words:
            trial = w if not cur else cur + " " + w
            if f.size(trial)[0] <= max_width:
                cur = trial
            else:
                if cur:
                    lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
    return lines


def text_block(surface, s, pos, size=19, color=INK, max_width=600, line_gap=6, bold=False):
    f = font(size, bold)
    x, y = pos
    lh = f.get_height() + line_gap
    for i, line in enumerate(wrap(s, size, max_width, bold)):
        if line:
            surface.blit(f.render(line, True, color), (x, y + i * lh))
    return y + len(wrap(s, size, max_width, bold)) * lh


def panel(surface, rect, bg=PAPER, border=PAPER_EDGE, radius=14, shadow=True):
    rect = pygame.Rect(rect)
    if shadow:
        sh = pygame.Surface((rect.w + 12, rect.h + 12), pygame.SRCALPHA)
        pygame.draw.rect(sh, SHADOW, (6, 8, rect.w, rect.h), border_radius=radius)
        surface.blit(sh, (rect.x - 6, rect.y - 4))
    pygame.draw.rect(surface, bg, rect, border_radius=radius)
    pygame.draw.rect(surface, border, rect, 3, border_radius=radius)
    return rect


def name_tag(surface, label, pos, color=ACCENT):
    f = font(18, True)
    w = f.size(label)[0] + 26
    r = pygame.Rect(pos[0], pos[1], w, 32)
    pygame.draw.rect(surface, color, r, border_radius=10)
    pygame.draw.rect(surface, ACCENT_DARK, r, 2, border_radius=10)
    surface.blit(f.render(label, True, (255, 252, 245)), (r.x + 13, r.y + 6))
    return r


def arrow(surface, center, facing, color=MUTED, size=9):
    """Tegnet trekant – fonte mangler ofte ◀ og ▶."""
    cx, cy = center
    if facing == "left":
        pts = [(cx + size // 2, cy - size), (cx + size // 2, cy + size), (cx - size // 2, cy)]
    elif facing == "right":
        pts = [(cx - size // 2, cy - size), (cx - size // 2, cy + size), (cx + size // 2, cy)]
    elif facing == "down":
        pts = [(cx - size, cy - size // 2), (cx + size, cy - size // 2), (cx, cy + size // 2)]
    else:
        pts = [(cx - size, cy + size // 2), (cx + size, cy + size // 2), (cx, cy - size // 2)]
    pygame.draw.polygon(surface, color, pts)


KEY_FACE = (255, 253, 248)
KEY_EDGE = (176, 168, 156)
KEY_SHADOW = (146, 138, 126)

_ARROWS = {"up", "down", "left", "right"}


def keycap(surface, pos, label, size=15, center=False):
    """Tegner en tast, så et barn kan se præcis hvad der skal trykkes på."""
    if label in _ARROWS:
        w = 30
    else:
        w = max(30, font(size, True).size(label)[0] + 18)
    h = 28
    x, y = pos
    if center:
        x -= w // 2
    r = pygame.Rect(x, y, w, h)
    pygame.draw.rect(surface, KEY_SHADOW, (r.x, r.y + 3, r.w, r.h), border_radius=7)
    pygame.draw.rect(surface, KEY_FACE, r, border_radius=7)
    pygame.draw.rect(surface, KEY_EDGE, r, 2, border_radius=7)
    if label in _ARROWS:
        arrow(surface, (r.centerx, r.centery), label, INK, 7)
    else:
        text(surface, label, r.center, size=size, color=INK, bold=True, center=True)
    return r


def keyrow(surface, pos, items, size=15, right_align=False, gap=16,
           color=MUTED, shadow=False):
    """items: [(tast, forklaring)] – tegnes som en række taster med tekst."""
    widths = []
    for label, desc in items:
        kw = 30 if label in _ARROWS else max(30, font(size, True).size(label)[0] + 18)
        widths.append(kw + (6 + font(size).size(desc)[0] if desc else 0))
    total = sum(widths) + gap * (len(items) - 1)
    x, y = pos
    if right_align:
        x -= total
    for (label, desc), w in zip(items, widths):
        r = keycap(surface, (x, y), label, size)
        if desc:
            text(surface, desc, (r.right + 6, r.centery - font(size).get_height() // 2),
                 size=size, color=color, shadow=shadow)
        x += w + gap
    return total


def bar(surface, rect, pct, fill=GOOD, bg=(226, 220, 210), label=None):
    rect = pygame.Rect(rect)
    pygame.draw.rect(surface, bg, rect, border_radius=8)
    inner = rect.inflate(-6, -6)
    w = max(0, int(inner.w * max(0.0, min(1.0, pct))))
    if w > 0:
        pygame.draw.rect(surface, fill, (inner.x, inner.y, w, inner.h), border_radius=6)
        pygame.draw.rect(surface, (255, 255, 255, 60),
                         (inner.x, inner.y, w, max(2, inner.h // 3)), border_radius=6)
    pygame.draw.rect(surface, PAPER_EDGE, rect, 2, border_radius=8)
    if label:
        text(surface, label, rect.center, size=15, color=INK, bold=True, center=True)


class Typewriter:
    """Tekst der ruller frem tegn for tegn."""

    def __init__(self, speed=48.0):
        self.full = ""
        self.shown = 0.0
        self.speed = speed

    def set(self, s):
        self.full = s
        self.shown = 0.0

    def update(self, dt):
        if self.shown < len(self.full):
            self.shown = min(len(self.full), self.shown + self.speed * dt)

    @property
    def done(self):
        return self.shown >= len(self.full)

    def finish(self):
        self.shown = len(self.full)

    def visible(self):
        return self.full[: int(self.shown)]
