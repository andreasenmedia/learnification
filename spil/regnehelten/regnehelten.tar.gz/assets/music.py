"""
Baggrundsmusik, komponeret og synthesized i kode.

Der ligger ingen musikfiler på disken: hvert tema er nodedata, som bliver
regnet om til lyd. Musikken er derfor royaltyfri af den simple grund, at
den bliver til her.

Musikken skal kunne høres i en time uden at blive træls, så temaerne er
langsomme og luftige: lange toner, tydelige pauser, dæmpet lydstyrke og
en blød sinusklang. Hvert sted i spillet har sit eget tema.
"""

import math
import os
import sys
import threading
from array import array

import pygame

RATE = 22050

# I browseren (pygbag) findes der hverken tråde eller tid til at regne
# et minuts musik ud i Python. Der ligger temaerne i stedet færdige som
# ogg-filer, lavet af tools/build_web.py på forhånd.
WEB = sys.platform == "emscripten"
MUSIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "musik")

_STEPS = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def note_freq(name):
    """'C4', 'F#3', 'Bb4' -> frekvens i Hz."""
    letter = name[0].upper()
    i = 1
    semi = _STEPS[letter]
    while i < len(name) and name[i] in "#b":
        semi += 1 if name[i] == "#" else -1
        i += 1
    octave = int(name[i:])
    return 440.0 * (2 ** (((octave + 1) * 12 + semi - 69) / 12.0))


def seq(s):
    """'C4 - E4:2' -> [(node, antal slag)]. '-' er en pause."""
    out = []
    for tok in s.split():
        if ":" in tok:
            n, d = tok.split(":")
            dur = float(d)
        else:
            n, dur = tok, 1.0
        out.append((None if n == "-" else n, dur))
    return out


# --- Temaer --------------------------------------------------------------
# Langsomt tempo, få toner, god plads imellem dem. "pad" er lange, meget
# svage akkordtoner, der lægger en blød bund under melodien.

THEMES = {
    "cutscene": {          # klasselokalet i går: tungt, men ikke dystert
        "bpm": 60, "vol": 0.40,
        "melody": seq("A4:3 - G4:2 E4:4 - F4:3 - E4:2 D4:5 - "
                      "C4:3 - E4:2 A4:4 - G4:6 - -:2"),
        "pad": seq("A2:8 F2:8 C3:8 E2:8 A2:8 D3:8 E3:8 A2:8"),
    },
    "hjem": {              # morgen derhjemme: varmt og roligt
        "bpm": 68, "vol": 0.34,
        "melody": seq("F4:3 - A4:2 C5:4 - - A4:2 G4:2 F4:4 - "
                      "Bb4:3 - A4:2 G4:4 - - F4:4 - -:3"),
        "pad": seq("F2:8 F2:8 Bb2:8 C3:8 F2:8 Bb2:8 C3:8 F2:8"),
    },
    "by": {                # ude på vejen: lys og let
        "bpm": 80, "vol": 0.30,
        "melody": seq("G4:2 B4:2 D5:3 - B4:2 A4:3 - G4:4 - "
                      "C5:2 B4:2 A4:3 - G4:2 E4:3 - G4:4 -:2"),
        "pad": seq("G2:8 D3:8 E3:8 C3:8 G2:8 C3:8 D3:8 G2:8"),
    },
    "butik": {             # inde i butikken: småtravlt, men blødt
        "bpm": 84, "vol": 0.28,
        "melody": seq("C5:2 - E5:2 - D5:3 - C5:2 A4:3 - "
                      "F4:2 - A4:2 - G4:3 - E4:2 C4:3 - -:2"),
        "pad": seq("C3:8 A2:8 F2:8 G2:8 C3:8 F2:8 G2:8 C3:8"),
    },
    "skolegaard": {        # frikvarter: legende, men ikke hektisk
        "bpm": 88, "vol": 0.30,
        "melody": seq("E5:2 - C5:2 - G4:3 - A4:2 C5:3 - "
                      "D5:2 - B4:2 - G4:3 - A4:2 G4:4 - -:2"),
        "pad": seq("C3:8 G2:8 A2:8 F2:8 C3:8 G2:8 F2:8 C3:8"),
    },
    "skole": {             # inde på gangen: dæmpet og nysgerrigt
        "bpm": 72, "vol": 0.26,
        "melody": seq("D4:3 - F4:2 A4:4 - - G4:2 F4:4 - "
                      "E4:3 - G4:2 F4:4 - - D4:4 - -:3"),
        "pad": seq("D3:8 D3:8 Bb2:8 F2:8 C3:8 A2:8 D3:8 D3:8"),
    },
    "klasse": {            # klasselokalet: stille, fokuseret
        "bpm": 64, "vol": 0.26,
        "melody": seq("G4:4 - - E4:3 - C4:4 - - "
                      "F4:4 - - E4:3 - D4:4 - - -:2"),
        "pad": seq("C3:8 C3:8 A2:8 F2:8 G2:8 C3:8 G2:8 C3:8"),
    },
    "park": {              # parken: luftigt og åbent
        "bpm": 66, "vol": 0.30,
        "melody": seq("A4:3 - C5:2 E5:4 - - D5:2 C5:4 - "
                      "G4:3 - A4:2 C5:4 - - A4:4 - -:3"),
        "pad": seq("A2:8 E3:8 F2:8 C3:8 G2:8 D3:8 A2:8 A2:8"),
    },
    "bibliotek": {         # biblioteket: næsten stille
        "bpm": 58, "vol": 0.22,
        "melody": seq("E4:4 - - G4:4 - - A4:4 - - G4:4 - - "
                      "E4:4 - - D4:4 - - E4:6 - -:4"),
        "pad": seq("A2:8 A2:8 E3:8 E3:8 F2:8 C3:8 A2:8 A2:8"),
    },
    "kamp": {              # opgaverne: koncentreret, men venligt
        "bpm": 92, "vol": 0.30,
        "melody": seq("A4:2 C5:2 E5:3 - D5:2 C5:3 - B4:2 A4:3 - "
                      "E4:2 A4:2 C5:3 - B4:2 A4:4 - -:2"),
        "pad": seq("A2:8 A2:8 F2:8 C3:8 G2:8 E3:8 A2:8 A2:8"),
    },
    "slut": {              # slutningen: varmt og stolt
        "bpm": 74, "vol": 0.42,
        "melody": seq("C5:3 - E5:2 G5:4 - - E5:2 F5:3 - E5:4 - "
                      "D5:3 - C5:2 E5:4 - - C5:5 - -:3"),
        "pad": seq("C3:8 G2:8 A2:8 F2:8 F2:8 C3:8 G2:8 C3:8"),
    },
}

MAP_THEMES = {
    "hjem": "hjem", "gade": "by", "butik": "butik",
    "skolegaard": "skolegaard", "skole": "skole", "klasse": "klasse",
    "park": "park", "bibliotek": "bibliotek",
}


# --- Synth ---------------------------------------------------------------

_note_cache = {}


def _note(freq, dur, vol, soft):
    """Blød sinustone. soft=True giver en næsten ren tone til pad-laget."""
    key = (round(freq, 2), round(dur, 3), round(vol, 3), soft)
    cached = _note_cache.get(key)
    if cached is not None:
        return cached
    n = int(RATE * dur)
    buf = [0.0] * n
    attack = max(1, int(n * (0.22 if soft else 0.10)))
    release = max(1, int(n * 0.55))
    w = 2 * math.pi * freq
    h2 = 0.04 if soft else 0.12
    h3 = 0.0 if soft else 0.05
    for i in range(n):
        t = i / RATE
        v = math.sin(w * t) + h2 * math.sin(w * 2 * t) + h3 * math.sin(w * 3 * t)
        if i < attack:
            env = i / attack
        elif i > n - release:
            env = (n - i) / release
        else:
            env = 1.0
        buf[i] = v * (env ** 1.6) * vol
    _note_cache[key] = buf
    return buf


def _render(theme):
    """Tema -> rå 16-bit mono bytes."""
    spb = 60.0 / theme["bpm"]
    beats = max(sum(d for _, d in theme.get(t, [])) for t in ("melody", "pad"))
    n = int(RATE * beats * spb) + RATE
    mix = [0.0] * n

    for track, vol, soft in (("melody", 0.30, False), ("pad", 0.13, True)):
        notes = theme.get(track)
        if not notes:
            continue
        pos = 0.0
        for name, dur_beats in notes:
            dur = dur_beats * spb
            if name:
                buf = _note(note_freq(name), dur * 0.92, vol, soft)
                start = int(pos * RATE)
                for i, s in enumerate(buf):
                    j = start + i
                    if j < n:
                        mix[j] += s
            pos += dur

    peak = max(1e-6, max(abs(v) for v in mix))
    scale = (22000 * theme.get("vol", 0.3)) / peak
    out = array("h")
    for v in mix:
        out.append(int(max(-32000, min(32000, v * scale))))
    return out.tobytes()


class Music:
    def __init__(self, audio, volume=0.55):
        self.audio = audio
        self.volume = volume
        self.enabled = True
        self.current = None
        self.channel = None
        self._raw = {}
        self._sounds = {}
        self._lock = threading.Lock()
        if audio.ok:
            try:
                pygame.mixer.set_reserved(1)
                self.channel = pygame.mixer.Channel(0)
            except pygame.error:
                self.channel = None
        if WEB:
            self._thread = None     # temaerne indlæses fra ogg i _sound()
        else:
            self._thread = threading.Thread(target=self._prerender, daemon=True)
            self._thread.start()

    def _prerender(self):
        order = ["cutscene", "hjem", "kamp", "by", "butik", "skolegaard",
                 "skole", "klasse", "park", "bibliotek", "slut"]
        for name in order:
            try:
                data = _render(THEMES[name])
            except Exception:
                continue
            with self._lock:
                self._raw[name] = data

    def _sound(self, name):
        if name in self._sounds:
            return self._sounds[name]
        if WEB:
            try:
                snd = pygame.mixer.Sound(os.path.join(MUSIC_DIR, name + ".ogg"))
            except Exception:
                return None
            self._sounds[name] = snd
            return snd
        with self._lock:
            data = self._raw.get(name)
        if data is None:
            return None
        try:
            snd = pygame.mixer.Sound(buffer=data)
        except pygame.error:
            return None
        self._sounds[name] = snd
        return snd

    def play(self, name):
        if name == self.current:
            return
        self.current = name
        self._restart()

    def for_map(self, map_key):
        self.play(MAP_THEMES.get(map_key, "skole"))

    def _restart(self):
        if not self.channel or not self.enabled or self.audio.muted:
            if self.channel:
                self.channel.stop()
            return
        snd = self._sound(self.current)
        if snd is None:
            return          # ikke renderet endnu – prøves igen i update()
        snd.set_volume(self.volume)
        self.channel.play(snd, loops=-1, fade_ms=900)

    def update(self):
        if not self.channel or not self.enabled or self.audio.muted:
            return
        if self.current and not self.channel.get_busy():
            self._restart()

    def set_enabled(self, on):
        self.enabled = on
        if on:
            self._restart()
        elif self.channel:
            self.channel.fadeout(400)
        return self.enabled

    def toggle(self):
        return self.set_enabled(not self.enabled)

    def refresh_mute(self):
        if self.channel and (self.audio.muted or not self.enabled):
            self.channel.stop()
        else:
            self._restart()
