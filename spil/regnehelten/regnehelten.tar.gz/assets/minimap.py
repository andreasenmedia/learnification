"""
Minikort i hjørnet: hvor er jeg, hvor er dørene, og hvor skal jeg hen.

Den gule stjerne viser den person, man skal snakke med lige nu, så et barn
altid kan se, hvilken vej der er fremad.
"""

import math

import pygame

import ui
import world

WALL = (96, 92, 110)
FLOOR = (222, 216, 202)
OUTDOOR = (176, 206, 162)
ROAD = (198, 194, 188)
DOOR = (206, 138, 46)
PLAYER = (236, 96, 88)
NPC = (88, 128, 200)
GOAL = (244, 196, 64)

_TILE_COLORS = {
    "#": WALL, "B": WALL, "b": WALL, "h": (108, 150, 104), "~": (96, 150, 200),
    "g": OUTDOOR, "p": (206, 198, 178), "v": ROAD, "a": (150, 148, 152),
    "-": (150, 148, 152), "x": (214, 212, 206), "d": (176, 150, 116),
    "w": (198, 166, 128), "k": (232, 230, 222), "l": (220, 214, 198),
    "s": (238, 236, 232), "c": (198, 160, 156), "f": (226, 210, 168),
    "C": (140, 150, 164),
}

_static = {}


def _render_static(gmap, cell):
    key = (gmap.key, cell)
    if key in _static:
        return _static[key]
    surf = pygame.Surface((gmap.w * cell, gmap.h * cell))
    surf.fill(WALL)
    for y, row in enumerate(gmap.ground):
        for x, ch in enumerate(row):
            col = _TILE_COLORS.get(ch, FLOOR)
            pygame.draw.rect(surf, col, (x * cell, y * cell, cell, cell))
    # møbler og andet fast som svage prikker
    for (px, py, kind) in gmap.props:
        if kind in ("rug", "flowers", "door"):
            continue
        w, h, solid = world.PROP_INFO.get(kind, (1, 1, True))
        if not solid:
            continue
        for dy in range(h):
            for dx in range(w):
                tx, ty = px + dx, py - dy
                if 0 <= tx < gmap.w and 0 <= ty < gmap.h:
                    pygame.draw.rect(surf, (168, 160, 150),
                                     (tx * cell, ty * cell, cell, cell))
    _static[key] = surf
    return surf


def draw(surface, rect, gmap, player, chapter, t, title=None):
    cell = max(2, min(6, rect.w // max(gmap.w, gmap.h)))
    ui.panel(surface, rect, radius=12)

    inner = rect.inflate(-16, -16)
    if title:
        inner.y += 14
        inner.h -= 14
        ui.text(surface, title, (rect.centerx, rect.y + 6), size=15,
                color=ui.MUTED, bold=True, center=True)

    static = _render_static(gmap, cell)
    mw, mh = static.get_size()
    ox = inner.x + (inner.w - mw) // 2
    oy = inner.y + (inner.h - mh) // 2
    surface.blit(static, (ox, oy))
    pygame.draw.rect(surface, ui.PAPER_EDGE, (ox - 1, oy - 1, mw + 2, mh + 2), 1)

    def at(tx, ty):
        return ox + tx * cell + cell // 2, oy + ty * cell + cell // 2

    for (mk, x, y), p in world.PORTALS.items():
        if mk != gmap.key:
            continue
        locked = p.get("needs") is not None and chapter < p["needs"]
        col = (150, 146, 140) if locked else DOOR
        pygame.draw.rect(surface, col, (ox + x * cell, oy + y * cell,
                                        max(2, cell), max(2, cell)))

    goal = None
    for npc in world.npcs_for(gmap.key):
        cx, cy = at(npc["x"], npc["y"])
        if npc.get("chapter") == chapter:
            goal = (cx, cy)
        else:
            pygame.draw.circle(surface, NPC, (cx, cy), max(2, cell // 2))

    if goal:
        pulse = 3 + 1.5 * (1 + math.sin(t * 5))
        pygame.draw.circle(surface, GOAL, goal, int(pulse) + 2)
        pygame.draw.circle(surface, (150, 108, 20), goal, int(pulse) + 2, 1)

    px, py = player.tile()
    cx, cy = at(px, py)
    pygame.draw.circle(surface, (255, 255, 255), (cx, cy), max(3, cell // 2 + 2))
    pygame.draw.circle(surface, PLAYER, (cx, cy), max(2, cell // 2 + 1))
