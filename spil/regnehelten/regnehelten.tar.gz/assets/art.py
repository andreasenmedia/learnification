"""
Procedural grafik i DS-aera stil: tre-tone materialer, skyggede sprites,
og props med dybde. Ingen billedfiler paa disken - alt tegnes i kode.
"""

import zlib
import pygame

TILE = 32
CHAR_W, CHAR_H = 28, 40

# --- Palet ---------------------------------------------------------------

SKIN_TONES = [
    (255, 224, 196), (245, 205, 170), (222, 176, 136),
    (190, 139, 98), (142, 98, 66), (96, 64, 44),
]
HAIR_COLORS = [
    (44, 34, 30), (92, 58, 36), (150, 98, 48),
    (214, 168, 84), (190, 78, 52), (70, 70, 80),
]
CLOTH_COLORS = [
    (72, 122, 196), (206, 84, 96), (86, 168, 110),
    (222, 150, 62), (140, 96, 184), (64, 176, 180),
    (232, 132, 168), (90, 100, 116),
]


def shade(color, amount):
    """amount > 0 lysner, < 0 moerkner."""
    r, g, b = color[:3]
    if amount >= 0:
        return (
            min(255, int(r + (255 - r) * amount)),
            min(255, int(g + (255 - g) * amount)),
            min(255, int(b + (255 - b) * amount)),
        )
    a = -amount
    return (max(0, int(r * (1 - a))), max(0, int(g * (1 - a))), max(0, int(b * (1 - a))))


def _rng(key):
    import random
    return random.Random(zlib.crc32(str(key).encode()))


def block(surf, rect, color, depth=3, top_light=True):
    """Tre-tone kasse: base, lys overkant, moerk underkant."""
    x, y, w, h = rect
    pygame.draw.rect(surf, color, (x, y, w, h))
    if top_light:
        pygame.draw.rect(surf, shade(color, 0.22), (x, y, w, depth))
        pygame.draw.rect(surf, shade(color, 0.12), (x, y, depth, h))
    pygame.draw.rect(surf, shade(color, -0.3), (x, y + h - depth, w, depth))
    pygame.draw.rect(surf, shade(color, -0.18), (x + w - depth, y, depth, h))


def outline(surf, rect, color, width=1):
    pygame.draw.rect(surf, color, rect, width)


# --- Fliser --------------------------------------------------------------

_TILE_CACHE = {}


def tile(kind):
    if kind in _TILE_CACHE:
        return _TILE_CACHE[kind]
    s = pygame.Surface((TILE, TILE)).convert()
    r = _rng(kind)
    painter = _TILE_PAINTERS.get(kind, _t_void)
    painter(s, r)
    _TILE_CACHE[kind] = s
    return s


def _speckle(s, r, color, count, alpha=None):
    for _ in range(count):
        x, y = r.randrange(TILE), r.randrange(TILE)
        if alpha:
            dot = pygame.Surface((1, 1), pygame.SRCALPHA)
            dot.fill((*color, alpha))
            s.blit(dot, (x, y))
        else:
            s.set_at((x, y), color)


def _t_void(s, r):
    s.fill((18, 18, 24))


def _t_grass(s, r):
    base = (96, 158, 78)
    s.fill(base)
    _speckle(s, r, shade(base, -0.15), 70)
    _speckle(s, r, shade(base, 0.18), 50)
    for _ in range(9):
        x, y = r.randrange(2, TILE - 2), r.randrange(2, TILE - 3)
        c = shade(base, 0.3 if r.random() < 0.5 else -0.25)
        pygame.draw.line(s, c, (x, y + 3), (x, y), 1)
        pygame.draw.line(s, c, (x + 1, y + 3), (x + 2, y + 1), 1)


def _t_path(s, r):
    base = (196, 186, 166)
    s.fill(base)
    _speckle(s, r, shade(base, -0.12), 60)
    _speckle(s, r, shade(base, 0.15), 40)
    seam = shade(base, -0.3)
    pygame.draw.line(s, seam, (0, 0), (TILE, 0))
    pygame.draw.line(s, seam, (0, 0), (0, TILE))
    pygame.draw.line(s, shade(base, 0.2), (1, 1), (TILE, 1))


def _t_pavement(s, r):
    base = (176, 172, 168)
    s.fill(base)
    _speckle(s, r, shade(base, -0.14), 70)
    _speckle(s, r, shade(base, 0.12), 45)
    seam = shade(base, -0.28)
    pygame.draw.line(s, seam, (0, 15), (TILE, 15))
    pygame.draw.line(s, seam, (15, 0), (15, 15))
    pygame.draw.line(s, seam, (7, 16), (7, TILE))
    pygame.draw.line(s, seam, (23, 16), (23, TILE))
    pygame.draw.line(s, seam, (0, TILE - 1), (TILE, TILE - 1))


def _t_asphalt(s, r):
    base = (78, 78, 86)
    s.fill(base)
    _speckle(s, r, shade(base, -0.25), 90)
    _speckle(s, r, shade(base, 0.2), 60)
    if r.random() < 0.25:
        x = r.randrange(TILE)
        pygame.draw.line(s, shade(base, -0.4), (x, 0), (x + r.randrange(-4, 5), TILE), 1)


def _t_road_line(s, r):
    _t_asphalt(s, r)
    pygame.draw.rect(s, (226, 222, 200), (13, 4, 6, 24))
    pygame.draw.rect(s, (200, 196, 176), (13, 26, 6, 2))


def _t_crosswalk(s, r):
    _t_asphalt(s, r)
    for x in (2, 12, 22):
        pygame.draw.rect(s, (230, 228, 214), (x, 0, 7, TILE))
        pygame.draw.rect(s, (198, 196, 182), (x, TILE - 3, 7, 3))


def _t_dirt(s, r):
    base = (150, 118, 84)
    s.fill(base)
    _speckle(s, r, shade(base, -0.2), 80)
    _speckle(s, r, shade(base, 0.16), 50)


def _t_wood(s, r):
    base = (176, 130, 84)
    s.fill(base)
    for i in range(0, TILE, 8):
        pygame.draw.line(s, shade(base, -0.22), (0, i), (TILE, i))
        pygame.draw.line(s, shade(base, 0.16), (0, i + 1), (TILE, i + 1))
        for _ in range(6):
            x = r.randrange(TILE)
            pygame.draw.line(s, shade(base, -0.1), (x, i + 3), (x + r.randrange(2, 6), i + 3))


def _t_kitchen_tile(s, r):
    base = (224, 222, 214)
    s.fill(base)
    seam = shade(base, -0.22)
    pygame.draw.line(s, seam, (0, 0), (TILE, 0))
    pygame.draw.line(s, seam, (0, 0), (0, TILE))
    pygame.draw.line(s, seam, (16, 0), (16, TILE))
    pygame.draw.line(s, seam, (0, 16), (TILE, 16))
    _speckle(s, r, shade(base, -0.06), 30)


def _t_lino(s, r):
    base = (206, 198, 178)
    s.fill(base)
    _speckle(s, r, shade(base, -0.1), 70)
    _speckle(s, r, shade(base, 0.12), 40)
    pygame.draw.line(s, shade(base, -0.16), (0, 0), (TILE, 0))
    pygame.draw.line(s, shade(base, -0.16), (0, 0), (0, TILE))


def _t_shopfloor(s, r):
    base = (232, 230, 226)
    s.fill(base)
    seam = shade(base, -0.16)
    pygame.draw.line(s, seam, (0, 0), (TILE, 0))
    pygame.draw.line(s, seam, (0, 0), (0, TILE))
    _speckle(s, r, shade(base, -0.05), 25)


def _t_carpet(s, r):
    base = (150, 84, 88)
    s.fill(base)
    _speckle(s, r, shade(base, -0.18), 120)
    _speckle(s, r, shade(base, 0.16), 90)


def _t_wall(s, r):
    base = (206, 196, 180)
    s.fill(base)
    _speckle(s, r, shade(base, -0.07), 40)
    pygame.draw.rect(s, shade(base, 0.16), (0, 0, TILE, 3))
    pygame.draw.rect(s, shade(base, -0.28), (0, TILE - 5, TILE, 5))
    pygame.draw.rect(s, shade(base, -0.42), (0, TILE - 2, TILE, 2))


def _t_wall_blue(s, r):
    base = (150, 178, 202)
    s.fill(base)
    _speckle(s, r, shade(base, -0.07), 40)
    pygame.draw.rect(s, shade(base, 0.18), (0, 0, TILE, 3))
    pygame.draw.rect(s, shade(base, -0.3), (0, TILE - 5, TILE, 5))


def _t_brick(s, r):
    base = (168, 92, 74)
    s.fill(shade(base, -0.4))
    for row in range(4):
        y = row * 8
        off = 0 if row % 2 == 0 else 8
        for col in range(-1, 3):
            x = col * 16 + off
            c = shade(base, r.uniform(-0.12, 0.12))
            pygame.draw.rect(s, c, (x + 1, y + 1, 14, 6))
            pygame.draw.line(s, shade(c, 0.2), (x + 1, y + 1), (x + 14, y + 1))


def _t_hedge(s, r):
    base = (58, 118, 62)
    s.fill(base)
    _speckle(s, r, shade(base, -0.25), 120)
    _speckle(s, r, shade(base, 0.22), 90)
    pygame.draw.rect(s, shade(base, 0.2), (0, 0, TILE, 3))


def _t_water(s, r):
    base = (74, 132, 190)
    s.fill(base)
    for y in range(0, TILE, 6):
        pygame.draw.line(s, shade(base, 0.18), (0, y), (TILE, y))
        pygame.draw.line(s, shade(base, -0.15), (0, y + 3), (TILE, y + 3))


def _t_sand(s, r):
    base = (222, 200, 150)
    s.fill(base)
    _speckle(s, r, shade(base, -0.12), 80)
    _speckle(s, r, shade(base, 0.12), 60)


def _t_court(s, r):
    base = (92, 104, 122)
    s.fill(base)
    _speckle(s, r, shade(base, -0.18), 70)
    pygame.draw.line(s, (232, 228, 210), (0, 4), (TILE, 4), 2)


_TILE_PAINTERS = {
    "grass": _t_grass, "path": _t_path, "pavement": _t_pavement,
    "asphalt": _t_asphalt, "road_line": _t_road_line, "crosswalk": _t_crosswalk,
    "dirt": _t_dirt, "wood": _t_wood, "ktile": _t_kitchen_tile,
    "lino": _t_lino, "shopfloor": _t_shopfloor, "carpet": _t_carpet,
    "wall": _t_wall, "wall_blue": _t_wall_blue, "brick": _t_brick,
    "hedge": _t_hedge, "water": _t_water, "sand": _t_sand, "court": _t_court,
    "void": _t_void,
}


def grass_fringe():
    """Overlay der bloeder graes ind over en flisekant."""
    s = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    r = _rng("fringe")
    for x in range(TILE):
        h = 2 + int(2.5 * (1 + __import__("math").sin(x * 0.7)))
        for y in range(h):
            if r.random() < 0.75:
                s.set_at((x, y), (*shade((96, 158, 78), r.uniform(-0.2, 0.2)), 255))
    return s


# --- Props ---------------------------------------------------------------

_PROP_CACHE = {}


def prop(kind):
    if kind in _PROP_CACHE:
        return _PROP_CACHE[kind]
    painter = _PROP_PAINTERS.get(kind)
    if painter is None:
        s = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    else:
        s = painter()
    _PROP_CACHE[kind] = s
    return s


def _surf(w, h):
    return pygame.Surface((w, h), pygame.SRCALPHA)


def _shadow(s, cx, by, rx, ry=None):
    ry = ry or max(3, rx // 3)
    sh = _surf(rx * 2, ry * 2)
    pygame.draw.ellipse(sh, (0, 0, 0, 70), (0, 0, rx * 2, ry * 2))
    s.blit(sh, (cx - rx, by - ry))


def _p_tree():
    s = _surf(TILE * 2, TILE * 3)
    cx = TILE
    _shadow(s, cx, TILE * 3 - 8, 22, 8)
    trunk = (108, 76, 48)
    block(s, (cx - 6, TILE * 3 - 34, 12, 30), trunk, depth=2)
    for i, (dy, rad, col) in enumerate([
        (0, 30, (48, 104, 58)), (10, 26, (66, 132, 70)), (20, 20, (92, 164, 88))
    ]):
        pygame.draw.circle(s, col, (cx, 38 + dy - 8), rad)
    r = _rng("tree")
    for _ in range(90):
        a = r.uniform(0, 6.283)
        rad = r.uniform(0, 26)
        import math
        x = cx + int(math.cos(a) * rad)
        y = 36 + int(math.sin(a) * rad * 0.8)
        if 0 <= x < TILE * 2 and 0 <= y < TILE * 3:
            if s.get_at((x, y))[3] > 0:
                s.set_at((x, y), (*shade((70, 140, 76), r.uniform(-0.25, 0.3)), 255))
    return s


def _p_bush():
    s = _surf(TILE, TILE)
    _shadow(s, 16, 28, 12, 5)
    for dx, dy, rad, col in [(10, 20, 9, (52, 112, 60)), (21, 20, 9, (52, 112, 60)),
                             (16, 15, 11, (76, 146, 78))]:
        pygame.draw.circle(s, col, (dx, dy), rad)
    r = _rng("bush")
    for _ in range(40):
        x, y = r.randrange(TILE), r.randrange(8, TILE)
        if s.get_at((x, y))[3] > 0:
            s.set_at((x, y), (*shade((70, 140, 76), r.uniform(-0.3, 0.3)), 255))
    return s


def _p_lamp():
    s = _surf(TILE, TILE * 3)
    _shadow(s, 16, TILE * 3 - 6, 9, 4)
    block(s, (13, 20, 6, TILE * 3 - 26), (96, 100, 110), depth=2)
    block(s, (8, 12, 16, 10), (70, 74, 84), depth=2)
    pygame.draw.rect(s, (248, 232, 170), (10, 18, 12, 4))
    return s


def _p_bench():
    s = _surf(TILE * 2, TILE)
    _shadow(s, TILE, 28, 26, 5)
    block(s, (4, 14, 56, 8), (150, 106, 62), depth=2)
    block(s, (4, 4, 56, 7), (168, 122, 74), depth=2)
    block(s, (8, 20, 5, 9), (90, 94, 102), depth=2)
    block(s, (51, 20, 5, 9), (90, 94, 102), depth=2)
    return s


def _p_bed():
    s = _surf(TILE * 2, TILE * 2)
    _shadow(s, TILE, TILE * 2 - 6, 28, 6)
    block(s, (4, 10, 56, 50), (138, 96, 60), depth=3)
    block(s, (7, 14, 50, 42), (232, 228, 236), depth=2)
    block(s, (10, 16, 44, 14), (240, 240, 244), depth=2)
    block(s, (7, 32, 50, 24), (86, 138, 206), depth=2)
    pygame.draw.line(s, shade((86, 138, 206), -0.2), (7, 44), (57, 44), 2)
    return s


def _p_desk():
    s = _surf(TILE * 2, TILE + 12)
    _shadow(s, TILE, TILE + 8, 26, 6)
    block(s, (2, 6, 60, 22), (164, 122, 78), depth=3)
    block(s, (6, 26, 6, 14), (130, 96, 62), depth=2)
    block(s, (52, 26, 6, 14), (130, 96, 62), depth=2)
    block(s, (18, 0, 26, 10), (60, 64, 74), depth=2)
    pygame.draw.rect(s, (120, 190, 220), (21, 2, 20, 6))
    return s


def _p_chair():
    s = _surf(TILE, TILE + 8)
    _shadow(s, 16, TILE + 4, 12, 5)
    block(s, (7, 4, 18, 18), (150, 108, 66), depth=2)
    block(s, (7, 20, 18, 8), (170, 126, 78), depth=2)
    block(s, (9, 28, 4, 10), (120, 88, 56), depth=2)
    block(s, (19, 28, 4, 10), (120, 88, 56), depth=2)
    return s


def _p_table():
    s = _surf(TILE * 2, TILE + 12)
    _shadow(s, TILE, TILE + 8, 28, 6)
    block(s, (2, 4, 60, 24), (186, 142, 92), depth=3)
    block(s, (6, 28, 6, 12), (140, 104, 66), depth=2)
    block(s, (52, 28, 6, 12), (140, 104, 66), depth=2)
    return s


def _p_sofa():
    s = _surf(TILE * 2, TILE + 16)
    _shadow(s, TILE, TILE + 12, 28, 6)
    c = (108, 128, 176)
    block(s, (2, 4, 60, 20), c, depth=3)
    block(s, (2, 20, 60, 20), shade(c, 0.12), depth=3)
    block(s, (0, 14, 10, 28), shade(c, -0.15), depth=2)
    block(s, (54, 14, 10, 28), shade(c, -0.15), depth=2)
    return s


def _p_tv():
    s = _surf(TILE + 16, TILE + 8)
    _shadow(s, 24, TILE + 4, 18, 5)
    block(s, (4, 4, 40, 26), (42, 44, 52), depth=2)
    pygame.draw.rect(s, (96, 148, 190), (7, 7, 34, 20))
    pygame.draw.rect(s, (140, 190, 225), (9, 9, 14, 8))
    block(s, (20, 30, 8, 8), (60, 62, 70), depth=2)
    return s


def _p_fridge():
    s = _surf(TILE, TILE * 2)
    _shadow(s, 16, TILE * 2 - 6, 15, 5)
    block(s, (3, 6, 26, 52), (226, 228, 232), depth=3)
    pygame.draw.line(s, (180, 184, 190), (3, 26), (29, 26), 2)
    block(s, (22, 12, 3, 10), (150, 154, 162), depth=1)
    block(s, (22, 32, 3, 10), (150, 154, 162), depth=1)
    return s


def _p_stove():
    s = _surf(TILE, TILE + 8)
    _shadow(s, 16, TILE + 4, 14, 5)
    block(s, (3, 8, 26, 30), (206, 208, 214), depth=2)
    block(s, (3, 2, 26, 8), (80, 84, 92), depth=2)
    for cx, cy in ((10, 5), (22, 5)):
        pygame.draw.circle(s, (48, 50, 56), (cx, cy), 3)
    pygame.draw.rect(s, (120, 170, 210), (7, 18, 18, 12))
    return s


def _p_counter():
    s = _surf(TILE, TILE + 6)
    _shadow(s, 16, TILE + 2, 14, 5)
    block(s, (0, 6, 32, 32), (196, 160, 116), depth=3)
    block(s, (0, 2, 32, 8), (150, 152, 158), depth=2)
    return s


def _p_sink():
    s = _p_counter().copy()
    pygame.draw.rect(s, (170, 176, 184), (7, 6, 18, 10))
    pygame.draw.rect(s, (140, 146, 154), (9, 8, 14, 6))
    pygame.draw.rect(s, (190, 194, 200), (15, 2, 3, 6))
    return s


def _p_plant():
    s = _surf(TILE, TILE + 10)
    _shadow(s, 16, TILE + 6, 11, 4)
    block(s, (10, 26, 13, 14), (168, 104, 74), depth=2)
    for dx, dy in ((16, 18), (10, 22), (22, 22), (16, 12)):
        pygame.draw.circle(s, (70, 142, 76), (dx, dy), 7)
        pygame.draw.circle(s, (92, 168, 92), (dx - 2, dy - 2), 4)
    return s


def _p_bookshelf():
    s = _surf(TILE, TILE * 2)
    _shadow(s, 16, TILE * 2 - 6, 15, 5)
    block(s, (2, 4, 28, 54), (140, 100, 62), depth=3)
    r = _rng("books")
    for row in range(3):
        y = 10 + row * 16
        x = 6
        while x < 26:
            w = r.randrange(3, 6)
            c = CLOTH_COLORS[r.randrange(len(CLOTH_COLORS))]
            pygame.draw.rect(s, c, (x, y, w, 12))
            pygame.draw.rect(s, shade(c, 0.2), (x, y, w, 2))
            x += w + 1
        pygame.draw.rect(s, (110, 78, 48), (4, y + 12, 24, 3))
    return s


def _p_locker():
    s = _surf(TILE, TILE * 2)
    _shadow(s, 16, TILE * 2 - 6, 15, 5)
    c = (96, 138, 168)
    block(s, (2, 4, 28, 54), c, depth=3)
    pygame.draw.line(s, shade(c, -0.35), (16, 6), (16, 56), 2)
    for x in (9, 23):
        for y in (14, 40):
            pygame.draw.rect(s, shade(c, -0.4), (x - 2, y, 4, 2))
            pygame.draw.circle(s, shade(c, 0.25), (x, y + 8), 2)
    return s


def _p_whiteboard():
    s = _surf(TILE * 3, TILE + 10)
    block(s, (2, 2, 92, 34), (238, 240, 242), depth=3)
    outline(s, (2, 2, 92, 34), (150, 152, 160), 2)
    r = _rng("board")
    for i in range(5):
        y = 8 + i * 5
        pygame.draw.line(s, (90, 120, 190), (8, y), (8 + r.randrange(20, 70), y), 1)
    block(s, (2, 36, 92, 5), (170, 172, 178), depth=2)
    return s


def _p_teacher_desk():
    s = _surf(TILE * 2, TILE + 14)
    _shadow(s, TILE, TILE + 10, 28, 6)
    block(s, (2, 4, 60, 26), (128, 92, 58), depth=3)
    block(s, (4, 30, 56, 12), (110, 78, 50), depth=2)
    pygame.draw.rect(s, (240, 240, 236), (12, 8, 16, 12))
    pygame.draw.rect(s, (206, 96, 84), (36, 10, 14, 8))
    return s


def _p_shelf():
    s = _surf(TILE, TILE * 2)
    _shadow(s, 16, TILE * 2 - 6, 15, 5)
    block(s, (1, 2, 30, 56), (176, 178, 184), depth=3)
    r = _rng("shelf")
    for row in range(3):
        y = 6 + row * 17
        x = 4
        while x < 28:
            w = r.randrange(4, 8)
            c = CLOTH_COLORS[r.randrange(len(CLOTH_COLORS))]
            h = r.randrange(8, 13)
            pygame.draw.rect(s, c, (x, y + (13 - h), w, h))
            pygame.draw.rect(s, shade(c, 0.25), (x, y + (13 - h), w, 2))
            x += w + 2
        pygame.draw.rect(s, (150, 152, 158), (1, y + 13, 30, 3))
    return s


def _p_produce():
    s = _surf(TILE, TILE + 8)
    _shadow(s, 16, TILE + 4, 14, 5)
    block(s, (2, 10, 28, 28), (162, 118, 76), depth=2)
    r = _rng("produce")
    colors = [(206, 72, 60), (240, 172, 56), (110, 176, 78), (226, 124, 64)]
    for _ in range(14):
        x, y = r.randrange(5, 27), r.randrange(12, 26)
        c = colors[r.randrange(len(colors))]
        pygame.draw.circle(s, c, (x, y), 3)
        pygame.draw.circle(s, shade(c, 0.3), (x - 1, y - 1), 1)
    return s


def _p_freezer():
    s = _surf(TILE * 2, TILE + 10)
    _shadow(s, TILE, TILE + 6, 28, 5)
    block(s, (2, 6, 60, 32), (188, 196, 206), depth=3)
    pygame.draw.rect(s, (150, 190, 214), (7, 11, 50, 20))
    r = _rng("freezer")
    for _ in range(18):
        x, y = r.randrange(9, 55), r.randrange(13, 29)
        pygame.draw.rect(s, (226, 236, 244), (x, y, 4, 3))
    return s


def _p_checkout():
    s = _surf(TILE * 2, TILE + 12)
    _shadow(s, TILE, TILE + 8, 28, 6)
    block(s, (2, 10, 60, 28), (150, 154, 162), depth=3)
    block(s, (6, 4, 34, 10), (60, 64, 72), depth=2)
    pygame.draw.rect(s, (120, 200, 150), (9, 6, 28, 6))
    block(s, (44, 2, 14, 12), (200, 202, 208), depth=2)
    return s


def _p_goal():
    s = _surf(TILE * 3, TILE * 2)
    _shadow(s, TILE + 16, TILE * 2 - 6, 40, 6)
    c = (232, 234, 238)
    block(s, (4, 8, 6, 52), c, depth=2)
    block(s, (86, 8, 6, 52), c, depth=2)
    block(s, (4, 8, 88, 6), c, depth=2)
    net = pygame.Surface((80, 46), pygame.SRCALPHA)
    for x in range(0, 80, 6):
        pygame.draw.line(net, (255, 255, 255, 90), (x, 0), (x, 46))
    for y in range(0, 46, 6):
        pygame.draw.line(net, (255, 255, 255, 90), (0, y), (80, y))
    s.blit(net, (8, 14))
    return s


def _p_bikerack():
    s = _surf(TILE * 2, TILE)
    _shadow(s, TILE, 28, 24, 5)
    for x in range(6, 60, 10):
        block(s, (x, 10, 4, 18), (120, 124, 132), depth=1)
    block(s, (2, 24, 60, 5), (100, 104, 112), depth=2)
    return s


def _p_noticeboard():
    s = _surf(TILE * 2, TILE + 6)
    block(s, (2, 2, 60, 32), (150, 110, 70), depth=3)
    pygame.draw.rect(s, (110, 80, 52), (6, 6, 52, 24))
    r = _rng("notice")
    for _ in range(6):
        x, y = r.randrange(8, 48), r.randrange(8, 24)
        c = [(240, 240, 236), (250, 226, 150), (200, 220, 245)][r.randrange(3)]
        pygame.draw.rect(s, c, (x, y, 8, 6))
    return s


def _p_trashcan():
    s = _surf(TILE, TILE + 6)
    _shadow(s, 16, TILE + 2, 11, 4)
    block(s, (8, 12, 17, 26), (80, 110, 86), depth=2)
    block(s, (6, 8, 21, 6), (64, 92, 70), depth=2)
    return s


def _p_sign_shop():
    s = _surf(TILE * 3, TILE)
    block(s, (2, 4, 92, 24), (208, 68, 60), depth=3)
    pygame.draw.rect(s, (240, 220, 120), (8, 10, 80, 3))
    pygame.draw.rect(s, (240, 220, 120), (8, 17, 56, 3))
    return s


def _p_door():
    s = _surf(TILE, TILE + 8)
    block(s, (3, 2, 26, 38), (128, 88, 54), depth=3)
    pygame.draw.rect(s, (150, 106, 64), (6, 6, 20, 14))
    pygame.draw.rect(s, (150, 106, 64), (6, 22, 20, 14))
    pygame.draw.circle(s, (230, 200, 120), (24, 22), 2)
    return s


def _p_rug():
    s = _surf(TILE * 2, TILE)
    c = (176, 92, 96)
    pygame.draw.rect(s, c, (0, 2, 64, 28))
    pygame.draw.rect(s, shade(c, 0.2), (4, 6, 56, 20))
    pygame.draw.rect(s, c, (8, 10, 48, 12))
    return s


def _p_tray_table():
    s = _surf(TILE * 3, TILE + 10)
    _shadow(s, TILE + 16, TILE + 6, 42, 6)
    block(s, (2, 6, 92, 20), (196, 168, 120), depth=3)
    block(s, (8, 26, 6, 14), (140, 120, 86), depth=2)
    block(s, (82, 26, 6, 14), (140, 120, 86), depth=2)
    for x in (14, 44, 70):
        pygame.draw.rect(s, (220, 120, 100), (x, 10, 14, 10))
        pygame.draw.rect(s, (240, 160, 130), (x + 2, 12, 10, 6))
    return s


def _p_flowers():
    s = _surf(TILE, TILE)
    r = _rng("flowers")
    for _ in range(12):
        x, y = r.randrange(4, 28), r.randrange(10, 28)
        c = [(236, 118, 140), (250, 214, 96), (220, 234, 250)][r.randrange(3)]
        pygame.draw.line(s, (72, 132, 70), (x, y), (x, y + 5))
        pygame.draw.circle(s, c, (x, y), 2)
    return s


_PROP_PAINTERS = {
    "tree": _p_tree, "bush": _p_bush, "lamp": _p_lamp, "bench": _p_bench,
    "bed": _p_bed, "desk": _p_desk, "chair": _p_chair, "table": _p_table,
    "sofa": _p_sofa, "tv": _p_tv, "fridge": _p_fridge, "stove": _p_stove,
    "counter": _p_counter, "sink": _p_sink, "plant": _p_plant,
    "bookshelf": _p_bookshelf, "locker": _p_locker, "whiteboard": _p_whiteboard,
    "teacher_desk": _p_teacher_desk, "shelf": _p_shelf, "produce": _p_produce,
    "freezer": _p_freezer, "checkout": _p_checkout, "goal": _p_goal,
    "bikerack": _p_bikerack, "noticeboard": _p_noticeboard, "trashcan": _p_trashcan,
    "sign_shop": _p_sign_shop, "door": _p_door, "rug": _p_rug,
    "tray_table": _p_tray_table, "flowers": _p_flowers,
}

# Props der tegnes i aktoer-laget (kan staa foran/bag spilleren)
TALL_PROPS = {
    "tree", "lamp", "bed", "desk", "table", "sofa", "tv", "fridge", "stove",
    "counter", "sink", "plant", "bookshelf", "locker", "whiteboard",
    "teacher_desk", "shelf", "produce", "freezer", "checkout", "goal",
    "bikerack", "noticeboard", "trashcan", "sign_shop", "bench", "bush",
    "chair", "tray_table",
}


# --- Karakter-sprites ----------------------------------------------------

DIRS = ("down", "up", "left", "right")
_CHAR_CACHE = {}

LEG_CYCLE = [(0, 0), (-2, 1), (0, 0), (2, 1)]
ARM_CYCLE = [0, 1, 0, -1]


def character_sprite(app, direction, frame):
    key = (tuple(sorted((k, tuple(v) if isinstance(v, (list, tuple)) else v)
                        for k, v in app.items())), direction, frame)
    if key in _CHAR_CACHE:
        return _CHAR_CACHE[key]
    s = _draw_character(app, direction, frame)
    _CHAR_CACHE[key] = s
    return s


def _draw_character(app, direction, frame):
    s = _surf(CHAR_W, CHAR_H)
    skin = tuple(app.get("skin", SKIN_TONES[1]))
    hair = tuple(app.get("hair", HAIR_COLORS[1]))
    shirt = tuple(app.get("shirt", CLOTH_COLORS[0]))
    pants = tuple(app.get("pants", (78, 86, 112)))
    style = app.get("hair_style", "kort")
    extra = app.get("extra", "ingen")

    _shadow(s, CHAR_W // 2, CHAR_H - 3, 10, 4)

    lx, ly = LEG_CYCLE[frame % 4]
    arm = ARM_CYCLE[frame % 4]

    # Ben
    block(s, (9 - lx, 29 + ly, 5, 9), pants, depth=2)
    block(s, (15 + lx, 29 - ly, 5, 9), shade(pants, -0.1), depth=2)
    # Sko
    pygame.draw.rect(s, (54, 50, 56), (9 - lx, 36 + ly, 5, 3))
    pygame.draw.rect(s, (54, 50, 56), (15 + lx, 36 - ly, 5, 3))

    if direction in ("left", "right"):
        body = (8, 17, 12, 13)
    else:
        body = (7, 17, 14, 13)
    block(s, body, shirt, depth=3)
    pygame.draw.rect(s, shade(shirt, 0.18), (body[0], body[1], body[2], 3))
    pygame.draw.rect(s, shade(shirt, -0.22), (body[0] + body[2] - 3, body[1], 3, body[3]))

    # Arme
    if direction == "left":
        block(s, (5, 18 + arm, 4, 10), shade(shirt, -0.12), depth=1)
        pygame.draw.rect(s, skin, (5, 26 + arm, 4, 3))
    elif direction == "right":
        block(s, (19, 18 - arm, 4, 10), shade(shirt, -0.12), depth=1)
        pygame.draw.rect(s, skin, (19, 26 - arm, 4, 3))
    else:
        block(s, (4, 18 + arm, 4, 10), shade(shirt, -0.08), depth=1)
        block(s, (20, 18 - arm, 4, 10), shade(shirt, -0.16), depth=1)
        pygame.draw.rect(s, skin, (4, 26 + arm, 4, 3))
        pygame.draw.rect(s, skin, (20, 26 - arm, 4, 3))

    # Hoved
    head = pygame.Rect(8, 5, 12, 13)
    pygame.draw.rect(s, skin, head)
    pygame.draw.rect(s, shade(skin, 0.15), (head.x, head.y, head.w, 2))
    pygame.draw.rect(s, shade(skin, -0.18), (head.right - 2, head.y, 2, head.h))
    pygame.draw.rect(s, shade(skin, -0.12), (head.x, head.bottom - 2, head.w, 2))

    # Haar
    if style == "kasket":
        pygame.draw.rect(s, hair, (7, 3, 14, 5))
        pygame.draw.rect(s, shade(hair, 0.2), (7, 3, 14, 2))
        if direction == "down":
            pygame.draw.rect(s, shade(hair, -0.2), (6, 8, 16, 2))
        elif direction == "left":
            pygame.draw.rect(s, shade(hair, -0.2), (4, 8, 10, 2))
        elif direction == "right":
            pygame.draw.rect(s, shade(hair, -0.2), (14, 8, 10, 2))
    elif style == "lang":
        pygame.draw.rect(s, hair, (6, 3, 16, 7))
        pygame.draw.rect(s, hair, (5, 6, 4, 14))
        pygame.draw.rect(s, hair, (19, 6, 4, 14))
        pygame.draw.rect(s, shade(hair, 0.22), (6, 3, 16, 2))
        pygame.draw.rect(s, shade(hair, -0.2), (19, 6, 4, 14))
    elif style == "kroeller":
        for cx, cy in ((9, 5), (13, 3), (17, 5), (7, 8), (20, 8)):
            pygame.draw.circle(s, hair, (cx, cy), 3)
        pygame.draw.circle(s, shade(hair, 0.22), (12, 3), 2)
    else:  # kort
        pygame.draw.rect(s, hair, (7, 3, 14, 5))
        pygame.draw.rect(s, shade(hair, 0.2), (7, 3, 14, 2))
        if direction != "up":
            pygame.draw.rect(s, hair, (7, 6, 2, 4))
            pygame.draw.rect(s, hair, (19, 6, 2, 4))

    # Ansigt
    if direction == "down":
        pygame.draw.rect(s, (40, 36, 40), (11, 11, 2, 2))
        pygame.draw.rect(s, (40, 36, 40), (16, 11, 2, 2))
        pygame.draw.rect(s, shade(skin, -0.3), (13, 15, 3, 1))
    elif direction == "left":
        pygame.draw.rect(s, (40, 36, 40), (10, 11, 2, 2))
    elif direction == "right":
        pygame.draw.rect(s, (40, 36, 40), (17, 11, 2, 2))

    if extra in ("briller", "briller+taske") and direction != "up":
        pygame.draw.rect(s, (60, 64, 76), (10, 10, 3, 3), 1)
        pygame.draw.rect(s, (60, 64, 76), (15, 10, 3, 3), 1)
        pygame.draw.line(s, (60, 64, 76), (13, 11), (15, 11))
    if extra in ("taske", "briller+taske"):
        c = (160, 90, 70)
        if direction == "up":
            block(s, (9, 18, 11, 12), c, depth=2)
        elif direction == "left":
            block(s, (18, 20, 5, 9), c, depth=1)
        elif direction == "right":
            block(s, (5, 20, 5, 9), c, depth=1)
        else:
            pygame.draw.rect(s, shade(c, -0.1), (8, 19, 2, 9))
            pygame.draw.rect(s, shade(c, -0.1), (18, 19, 2, 9))

    return s


def bubble(kind):
    """'!' eller '?' boble over NPC'er."""
    s = _surf(16, 18)
    pygame.draw.ellipse(s, (255, 255, 255), (0, 0, 16, 14))
    pygame.draw.ellipse(s, (60, 64, 76), (0, 0, 16, 14), 2)
    pygame.draw.polygon(s, (255, 255, 255), [(6, 12), (10, 12), (7, 17)])
    color = (214, 88, 72) if kind == "!" else (72, 120, 200)
    if kind == "!":
        pygame.draw.rect(s, color, (7, 3, 3, 6))
        pygame.draw.rect(s, color, (7, 10, 3, 2))
    else:
        pygame.draw.arc(s, color, (4, 2, 9, 8), 0.6, 3.6, 2)
        pygame.draw.rect(s, color, (7, 7, 2, 3))
        pygame.draw.rect(s, color, (7, 11, 2, 2))
    return s
