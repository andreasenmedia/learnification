"""
Verden: kort, kollision, døre, NPC'er og ting man kan undersøge.

Et kort består af et ASCII-gulvlag plus lister med rekvisitter, NPC'er,
døre og ting man kan kigge på. Alt ligger i felter (tiles); spilleren
bevæger sig frit i pixels ovenpå.
"""

import pygame

import art
from art import TILE

GROUND = {
    "g": "grass", "p": "path", "v": "pavement", "a": "asphalt",
    "-": "road_line", "x": "crosswalk", "d": "dirt", "w": "wood",
    "k": "ktile", "l": "lino", "s": "shopfloor", "c": "carpet",
    "#": "wall", "B": "wall_blue", "b": "brick", "h": "hedge",
    "~": "water", "f": "sand", "C": "court",
}
SOLID_GROUND = {"#", "B", "b", "h", "~"}

# prop -> (bredde, højde i felter, fast?)
PROP_INFO = {
    "tree": (1, 1, True), "bush": (1, 1, True), "lamp": (1, 1, True),
    "bench": (2, 1, True), "bed": (2, 2, True), "desk": (2, 1, True),
    "chair": (1, 1, True), "table": (2, 1, True), "sofa": (2, 1, True),
    "tv": (1, 1, True), "fridge": (1, 1, True), "stove": (1, 1, True),
    "counter": (1, 1, True), "sink": (1, 1, True), "plant": (1, 1, True),
    "bookshelf": (1, 1, True), "locker": (1, 1, True), "whiteboard": (3, 1, True),
    "teacher_desk": (2, 1, True), "shelf": (1, 1, True), "produce": (1, 1, True),
    "freezer": (2, 1, True), "checkout": (2, 1, True), "goal": (3, 1, True),
    "bikerack": (2, 1, True), "noticeboard": (2, 1, True), "trashcan": (1, 1, True),
    "sign_shop": (3, 1, False), "rug": (2, 1, False), "tray_table": (3, 1, True),
    "flowers": (1, 1, False), "door": (1, 1, False),
}


def _rows(*rows):
    w = len(rows[0])
    for i, r in enumerate(rows):
        if len(r) != w:
            raise ValueError(f"række {i} er {len(r)} tegn, forventede {w}: {r!r}")
    return list(rows)


HJEM = _rows(
    "########################",
    "#wwwwwwwww#kkkkkkkkkkkk#",
    "#wwwwwwwww#kkkkkkkkkkkk#",
    "#wwwwwwwww#kkkkkkkkkkkk#",
    "#wwwwwwwww#kkkkkkkkkkkk#",
    "#wwwwwwwww#kkkkkkkkkkkk#",
    "#wwwwwwwwwwkkkkkkkkkkkk#",
    "#wwwwwwwwwwkkkkkkkkkkkk#",
    "#wwwwwwwwwwwwwwwwwwwwww#",
    "#wwwwcccccwwwwwwwwwwwww#",
    "#wwwwcccccwwwwwwwwwwwww#",
    "#wwwwcccccwwwwwwwwwwwww#",
    "#wwwwwwwwwwwwwwwwwwwwww#",
    "#wwwwwwwwwwwwwwwwwwwwww#",
    "#wwwwwwwwwwwwwwwwwwwwww#",
    "##########ww############",
)

GADE = _rows(
    "bbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "bbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "bbbbbvbbbbbbbbbbbbvvbbbbvbbb",
    "vvvvvvvvvvvvvvvvvvvvvvvvvvvv",
    "vvvvvvvvvvvvvvvvvvvvvvvvvvvv",
    "aaaaaaaaaaaaxxaaaaaaaaaaaaaa",
    "------------xx--------------",
    "aaaaaaaaaaaaxxaaaaaaaaaaaaaa",
    "vvvvvvvvvvvvvvvvvvvvvvvvvvvv",
    "vvvvvvvvvvvvvvvvvvvvvvvvvvvv",
    "gggggggggggggggggggggggggggg",
    "gggppggggggppppggggggggggggg",
    "gggppggggggppppggggggggggggg",
    "hhhpphhhhhhppppphhhhhhhhhhhh",
)

PARK = _rows(
    "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhh",
    "hggggggggggggggggggggggggggggh",
    "hggggggggggggggggggggggggggggh",
    "hgggppppppppppppppppppppppgggh",
    "hgggpggggggggggggggggggggpgggh",
    "hgggpggg~~~~~~~~ggggffffgpgggh",
    "hgggpggg~~~~~~~~ggggffffgpgggh",
    "hgggpggg~~~~~~~~gggggggggpgggh",
    "hgggpggg~~~~~~~~gggggggggpgggh",
    "hgggpggggggggggggggggggggpgggh",
    "hgggpggggggffffffffgggggggpggh"[:30],
    "hgggpggggggffffffffgggggggpggh"[:30],
    "hgggpggggggggggggggggggggpgggh",
    "hgggppppppppppppppppppppppgggh",
    "hggggggggggggggggggggggggggggh",
    "hggggggggggggggggggggggggggggh",
    "hhhhhhhhhhhhhppphhhhhhhhhhhhhh",
    "gggggggggggggpppgggggggggggggg",
)

BIBLIOTEK = _rows(
    "######################",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "#llllllllllllllllllll#",
    "##########ll##########",
)

BUTIK = _rows(
    "########################",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "#ssssssssssssssssssssss#",
    "##########ss############",
)

# Skolebygningen ligger i toppen, porten til vejen i bunden.
SKOLEGAARD = _rows(
    "BBBBBBBBBBBlllBBBBBBBBBBBB",
    "BBBBBBBBBBBlllBBBBBBBBBBBB",
    "hggggggggggggggggggggggggh",
    "hgaaaaaaaaaaaaaaaaaaaaaagh",
    "hgaaaaaaaaaaaaaaaaaaaaaagh",
    "hgaaaaaaaaaaaaaaaaaaaaaagh",
    "hgaaaaaaaaaaaaaaaaaaaaaagh",
    "hgaaaaaaaaaaaaaaaaaaaaaagh",
    "hgaaaaaaaaaaaaaaaaaaaaaagh",
    "hgaaaaaaaaaaaaaaaaaaaaaagh",
    "hggggggggggggggggggggggggh",
    "hggggggggggggggggggggggggh",
    "hhhhhhhhhhhppphhhhhhhhhhhh",
    "gggggggggggpppgggggggggggg",
)

SKOLE = _rows(
    "BBBBBBBBBBBBBBBBBBBBBBBBBB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BllllllllllllllllllllllllB",
    "BBBBBBBBBlllBBBBBBlllBBBBB",
)

KLASSE = _rows(
    "BBBBBBBBBBBBBBBBBBBB",
    "BllllllllllllllllllB",
    "BllllllllllllllllllB",
    "BllllllllllllllllllB",
    "BllllllllllllllllllB",
    "BllllllllllllllllllB",
    "BllllllllllllllllllB",
    "BllllllllllllllllllB",
    "BllllllllllllllllllB",
    "BllllllllllllllllllB",
    "BllllllllllllllllllB",
    "BBBBBBBBBllBBBBBBBBB",
)

MAPS = {
    "hjem": {
        "name": "Hjemme",
        "ground": HJEM,
        "tint": (255, 206, 150, 30),
        "props": [
            (1, 3, "bed"), (5, 2, "desk"), (7, 3, "chair"), (8, 2, "bookshelf"),
            (8, 6, "plant"), (3, 6, "rug"),
            (12, 2, "fridge"), (14, 2, "stove"), (15, 2, "counter"),
            (16, 2, "counter"), (17, 2, "sink"), (20, 2, "counter"),
            (17, 6, "table"), (16, 6, "chair"), (19, 6, "chair"),
            (4, 12, "sofa"), (5, 9, "tv"), (10, 11, "table"),
            (20, 10, "bookshelf"), (21, 13, "plant"), (2, 14, "trashcan"),
            (10, 15, "door"), (11, 15, "door"),
        ],
    },
    "gade": {
        "name": "Vejen udenfor",
        "ground": GADE,
        "tint": (255, 236, 205, 16),
        "props": [
            (2, 4, "lamp"), (9, 4, "tree"), (15, 4, "lamp"), (23, 4, "tree"),
            (17, 2, "sign_shop"),
            (3, 9, "bench"), (7, 9, "tree"), (20, 9, "bench"), (24, 9, "tree"),
            (12, 9, "lamp"),
            (2, 12, "tree"), (6, 12, "bush"), (20, 12, "bush"), (24, 12, "tree"),
            (17, 12, "flowers"), (8, 12, "flowers"),
            (5, 2, "door"), (18, 2, "door"), (19, 2, "door"), (24, 2, "door"),
            (21, 3, "noticeboard"), (26, 4, "trashcan"),
        ],
    },
    "park": {
        "name": "Parken",
        "ground": PARK,
        "tint": (255, 246, 214, 14),
        "props": [
            (2, 2, "tree"), (8, 2, "tree"), (15, 2, "tree"), (22, 2, "tree"),
            (27, 2, "tree"), (2, 8, "tree"), (27, 8, "tree"),
            (2, 15, "tree"), (10, 15, "tree"), (20, 15, "tree"), (27, 15, "tree"),
            (6, 4, "bench"), (18, 4, "bench"), (6, 12, "bench"), (18, 12, "bench"),
            (21, 5, "flowers"), (23, 6, "flowers"), (13, 14, "flowers"),
            (12, 11, "bush"), (18, 11, "bush"),
            (24, 12, "trashcan"), (9, 14, "lamp"), (21, 14, "lamp"),
        ],
    },
    "bibliotek": {
        "name": "Biblioteket",
        "ground": BIBLIOTEK,
        "tint": (250, 240, 220, 20),
        "props": [
            (2, 2, "bookshelf"), (3, 2, "bookshelf"), (4, 2, "bookshelf"),
            (5, 2, "bookshelf"), (6, 2, "bookshelf"),
            (15, 2, "bookshelf"), (16, 2, "bookshelf"), (17, 2, "bookshelf"),
            (18, 2, "bookshelf"), (19, 2, "bookshelf"),
            (2, 7, "bookshelf"), (3, 7, "bookshelf"), (4, 7, "bookshelf"),
            (17, 7, "bookshelf"), (18, 7, "bookshelf"), (19, 7, "bookshelf"),
            (8, 9, "table"), (13, 9, "table"),
            (7, 9, "chair"), (11, 9, "chair"), (12, 9, "chair"), (16, 9, "chair"),
            (10, 4, "noticeboard"),
            (2, 11, "plant"), (19, 11, "plant"),
            (10, 13, "door"), (11, 13, "door"),
        ],
    },
    "butik": {
        "name": "Supermarkedet",
        "ground": BUTIK,
        "tint": (225, 240, 255, 18),
        "props": [
            (3, 3, "shelf"), (4, 3, "shelf"), (5, 3, "shelf"), (6, 3, "shelf"),
            (3, 6, "shelf"), (4, 6, "shelf"), (5, 6, "shelf"), (6, 6, "shelf"),
            (10, 3, "shelf"), (11, 3, "shelf"), (12, 3, "shelf"), (13, 3, "shelf"),
            (10, 6, "produce"), (11, 6, "produce"), (12, 6, "produce"),
            (17, 3, "freezer"), (19, 3, "freezer"),
            (17, 6, "shelf"), (18, 6, "shelf"), (19, 6, "shelf"),
            (3, 11, "checkout"), (7, 11, "checkout"),
            (20, 11, "trashcan"), (15, 11, "produce"),
            (10, 13, "door"), (11, 13, "door"),
        ],
    },
    "skolegaard": {
        "name": "Skolegården",
        "ground": SKOLEGAARD,
        "tint": (255, 244, 215, 14),
        "props": [
            (2, 9, "goal"), (21, 9, "goal"),
            (3, 2, "tree"), (22, 2, "tree"),
            (5, 11, "bench"), (18, 11, "bench"),
            (8, 11, "bikerack"), (15, 11, "trashcan"),
            (2, 11, "flowers"), (23, 11, "flowers"),
            (11, 0, "door"), (12, 0, "door"), (13, 0, "door"),
        ],
    },
    "skole": {
        "name": "Skolen",
        "ground": SKOLE,
        "tint": (240, 240, 250, 14),
        "props": [
            (2, 2, "locker"), (3, 2, "locker"), (4, 2, "locker"), (5, 2, "locker"),
            (18, 2, "locker"), (19, 2, "locker"), (20, 2, "locker"), (21, 2, "locker"),
            (9, 2, "noticeboard"),
            (3, 7, "tray_table"), (8, 7, "tray_table"), (13, 7, "tray_table"),
            (18, 7, "tray_table"),
            (2, 10, "plant"), (22, 10, "plant"), (14, 10, "trashcan"),
            (9, 12, "door"), (10, 12, "door"), (11, 12, "door"),
            (18, 12, "door"), (19, 12, "door"), (20, 12, "door"),
        ],
    },
    "klasse": {
        "name": "Klasselokalet",
        "ground": KLASSE,
        "tint": (255, 246, 226, 16),
        "props": [
            (7, 1, "whiteboard"), (3, 2, "teacher_desk"),
            (2, 5, "desk"), (5, 5, "desk"), (8, 5, "desk"),
            (12, 5, "desk"), (15, 5, "desk"),
            (2, 8, "desk"), (5, 8, "desk"), (8, 8, "desk"),
            (12, 8, "desk"), (15, 8, "desk"),
            (17, 2, "bookshelf"), (18, 10, "plant"), (1, 10, "trashcan"),
            (9, 11, "door"), (10, 11, "door"),
        ],
    },
}

PORTALS = {
    ("hjem", 10, 15): {"to": "gade", "tx": 5, "ty": 3, "dir": "down", "needs": 2,
                       "locked": "Du er ikke klar endnu – Mor står i køkkenet."},
    ("hjem", 11, 15): {"to": "gade", "tx": 5, "ty": 3, "dir": "down", "needs": 2,
                       "locked": "Du er ikke klar endnu – Mor står i køkkenet."},

    ("gade", 5, 2): {"to": "hjem", "tx": 10, "ty": 14, "dir": "up"},
    ("gade", 18, 2): {"to": "butik", "tx": 10, "ty": 12, "dir": "up"},
    ("gade", 19, 2): {"to": "butik", "tx": 11, "ty": 12, "dir": "up"},
    ("gade", 12, 13): {"to": "skolegaard", "tx": 12, "ty": 13, "dir": "up", "needs": 3,
                       "locked": "Far venter i supermarkedet – I skulle jo lige handle."},
    ("gade", 13, 13): {"to": "skolegaard", "tx": 12, "ty": 13, "dir": "up", "needs": 3,
                       "locked": "Far venter i supermarkedet – I skulle jo lige handle."},
    ("gade", 14, 13): {"to": "skolegaard", "tx": 13, "ty": 13, "dir": "up", "needs": 3,
                       "locked": "Far venter i supermarkedet – I skulle jo lige handle."},

    ("butik", 10, 13): {"to": "gade", "tx": 18, "ty": 3, "dir": "down"},
    ("butik", 11, 13): {"to": "gade", "tx": 19, "ty": 3, "dir": "down"},

    ("gade", 24, 2): {"to": "bibliotek", "tx": 10, "ty": 12, "dir": "up"},
    ("bibliotek", 10, 13): {"to": "gade", "tx": 24, "ty": 3, "dir": "down"},
    ("bibliotek", 11, 13): {"to": "gade", "tx": 24, "ty": 3, "dir": "down"},

    ("gade", 3, 13): {"to": "park", "tx": 14, "ty": 16, "dir": "up"},
    ("gade", 4, 13): {"to": "park", "tx": 14, "ty": 16, "dir": "up"},
    ("park", 13, 17): {"to": "gade", "tx": 3, "ty": 12, "dir": "down"},
    ("park", 14, 17): {"to": "gade", "tx": 4, "ty": 12, "dir": "down"},
    ("park", 15, 17): {"to": "gade", "tx": 4, "ty": 12, "dir": "down"},

    ("skolegaard", 11, 13): {"to": "gade", "tx": 12, "ty": 12, "dir": "down"},
    ("skolegaard", 12, 13): {"to": "gade", "tx": 13, "ty": 12, "dir": "down"},
    ("skolegaard", 13, 13): {"to": "gade", "tx": 14, "ty": 12, "dir": "down"},
    ("skolegaard", 11, 0): {"to": "skole", "tx": 9, "ty": 11, "dir": "up", "needs": 4,
                            "locked": "Oskar vinker ovre i gården – han vil vise dig noget."},
    ("skolegaard", 12, 0): {"to": "skole", "tx": 10, "ty": 11, "dir": "up", "needs": 4,
                            "locked": "Oskar vinker ovre i gården – han vil vise dig noget."},
    ("skolegaard", 13, 0): {"to": "skole", "tx": 11, "ty": 11, "dir": "up", "needs": 4,
                            "locked": "Oskar vinker ovre i gården – han vil vise dig noget."},

    ("skole", 9, 12): {"to": "skolegaard", "tx": 11, "ty": 1, "dir": "down"},
    ("skole", 10, 12): {"to": "skolegaard", "tx": 12, "ty": 1, "dir": "down"},
    ("skole", 11, 12): {"to": "skolegaard", "tx": 13, "ty": 1, "dir": "down"},
    ("skole", 18, 12): {"to": "klasse", "tx": 9, "ty": 10, "dir": "up", "needs": 5,
                        "locked": "Der er stadig frikvarter – Emma sidder i kantinen."},
    ("skole", 19, 12): {"to": "klasse", "tx": 9, "ty": 10, "dir": "up", "needs": 5,
                        "locked": "Der er stadig frikvarter – Emma sidder i kantinen."},
    ("skole", 20, 12): {"to": "klasse", "tx": 10, "ty": 10, "dir": "up", "needs": 5,
                        "locked": "Der er stadig frikvarter – Emma sidder i kantinen."},

    ("klasse", 9, 11): {"to": "skole", "tx": 19, "ty": 11, "dir": "down"},
    ("klasse", 10, 11): {"to": "skole", "tx": 19, "ty": 11, "dir": "down"},
}


def _app(skin, hair, style, shirt, pants, extra="ingen"):
    return {"skin": art.SKIN_TONES[skin], "hair": art.HAIR_COLORS[hair],
            "hair_style": style, "shirt": art.CLOTH_COLORS[shirt],
            "pants": pants, "extra": extra}


NPCS = [
    {
        "id": "mor", "map": "hjem", "x": 14, "y": 5, "dir": "down",
        "name": "Mor", "chapter": 1, "encounter": "forstaa",
        "app": _app(1, 3, "lang", 2, (92, 86, 120)),
        "before": [("Mor", "Godmorgen! Du når det nok – men kom nu ud af fjerene.")],
        "intro": [
            ("Mor", "Der er du. Kan du hjælpe mig med bollerne, mens du spiser?"),
            ("Mor", "Jeg skal bruge en, der kan regne. Og det er dig i dag."),
        ],
        "after": [("Mor", "Tak for hjælpen! Far venter – I skal lige forbi købmanden.")],
    },
    {
        "id": "ida", "map": "hjem", "x": 19, "y": 7, "dir": "up",
        "name": "Ida", "chapter": None,
        "app": _app(0, 3, "kroeller", 6, (176, 120, 150)),
        "before": [("Ida", "Jeg har fået en hel pose vingummier. Du får IKKE nogen.")],
        "after": [("Ida", "Fint. Vi deler. Men jeg tæller efter!")],
    },
    {
        "id": "far", "map": "butik", "x": 12, "y": 9, "dir": "down",
        "name": "Far", "chapter": 2, "encounter": "anvend",
        "app": _app(2, 0, "kort", 7, (78, 82, 96)),
        "before": [("Far", "Nå, er du klar? Vi skal lige handle, før du skal i skole.")],
        "intro": [
            ("Far", "Godt du er med. Jeg har glemt mine briller, så du må være regnemaskine."),
            ("Far", "Og vi har et budget i dag, så det skal passe."),
        ],
        "after": [("Far", "Flot regnet. Af sted med dig – du når lige skolen.")],
    },
    {
        "id": "oskar", "map": "skolegaard", "x": 13, "y": 7, "dir": "down",
        "name": "Oskar", "chapter": 3, "encounter": "analyser",
        "app": _app(3, 0, "kasket", 0, (86, 92, 110), "taske"),
        "before": [("Oskar", "Hey! Kommer du ud i gården?")],
        "intro": [
            ("Oskar", "Der er du! Kom, jeg har fundet noget mærkeligt ved fliserne."),
            ("Oskar", "Der er et mønster i dem. Kan du regne ud, hvad der kommer næst?"),
        ],
        "after": [("Oskar", "Du er jo blevet vildt god til det der. Vi ses i kantinen!")],
    },
    {
        "id": "emma", "map": "skole", "x": 9, "y": 6, "dir": "down",
        "name": "Emma", "chapter": 4, "encounter": "vurder",
        "app": _app(4, 2, "lang", 4, (120, 96, 150), "briller"),
        "before": [("Emma", "Hej! Jeg sidder her i frikvarteret, hvis du skal noget.")],
        "intro": [
            ("Emma", "Godt du kommer. Oskar og jeg er uenige om et regnestykke."),
            ("Emma", "Vil du være dommer? Sig bare, hvad der er rigtigt."),
        ],
        "after": [("Emma", "Held og lykke derinde. Du kan godt, altså.")],
    },
    {
        "id": "poulsen", "map": "klasse", "x": 4, "y": 4, "dir": "down",
        "name": "Hr. Poulsen", "chapter": 5, "encounter": "boss",
        "app": _app(2, 5, "kort", 5, (70, 74, 90), "briller"),
        "before": [("Hr. Poulsen", "Vi ses til timen. Husk det, vi talte om.")],
        "intro": [
            ("Hr. Poulsen", "Nå. Der er du."),
            ("Hr. Poulsen", "Prøven i går gik ikke særlig godt, og det ved du godt selv."),
            ("Hr. Poulsen", "Men jeg har hørt, at du har regnet en hel del i dag."),
            ("Hr. Poulsen", "Så vis mig det. Ikke for min skyld – for din egen."),
        ],
        "after": [("Hr. Poulsen", "Kan du mærke forskellen fra i går? Det kan jeg.")],
    },
]

# --- Sidequests ---------------------------------------------------------
# Frivillige opgaver rundt omkring. "needs" er det kapitel, man skal være
# nået til, før personen har noget at spørge om.

SIDEQUESTS = [
    {
        "id": "kioskmand", "map": "gade", "x": 25, "y": 3, "dir": "down",
        "name": "Kioskmanden", "sidequest": True, "encounter": "sq_kiosk", "needs": 2,
        "app": _app(2, 1, "kasket", 3, (84, 80, 92)),
        "before": [("Kioskmanden", "Godmorgen! Jeg har ikke åbnet endnu.")],
        "intro": [
            ("Kioskmanden", "Hey, dig der. Har du to minutter?"),
            ("Kioskmanden", "Min regnemaskine er gået i stykker, og køen vokser."),
        ],
        "after": [("Kioskmanden", "Du reddede min formiddag. Kom igen i morgen!")],
    },
    {
        "id": "bibliotekar", "map": "bibliotek", "x": 10, "y": 6, "dir": "down",
        "name": "Bibliotekaren", "sidequest": True, "encounter": "sq_bibliotek", "needs": 2,
        "app": _app(1, 5, "lang", 5, (88, 84, 110), "briller"),
        "before": [("Bibliotekaren", "Velkommen. Her må man godt tale – bare stille.")],
        "intro": [
            ("Bibliotekaren", "Godt du kommer. Jeg skal have styr på reolerne."),
            ("Bibliotekaren", "Vil du regne med? Så finder jeg en bog til dig bagefter."),
        ],
        "after": [("Bibliotekaren", "Bogen er din så længe du vil. Pas på den.")],
    },
    {
        "id": "viggo", "map": "park", "x": 14, "y": 11, "dir": "down",
        "name": "Viggo", "sidequest": True, "encounter": "sq_park_barn", "needs": 2,
        "app": _app(0, 1, "kroeller", 2, (120, 108, 150)),
        "before": [("Viggo", "Jeg venter på min storebror. Han er altid sen.")],
        "intro": [
            ("Viggo", "Hej! Er du god til at dele?"),
            ("Viggo", "Jeg skal dele med min bror, og han snyder altid."),
        ],
        "after": [("Viggo", "Nu snyder han ikke mere. Tak!")],
    },
    {
        "id": "hundelufter", "map": "park", "x": 21, "y": 8, "dir": "left",
        "name": "Hundelufteren", "sidequest": True, "encounter": "sq_hund", "needs": 3,
        "app": _app(3, 2, "kort", 4, (70, 76, 88)),
        "before": [("Hundelufteren", "Sally! Kom her, Sally!")],
        "intro": [
            ("Hundelufteren", "Undskyld – har du lige et øjeblik?"),
            ("Hundelufteren", "Jeg skal finde ud af, hvor meget jeg egentlig går om dagen."),
        ],
        "after": [("Hundelufteren", "Så mange minutter! Ikke underligt jeg er træt.")],
    },
    {
        "id": "pedel", "map": "skole", "x": 20, "y": 9, "dir": "down",
        "name": "Pedellen", "sidequest": True, "encounter": "sq_pedel", "needs": 4,
        "app": _app(2, 0, "kasket", 7, (74, 84, 74)),
        "before": [("Pedellen", "Pas på gulvet, jeg har lige vasket det.")],
        "intro": [
            ("Pedellen", "Er du god til at gange? Jeg skal stille stole op."),
            ("Pedellen", "Og jeg gider ikke tælle dem én ad gangen igen."),
        ],
        "after": [("Pedellen", "Perfekt. Her – tag den her nøgle. Den passer til noget.")],
    },
    {
        "id": "sportslaerer", "map": "skolegaard", "x": 6, "y": 6, "dir": "down",
        "name": "Sportslæreren", "sidequest": True, "encounter": "sq_sport", "needs": 3,
        "app": _app(4, 0, "kort", 2, (60, 66, 80)),
        "before": [("Sportslæreren", "Ikke bolde mod vinduerne, tak!")],
        "intro": [
            ("Sportslæreren", "Dig der! Du er god til tal, har jeg hørt."),
            ("Sportslæreren", "Jeg skal have styr på målscoren inden turneringen."),
        ],
        "after": [("Sportslæreren", "Flot. Tag den gamle bold – den ligger bare og samler støv.")],
    },
]

# --- Folk man bare kan snakke med ---------------------------------------
# Replikkerne skifter, alt efter hvor godt det går med regningen.

CHATTERS = [
    {
        "id": "nabo", "map": "gade", "x": 10, "y": 9, "dir": "down", "name": "Naboen",
        "app": _app(4, 5, "kort", 6, (96, 92, 104)),
        "lines": [("Naboen", "Godmorgen! Du er tidligt oppe i dag.")],
        "lines_good": [("Naboen", "Du ser godt tilfreds ud i dag. Er der sket noget godt?")],
        "lines_low": [("Naboen", "Sådan en dag, hva'? Dem har jeg også haft. De går over.")],
    },
    {
        "id": "ekspedient", "map": "butik", "x": 5, "y": 9, "dir": "down",
        "name": "Ekspedienten",
        "app": _app(1, 3, "lang", 0, (80, 84, 96)),
        "lines": [("Ekspedienten", "Tilbuddene hænger ved kassen, hvis I skal spare.")],
        "lines_good": [("Ekspedienten", "Var det dig, der regnede det hele for din far? Flot.")],
    },
    {
        "id": "bogorm", "map": "bibliotek", "x": 8, "y": 10, "dir": "up",
        "name": "Dreng med bog",
        "app": _app(0, 0, "kort", 4, (72, 78, 96), "briller"),
        "lines": [("Dreng med bog", "Shh. Jeg er på side 200.")],
        "lines_good": [("Dreng med bog", "Er du også god til tal? Så er vi to.")],
    },
    {
        "id": "pigen", "map": "skolegaard", "x": 18, "y": 5, "dir": "left",
        "name": "Sofie",
        "app": _app(2, 3, "lang", 6, (150, 100, 130)),
        "lines": [("Sofie", "Har du set Oskar? Han skylder mig en is.")],
        "lines_good": [("Sofie", "Alle snakker om, at du er blevet god til matematik.")],
        "lines_low": [("Sofie", "Matematik er også svært. Det siger min mor i hvert fald.")],
    },
]

NPCS = NPCS + SIDEQUESTS + CHATTERS

SIGNS = {
    ("hjem", 5, 2): {
        "name": "Skrivebordet", "chapter": 0, "encounter": "husk",
        "before": [("Dig selv", "Skoletasken ligger klar.")],
        "intro": [
            ("Dig selv", "Puha. Matematiktimen i går var en katastrofe."),
            ("Dig selv", "Hr. Poulsen sagde, jeg skulle vise ham noget i dag."),
            ("Dig selv", "Okay. Først skal jeg bare nå bussen. Lad mig lige tænke ..."),
        ],
        "after": [("Dig selv", "Tasken er pakket. Nu skal jeg have morgenmad.")],
    },
    ("hjem", 1, 3): {"text": ("Din seng", "Redt. Næsten. Mor ville kalde det \"et forsøg\".")},
    ("hjem", 5, 9): {"text": ("Fjernsynet", "Slukket. Der er skole i dag, desværre.")},
    ("hjem", 12, 2): {"text": ("Køleskabet", "Rugbrød, leverpostej og en tegning fra Ida på døren.")},
    ("hjem", 8, 2): {"text": ("Reolen", "Mest Idas bøger. Og en gammel matematikbog fra sidste år.")},
    ("gade", 17, 2): {"text": ("Skiltet", "KØBMANDEN – åbent 8-21.\nTilbudsaviserne hænger i vinduet.")},
    ("gade", 3, 9): {"text": ("Bænken", "Her sad du og Oskar og spiste is hele sommeren.")},
    ("butik", 10, 6): {"text": ("Frugtafdelingen", "Æbler, bananer og noget, der ligner meget dyre blåbær.")},
    ("butik", 3, 11): {"text": ("Kassen", "Køen er lang. Far beder dig helt sikkert regne noget ud imens.")},
    ("skolegaard", 2, 9): {"text": ("Målet", "Nettet har et hul. Det har det haft i to år.")},
    ("skolegaard", 8, 11): {"text": ("Cykelstativet", "Din cykel står derhjemme. Du sov over dig.")},
    ("skole", 9, 2): {"text": ("Opslagstavlen", "\"Forældremøde torsdag.\"\n\"Husk gymnastiktøj.\"\n\"Matematikprøve – fredag.\"")},
    ("klasse", 7, 1): {"text": ("Tavlen", "Der står stadig gårsdagens opgaver.\nDe ser pludselig ikke så slemme ud.")},
    ("klasse", 17, 2): {"text": ("Bogreolen", "Matematikbøger. Række efter række af dem.")},
    ("park", 6, 4): {"text": ("Bænken ved søen", "Her sidder de gamle og fodrer ænderne\nhver eneste formiddag.")},
    ("park", 9, 14): {"text": ("Lygtepælen", "Nogen har ridset et regnestykke ind i den.\nDet passer endda.")},
    ("bibliotek", 10, 4): {"text": ("Opslagstavlen", "\"Læsemaraton starter mandag.\"\n\"Lektiecafé hver torsdag – alle er velkomne.\"")},
    ("gade", 21, 3): {"text": ("Opslagstavlen", "En plakat for skolens sommerfest.\nNogen har tegnet en fodbold på den.")},
}


class GameMap:
    def __init__(self, key):
        self.key = key
        data = MAPS[key]
        self.name = data["name"]
        self.ground = data["ground"]
        self.tint = data.get("tint")
        self.h = len(self.ground)
        self.w = len(self.ground[0])
        self.props = list(data.get("props", []))
        self.solid = [[False] * self.w for _ in range(self.h)]
        self._build_collision()
        self.ground_surf = self._render_ground()
        self.flat_props, self.tall_props = self._split_props()

    def _build_collision(self):
        for y, row in enumerate(self.ground):
            for x, ch in enumerate(row):
                if ch in SOLID_GROUND:
                    self.solid[y][x] = True
        for (px, py, kind) in self.props:
            w, h, solid = PROP_INFO.get(kind, (1, 1, True))
            if not solid:
                continue
            for dy in range(h):
                for dx in range(w):
                    tx, ty = px + dx, py - dy
                    if 0 <= tx < self.w and 0 <= ty < self.h:
                        self.solid[ty][tx] = True
        for (mk, x, y) in PORTALS:
            if mk == self.key and 0 <= x < self.w and 0 <= y < self.h:
                self.solid[y][x] = False

    def _render_ground(self):
        surf = pygame.Surface((self.w * TILE, self.h * TILE)).convert()
        for y, row in enumerate(self.ground):
            for x, ch in enumerate(row):
                surf.blit(art.tile(GROUND.get(ch, "void")), (x * TILE, y * TILE))
        fringe = art.grass_fringe()
        for y in range(1, self.h):
            for x in range(self.w):
                if self.ground[y][x] in ("p", "v", "a") and self.ground[y - 1][x] == "g":
                    surf.blit(fringe, (x * TILE, y * TILE))
        return surf

    def _split_props(self):
        flat, tall = [], []
        for (x, y, kind) in self.props:
            (tall if kind in art.TALL_PROPS else flat).append((x, y, kind))
        return flat, tall

    def is_solid_px(self, rect):
        if rect.left < 0 or rect.top < 0:
            return True
        if rect.right > self.w * TILE or rect.bottom > self.h * TILE:
            return True
        x0, x1 = rect.left // TILE, (rect.right - 1) // TILE
        y0, y1 = rect.top // TILE, (rect.bottom - 1) // TILE
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if self.solid[ty][tx]:
                    return True
        return False

    def draw_flat(self, surface, cam):
        surface.blit(self.ground_surf, (-cam[0], -cam[1]))
        for (x, y, kind) in self.flat_props:
            img = art.prop(kind)
            w, _, _ = PROP_INFO.get(kind, (1, 1, True))
            px = x * TILE + (w * TILE - img.get_width()) // 2
            py = (y + 1) * TILE - img.get_height()
            surface.blit(img, (px - cam[0], py - cam[1]))

    def tall_prop_draws(self):
        out = []
        for (x, y, kind) in self.tall_props:
            img = art.prop(kind)
            w, _, _ = PROP_INFO.get(kind, (1, 1, True))
            px = x * TILE + (w * TILE - img.get_width()) // 2
            py = (y + 1) * TILE - img.get_height()
            out.append(((y + 1) * TILE, img, px, py))
        return out


def npcs_for(map_key):
    return [n for n in NPCS if n["map"] == map_key]
