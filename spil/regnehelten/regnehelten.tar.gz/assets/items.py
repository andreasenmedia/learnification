"""
Ting i tasken.

Man får en ting, hver gang man rammer mindst 85 % rigtige i første forsøg
i et opgavesæt. To af tingene låser et pausespil op – fodbold og klæd om –
og giver samtidig et par spilleture. Man kan kun spille pausespillene, så
længe man har ture tilbage, så de bliver en belønning og ikke hele spillet.
"""

import pygame

import ui

PLAYS_PER_ITEM = 2      # spilleture man får med hver ting
MAX_PLAYS = 6           # man kan aldrig have flere ture end det i banken


def _s(size=40):
    return pygame.Surface((size, size), pygame.SRCALPHA)


def _i_fodbold():
    s = _s()
    pygame.draw.circle(s, (250, 250, 248), (20, 21), 15)
    pygame.draw.circle(s, (60, 60, 66), (20, 21), 15, 2)
    pts = [(20, 13), (27, 18), (24, 27), (16, 27), (13, 18)]
    pygame.draw.polygon(s, (52, 52, 58), pts)
    for a, b in ((0, 1), (1, 2), (2, 3), (3, 4), (4, 0)):
        pygame.draw.line(s, (52, 52, 58), pts[a], (pts[a][0], pts[a][1] - 6), 2)
    return s


def _i_toejpose():
    s = _s()
    pygame.draw.rect(s, (214, 120, 150), (8, 14, 24, 20), border_radius=4)
    pygame.draw.rect(s, (168, 82, 112), (8, 14, 24, 20), 2, border_radius=4)
    pygame.draw.arc(s, (168, 82, 112), (13, 6, 14, 16), 0.2, 2.9, 3)
    pygame.draw.line(s, (240, 190, 210), (12, 20), (28, 20), 2)
    return s


def _i_guldmoent():
    s = _s()
    pygame.draw.circle(s, (188, 148, 56), (20, 21), 14)
    pygame.draw.circle(s, (238, 200, 96), (20, 20), 13)
    pygame.draw.circle(s, (188, 148, 56), (20, 20), 13, 2)
    ui.text(s, "12", (20, 20), size=15, color=(150, 112, 34), bold=True, center=True)
    return s


def _i_is():
    s = _s()
    pygame.draw.polygon(s, (214, 176, 118), [(14, 20), (26, 20), (20, 36)])
    pygame.draw.circle(s, (248, 186, 196), (17, 16), 7)
    pygame.draw.circle(s, (236, 232, 210), (24, 15), 7)
    pygame.draw.circle(s, (188, 112, 96), (21, 10), 6)
    return s


def _i_kridt():
    s = _s()
    pygame.draw.rect(s, (246, 244, 238), (14, 8, 10, 26), border_radius=3)
    pygame.draw.rect(s, (206, 202, 192), (14, 8, 10, 26), 2, border_radius=3)
    pygame.draw.rect(s, (226, 222, 212), (14, 28, 10, 6))
    return s


def _i_pokal():
    s = _s()
    pygame.draw.polygon(s, (236, 198, 92), [(11, 8), (29, 8), (26, 22), (14, 22)])
    pygame.draw.rect(s, (208, 166, 62), (17, 22, 6, 6))
    pygame.draw.rect(s, (208, 166, 62), (12, 28, 16, 5), border_radius=2)
    pygame.draw.arc(s, (208, 166, 62), (4, 8, 10, 12), 1.6, 4.7, 3)
    pygame.draw.arc(s, (208, 166, 62), (26, 8, 10, 12), 4.7, 1.6, 3)
    return s


def _i_bog():
    s = _s()
    pygame.draw.rect(s, (108, 76, 148), (9, 9, 22, 24), border_radius=2)
    pygame.draw.rect(s, (78, 52, 112), (9, 9, 22, 24), 2, border_radius=2)
    pygame.draw.rect(s, (238, 234, 222), (20, 11, 9, 20))
    pygame.draw.line(s, (168, 150, 196), (13, 14), (17, 14), 2)
    pygame.draw.line(s, (168, 150, 196), (13, 19), (17, 19), 2)
    return s


def _i_slik():
    s = _s()
    pygame.draw.circle(s, (228, 92, 108), (20, 20), 9)
    pygame.draw.circle(s, (250, 160, 172), (17, 17), 4)
    pygame.draw.polygon(s, (240, 148, 162), [(11, 20), (4, 15), (4, 25)])
    pygame.draw.polygon(s, (240, 148, 162), [(29, 20), (36, 15), (36, 25)])
    return s


def _i_hundeben():
    s = _s()
    c = (232, 226, 206)
    pygame.draw.rect(s, c, (12, 18, 16, 6), border_radius=3)
    for cx, cy in ((12, 16), (12, 25), (28, 16), (28, 25)):
        pygame.draw.circle(s, c, (cx, cy), 5)
    pygame.draw.rect(s, (196, 188, 166), (12, 18, 16, 6), 1, border_radius=3)
    return s


def _i_noegle():
    s = _s()
    pygame.draw.circle(s, (206, 176, 96), (14, 16), 7)
    pygame.draw.circle(s, (150, 124, 62), (14, 16), 7, 2)
    pygame.draw.circle(s, (250, 248, 244), (14, 16), 3)
    pygame.draw.rect(s, (206, 176, 96), (18, 20, 14, 5))
    pygame.draw.rect(s, (206, 176, 96), (27, 24, 4, 6))
    return s


ITEMS = {
    "fodbold": {
        "name": "Fodbolden", "icon": _i_fodbold, "unlocks": "fodbold",
        "desc": "Oskars gamle fodbold. Nu kan du tage et par straffespark\n"
                "i skolegården, når du trænger til en pause.",
    },
    "toejpose": {
        "name": "Tøjposen", "icon": _i_toejpose, "unlocks": "dressup",
        "desc": "En pose med dit eget tøj. Nu kan du klæde om og skifte\n"
                "udseende, når du har lyst.",
    },
    "guldmoent": {
        "name": "Den blanke mønt", "icon": _i_guldmoent,
        "desc": "Den lå bagerst i sparegrisen. Bedstefar siger, den er\n"
                "fra dengang, han selv gik i skole.",
    },
    "is": {
        "name": "Isen fra Far", "icon": _i_is,
        "desc": "\"Fordi du regnede det hele rigtigt,\" sagde han.\n"
                "Den smelter ikke – det er den slags is.",
    },
    "kridt": {
        "name": "Et stykke kridt", "icon": _i_kridt,
        "desc": "Fra kantinens gulv. Man kan tegne hinkeruder med det –\n"
                "eller regnestykker.",
    },
    "pokal": {
        "name": "Pokalen", "icon": _i_pokal,
        "desc": "Den stod øverst i skabet i klassen. I dag er den din.",
    },
    "bog": {
        "name": "Lånt bog", "icon": _i_bog,
        "desc": "\"Tal og mønstre for nysgerrige\". Bibliotekaren fandt den\n"
                "frem til dig helt af sig selv.",
    },
    "slik": {
        "name": "Bland selv-pose", "icon": _i_slik,
        "desc": "Fra kiosken. Kioskmanden gav en ekstra, fordi du regnede\n"
                "byttepengene hurtigere end ham.",
    },
    "hundeben": {
        "name": "Hundekiks", "icon": _i_hundeben,
        "desc": "Til Sally, hunden i parken. Hun kan lide dig nu.",
    },
    "noegle": {
        "name": "Pedellens nøgle", "icon": _i_noegle,
        "desc": "\"Pas godt på den,\" sagde han. Du er ikke helt sikker på,\n"
                "hvad den låser op.",
    },
}

# Beskrivelserne er skrevet over flere linjer for læsbarhedens skyld i koden;
# på skærmen skal de ombrydes efter panelets bredde i stedet.
for _it in ITEMS.values():
    _it["desc"] = " ".join(_it["desc"].split())

_icon_cache = {}


def icon(item_id):
    if item_id not in _icon_cache:
        maker = ITEMS[item_id]["icon"]
        _icon_cache[item_id] = maker()
    return _icon_cache[item_id]


class Inventory:
    def __init__(self):
        self.owned = []                       # rækkefølgen man fik dem i
        self.counts = {}
        self.plays = {"fodbold": 0, "dressup": 0}
        self.cursor = 0

    def add(self, item_id):
        """Lægger en ting i tasken. Returnerer (ny?, oplåst spil eller None)."""
        first = item_id not in self.counts
        if first:
            self.owned.append(item_id)
        self.counts[item_id] = self.counts.get(item_id, 0) + 1
        unlocks = ITEMS[item_id].get("unlocks")
        if unlocks:
            self.plays[unlocks] = min(MAX_PLAYS, self.plays[unlocks] + PLAYS_PER_ITEM)
        return first, unlocks

    def has_game(self, game):
        return self.plays.get(game, 0) > 0

    def unlocked(self, game):
        """Om spillet nogensinde er blevet låst op (også selv om turene er brugt)."""
        for item_id in self.counts:
            if ITEMS[item_id].get("unlocks") == game:
                return True
        return False

    def spend(self, game):
        if self.plays.get(game, 0) > 0:
            self.plays[game] -= 1
            return True
        return False
