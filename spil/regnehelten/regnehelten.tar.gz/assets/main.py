"""
Regnehelten
Et matematik-rollespil på dansk for 7-12-årige.

Kør med:  python main.py
"""

import asyncio
import math
import os
import random
import sys

import pygame

# python-for-android sætter denne, når spillet kører som app på en telefon
ANDROID = "ANDROID_ARGUMENT" in os.environ
# pygbag kører spillet i browseren som WebAssembly
WEB = sys.platform == "emscripten"

import art
import breakgames
import content
import items as items_mod
import journal as journal_mod
import minigames
import minimap
import music as music_mod
import touch as touch_mod
import ui
import world
from art import TILE, CHAR_W, CHAR_H
from audio import Audio

WINDOW_W, WINDOW_H = 1024, 640
WORLD_SCALE = 2
VIEW_W, VIEW_H = WINDOW_W // WORLD_SCALE, WINDOW_H // WORLD_SCALE
FPS = 60

WALK_SPEED = 96.0
ANIM_FPS = 7.0

OBJECTIVES = [
    "Gør dig klar til skole – kig på dit skrivebord",
    "Spis morgenmad – snak med Mor i køkkenet",
    "Tag med Far i supermarkedet",
    "Mød Oskar i skolegården",
    "Find Emma inde i kantinen",
    "Vis Hr. Poulsen, hvad du kan",
    "Du klarede det!",
]

PRAISE = ["Præcis!", "Lige i øjet.", "Korrekt.", "Sådan!", "Helt rigtigt.",
          "Flot regnet.", "Det sidder lige i skabet."]


class Player:
    def __init__(self, appearance):
        self.app = appearance
        self.x = 0.0
        self.y = 0.0
        self.dir = "down"
        self.frame = 0.0
        self.moving = False

    @property
    def feet(self):
        return pygame.Rect(int(self.x) + 6, int(self.y) + CHAR_H - 12, CHAR_W - 12, 10)

    def place_tile(self, tx, ty):
        self.x = tx * TILE + (TILE - CHAR_W) / 2
        self.y = ty * TILE + TILE - CHAR_H

    def tile(self):
        f = self.feet
        return f.centerx // TILE, f.centery // TILE

    def update(self, dt, dx, dy, gmap):
        self.moving = bool(dx or dy)
        if self.moving:
            if dx and dy:
                dx *= 0.7071
                dy *= 0.7071
            if dx < 0:
                self.dir = "left"
            elif dx > 0:
                self.dir = "right"
            elif dy < 0:
                self.dir = "up"
            elif dy > 0:
                self.dir = "down"

            nx = self.x + dx * WALK_SPEED * dt
            probe = pygame.Rect(self.feet)
            probe.x = int(nx) + 6
            if not gmap.is_solid_px(probe):
                self.x = nx
            ny = self.y + dy * WALK_SPEED * dt
            probe = pygame.Rect(self.feet)
            probe.y = int(ny) + CHAR_H - 12
            if not gmap.is_solid_px(probe):
                self.y = ny
            self.frame += ANIM_FPS * dt
        else:
            self.frame = 0.0

    def sprite(self):
        return art.character_sprite(self.app, self.dir, int(self.frame) % 4)

    def facing_tile(self):
        tx, ty = self.tile()
        return {"up": (tx, ty - 1), "down": (tx, ty + 1),
                "left": (tx - 1, ty), "right": (tx + 1, ty)}[self.dir]


class Dialogue:
    def __init__(self, audio):
        self.audio = audio
        self.lines = []
        self.index = 0
        self.tw = ui.Typewriter()
        self.active = False
        self.on_done = None

    def start(self, lines, on_done=None):
        self.lines = list(lines)
        self.index = 0
        self.active = bool(self.lines)
        self.on_done = on_done
        if self.active:
            self.tw.set(self.lines[0][1])
        elif on_done:
            # intet at sige – kør videre med det samme i stedet for at tabe kaldet
            self.on_done = None
            on_done()

    def advance(self):
        if not self.active:
            return
        if not self.tw.done:
            self.tw.finish()
            return
        self.index += 1
        if self.index >= len(self.lines):
            self.active = False
            cb, self.on_done = self.on_done, None
            if cb:
                cb()
        else:
            self.tw.set(self.lines[self.index][1])

    def update(self, dt):
        if self.active:
            self.tw.update(dt)

    def draw(self, surface):
        if not self.active:
            return
        speaker, _ = self.lines[self.index]
        box = pygame.Rect(40, WINDOW_H - 190, WINDOW_W - 80, 150)
        ui.panel(surface, box)
        ui.name_tag(surface, speaker, (box.x + 18, box.y - 16))
        ui.text_block(surface, self.tw.visible(), (box.x + 26, box.y + 34),
                      size=22, max_width=box.w - 60, line_gap=8)
        if self.tw.done:
            ui.arrow(surface, (box.right - 118, box.bottom - 26), "down", ui.MUTED, 7)
            ui.text(surface, "ENTER", (box.right - 104, box.bottom - 36),
                    size=16, color=ui.MUTED, bold=True)


class Battle:
    """Kampskærmen: ét minispil ad gangen, med Regnebogen ved hånden."""

    MAX_TRIES = {"build": 4, "findall": 3, "coins": 3}

    def __init__(self, game, key, npc_name, npc_app=None):
        self.game = game
        self.key = key
        self.bloom = content.ENCOUNTERS[key]["bloom"]
        self.specs = content.ENCOUNTERS[key]["gen"](game.tier)
        self.npc_name = npc_name
        self.npc_app = npc_app
        self.index = 0
        self.attempts = 0
        self.first_try = 0
        self.phase = "play"
        self.feedback = ""
        self.feedback_good = False
        self.revealed = ""
        self.shake = 0.0
        self.flash = 0.0
        self.done = False
        self.mg = minigames.make(self.specs[0])

    @property
    def spec(self):
        return self.specs[self.index]

    def _max_tries(self):
        return self.MAX_TRIES.get(self.spec["kind"], 2)

    def handle_event(self, e):
        if self.phase == "feedback":
            if e.type == pygame.KEYDOWN and e.key in (
                    pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE, pygame.K_e):
                self._next()
            return
        self.mg.handle_event(e, self.game.audio)
        if self.mg.result is not None:
            ok, msg = self.mg.result
            self.mg.result = None
            self._judge(ok, msg)

    def _judge(self, ok, msg):
        if ok:
            if self.attempts == 0:
                self.first_try += 1
                self.game.confidence = min(100, self.game.confidence + 6)
            else:
                self.game.confidence = min(100, self.game.confidence + 3)
            self.game.audio.correct()
            self.feedback = random.choice(PRAISE)
            self.feedback_good = True
            self.flash = 0.45
            self.phase = "feedback"
            self.revealed = ""
        else:
            self.attempts += 1
            self.game.audio.wrong()
            self.feedback_good = False
            self.shake = 0.35
            if self.attempts >= self._max_tries():
                self.revealed = self.mg.answer_text()
                self.feedback = self.spec["hint"]
                self.phase = "feedback"
            else:
                base = msg or "Ikke helt."
                self.feedback = f"{base} {self.spec['hint']}"
                self.mg.reset()

    def _next(self):
        self.index += 1
        self.attempts = 0
        self.feedback = ""
        self.revealed = ""
        self.phase = "play"
        if self.index >= len(self.specs):
            self.done = True
        else:
            self.mg = minigames.make(self.spec)

    def update(self, dt):
        self.mg.update(dt)
        self.shake = max(0.0, self.shake - dt)
        self.flash = max(0.0, self.flash - dt)

    def book_page(self):
        return self.spec.get("book")

    # --- tegning ------------------------------------------------------

    def draw(self, surface):
        veil = pygame.Surface((WINDOW_W, WINDOW_H), pygame.SRCALPHA)
        veil.fill((18, 20, 34, 208))
        surface.blit(veil, (0, 0))

        if self.flash > 0:
            glow = pygame.Surface((WINDOW_W, WINDOW_H), pygame.SRCALPHA)
            glow.fill((120, 220, 150, int(60 * self.flash / 0.45)))
            surface.blit(glow, (0, 0))

        dx = int(math.sin(self.shake * 60) * 7) if self.shake > 0 else 0

        # modstander
        if self.npc_app:
            sprite = art.character_sprite(self.npc_app, "down",
                                          int(self.mg.t * 4) % 4 if self.phase == "play" else 0)
            big = pygame.transform.scale(sprite, (CHAR_W * 3, CHAR_H * 3))
            pygame.draw.ellipse(surface, (12, 14, 24), (854, 152, 116, 22))
            surface.blit(big, (860, 34))

        # spørgsmål
        qbox = pygame.Rect(24 + dx, 26, 800, 132)
        ui.panel(surface, qbox)
        ui.name_tag(surface, self.spec.get("speaker", self.npc_name), (qbox.x + 18, qbox.y - 16))
        ui.text_block(surface, self.spec["q"], (qbox.x + 26, qbox.y + 30),
                      size=21, max_width=qbox.w - 56, line_gap=5)

        # runde-info
        tagw = ui.font(15, True).size(self.bloom)[0]
        ui.text(surface, self.bloom, (WINDOW_W - 40 - tagw, 172), size=15,
                color=(214, 208, 198), bold=True)
        for i in range(len(self.specs)):
            cx = 44 + i * 26
            col = ui.GOOD if i < self.index else ((250, 244, 232) if i == self.index
                                                  else (92, 96, 116))
            pygame.draw.circle(surface, col, (cx, 176), 7)
            pygame.draw.circle(surface, (40, 44, 64), (cx, 176), 7, 2)

        # minispil-scene
        stage = pygame.Rect(24 + dx, 196, WINDOW_W - 48, 322)
        ui.panel(surface, stage, bg=(252, 250, 244))
        ui.text(surface, self.mg.label, (stage.x + 22, stage.y + 12), size=17,
                color=ui.MUTED, bold=True)
        inner = pygame.Rect(stage.x + 16, stage.y + 40, stage.w - 32, stage.h - 96)
        self.mg.draw(surface, inner)

        if self.feedback:
            fb = pygame.Rect(stage.x + 16, stage.bottom - 54, stage.w - 32, 40)
            col = ui.GOOD if self.feedback_good else ui.BAD
            bg = (228, 244, 232) if self.feedback_good else (252, 232, 228)
            pygame.draw.rect(surface, bg, fb, border_radius=10)
            pygame.draw.rect(surface, col, fb, 2, border_radius=10)
            msg = self.feedback
            if self.revealed:
                msg = f"Svaret er {self.revealed}.  {self.feedback}"
            lines = ui.wrap(msg, 17, fb.w - 150)
            ui.text(surface, lines[0], (fb.x + 16, fb.y + 10), size=17, color=col, bold=True)
            if self.phase == "feedback":
                ui.text(surface, "ENTER: videre", (fb.right - 118, fb.y + 11),
                        size=16, color=col, bold=True)

        # bundlinje – på touch gøres den smallere, så styrekrydset og
        # OK-knappen har plads i hjørnerne
        if ui.TOUCH:
            bar = pygame.Rect(252, 548, 556, 74)
        else:
            bar = pygame.Rect(24, 532, WINDOW_W - 48, 86)
        ui.panel(surface, bar, radius=12)
        psprite = art.character_sprite(self.game.player.app, "down", 0)
        surface.blit(pygame.transform.scale(psprite, (CHAR_W * 2, CHAR_H * 2)),
                     (bar.x + 16, bar.y - 24))
        ui.text(surface, self.game.name or "Dig", (bar.x + 84, bar.y + 12), size=19, bold=True)
        ui.text(surface, "Regnekraft", (bar.x + 84, bar.y + 38), size=14, color=ui.MUTED)
        ui.bar(surface, (bar.x + 176, bar.y + 34, 200, 20),
               self.game.confidence / 100.0, label=f"{self.game.confidence}%")

        if not ui.TOUCH:
            items = self.mg.key_items if self.phase == "play" else [("ENTER", "videre")]
            ui.keyrow(surface, (bar.right - 20, bar.y + 10), items, size=14,
                      right_align=True, gap=12)
            ui.keyrow(surface, (bar.right - 20, bar.y + 46),
                      [("J", "slå op i Regnebogen")], size=14, right_align=True)


class Game:
    def __init__(self):
        pygame.init()
        # På Android ville et åbent tekstfelt hive tastaturet op over spillet.
        # Der bruges taltastaturet i stedet – undtagen når navnet skal skrives.
        self._text_input_on = not ANDROID
        if self._text_input_on:
            pygame.key.start_text_input()
        else:
            pygame.key.stop_text_input()
        # Spillet tegnes altid i 1024x640 og skaleres til vinduet/skærmen,
        # så det passer på både en pc og en telefon.
        if ANDROID or "--fullscreen" in sys.argv:
            self.display = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        elif WEB:
            # I browseren er lærredet fast – ingen VIDEORESIZE at reagere på.
            self.display = pygame.display.set_mode((WINDOW_W, WINDOW_H))
        else:
            self.display = pygame.display.set_mode((WINDOW_W, WINDOW_H), pygame.RESIZABLE)
        pygame.display.set_caption("Regnehelten")
        self.screen = pygame.Surface((WINDOW_W, WINDOW_H)).convert()
        self._view = (0, 0, 1.0)
        # Knapperne på skærmen hører til en telefon eller tablet. I browseren
        # spørger vi siden, om skærmen bliver rørt ved; på en pc er svaret nej,
        # og så dukker de aldrig op – musen klikker direkte i spillet.
        self.touch = touch_mod.TouchControls(
            device=ANDROID or (WEB and touch_mod.browser_is_touch()))
        if WEB:
            touch_mod.report("Regnehelten: touch-skaerm = %s (%s)"
                             % (self.touch.device, touch_mod.HOW))
        if ANDROID:
            self.touch.activate()      # på telefon er der kun fingre
        self.world_surf = pygame.Surface((VIEW_W, VIEW_H)).convert()
        self.clock = pygame.time.Clock()
        self.audio = Audio()
        self.music = music_mod.Music(self.audio)
        self.running = True

        self.state = "title"
        self.t = 0.0

        self.name = ""
        self.age = 10
        self.tier = "mellem"
        self.chapter = 0
        self.confidence = 10
        self.total_first_try = 0
        self.total_questions = 0
        self.mastery = {}

        self.gender = "pige"
        self.appearance = {
            "skin": art.SKIN_TONES[1], "hair": art.HAIR_COLORS[3],
            "hair_style": "lang", "shirt": art.CLOTH_COLORS[6],
            "pants": (78, 86, 112), "extra": "taske",
        }

        self.player = Player(self.appearance)
        self.maps = {}
        self.map = None
        self.cam = [0.0, 0.0]
        self.dialogue = Dialogue(self.audio)
        self.book = journal_mod.Journal()
        self.battle = None
        self.bag = items_mod.Inventory()
        self.done_quests = set()
        self.breakgame = None
        self.cutscene_actors = []
        self._after_lines = []
        self._quest_id = None
        self.toast = ""
        self.toast_t = 0.0
        self.pause_index = 0
        self.creator_row = 0

    # --- kort ---------------------------------------------------------

    def get_map(self, key):
        if key not in self.maps:
            self.maps[key] = world.GameMap(key)
        return self.maps[key]

    def goto(self, key, tx, ty, direction="down"):
        self.map = self.get_map(key)
        self.music.for_map(key)
        self.player.place_tile(tx, ty)
        self.player.dir = direction
        cx = self.player.x + CHAR_W / 2 - VIEW_W / 2
        cy = self.player.y + CHAR_H / 2 - VIEW_H / 2
        self.cam = [self._clampx(cx), self._clampy(cy)]

    def _clampx(self, v):
        return max(0, min(self.map.w * TILE - VIEW_W, v))

    def _clampy(self, v):
        return max(0, min(self.map.h * TILE - VIEW_H, v))

    def show_toast(self, msg):
        self.toast = msg
        self.toast_t = 3.4

    # --- historie -----------------------------------------------------

    def start_game(self):
        self.tier = content.tier_for_age(self.age)
        self.player = Player(self.appearance)
        self.start_cutscene()

    # --- åbningsscene i klasselokalet ---------------------------------

    def start_cutscene(self):
        """I går, sidste time: det gik galt – og så blev det besluttet."""
        self.map = self.get_map("klasse")
        self.music.play("cutscene")
        self.player.place_tile(10, 9)
        self.player.dir = "up"
        self.cam = [0.0, 0.0]

        seats = [(2, 5), (5, 5), (12, 5), (15, 5), (2, 8), (5, 8), (12, 8), (15, 8)]
        rng = random.Random(7)
        self.cutscene_actors = []
        for i, (tx, ty) in enumerate(seats):
            app = {
                "skin": art.SKIN_TONES[rng.randrange(len(art.SKIN_TONES))],
                "hair": art.HAIR_COLORS[rng.randrange(len(art.HAIR_COLORS))],
                "hair_style": ["kort", "lang", "kroeller", "kasket"][rng.randrange(4)],
                "shirt": art.CLOTH_COLORS[rng.randrange(len(art.CLOTH_COLORS))],
                "pants": (78, 86, 112), "extra": "ingen",
            }
            self.cutscene_actors.append((tx, ty, app))

        n = self.name
        self.state = "cutscene"
        self.dialogue.start([
            ("Fortæller", "I går. Sidste time."),
            ("Hr. Poulsen", "Og hvem kan så svare på den her?"),
            ("Sofie", "48!"),
            ("Hr. Poulsen", "Rigtigt. Og den næste?"),
            ("Oskar", "72! Den var nem."),
            ("Dig selv", "... jeg kan ikke engang se, hvor de starter."),
            ("Hr. Poulsen", f"{n}? Hvad siger du?"),
            ("Dig selv", "... det ved jeg ikke."),
            ("Fortæller", "Nogen grinede. Ikke alle. Men nogen."),
            ("Dig selv", "Jeg hader det her."),
            ("Fortæller", "Bagefter, da klassen var tom:"),
            ("Hr. Poulsen", "Kom forbi i morgen og vis mig, hvad du kan."),
            ("Hr. Poulsen", "Jeg tror på dig. Det er ikke bare noget, jeg siger."),
            ("Dig selv", "Jeg vil ikke have det sådan her mere."),
            ("Dig selv", "Jeg vil kunne det. Også mig."),
        ], on_done=self._after_cutscene)

    def _after_cutscene(self):
        self.goto("hjem", 4, 6, "down")
        self.state = "story"
        self.dialogue.start([
            ("Fortæller", "Det er i morgen nu. Og klokken er alt for mange."),
            ("Mor", f"{self.name}! Bussen kører om lidt!"),
        ], on_done=self._begin_play)

    def _begin_play(self):
        self.state = "play"
        self.show_toast(OBJECTIVES[0])

    # --- hvordan går det? ---------------------------------------------

    def performance(self):
        if self.total_questions < 3:
            return "mid"
        ratio = self.total_first_try / self.total_questions
        return "good" if ratio >= 0.75 else ("low" if ratio < 0.5 else "mid")

    def lines_for(self, npc, base):
        """Vælger replikker efter hvordan det går med regningen."""
        p = self.performance()
        if p == "good" and npc.get(base + "_good"):
            return npc[base + "_good"]
        if p == "low" and npc.get(base + "_low"):
            return npc[base + "_low"]
        return npc.get(base, [])

    def trigger_battle(self, key, npc_name, after_lines, npc_app=None, quest_id=None):
        self.battle = Battle(self, key, npc_name, npc_app)
        self._after_lines = after_lines
        self._quest_id = quest_id
        self.state = "battle"

    def finish_battle(self):
        b = self.battle
        self.total_first_try += b.first_try
        self.total_questions += len(b.specs)
        ratio = b.first_try / max(1, len(b.specs))
        self.battle = None
        self.state = "play"
        self.audio.levelup()
        lines = list(self._after_lines)

        if self._quest_id:
            self.done_quests.add(self._quest_id)
        else:
            self.mastery[b.bloom] = 3 if ratio >= 0.8 else (2 if ratio >= 0.45 else 1)
            self.chapter += 1
            self.show_toast(OBJECTIVES[min(self.chapter, len(OBJECTIVES) - 1)])

        lines += self._award_for(b.key, ratio)
        self._quest_id = None

        if b.key == "boss":
            self.dialogue.start(lines, on_done=self._to_ending)
        else:
            self.dialogue.start(lines)

    def _award_for(self, enc_key, ratio):
        """Mindst 85 % rigtige i første forsøg giver en ting i tasken."""
        pct = int(round(ratio * 100))
        item_id = content.REWARDS.get(enc_key)
        if ratio < content.REWARD_PCT or not item_id:
            if ratio >= 0.6:
                return [("Fortæller", f"Du ramte {pct} % i første forsøg. "
                                      f"Fra 85 % giver det en ting i tasken.")]
            return []
        first, unlocks = self.bag.add(item_id)
        item = items_mod.ITEMS[item_id]
        self.show_toast(f"{pct} % rigtige – du fik {item['name']}!")
        out = [("Fortæller", f"{pct} % rigtige i første forsøg.\n"
                             f"{item['name']} er lagt i din taske.")]
        if unlocks:
            label = breakgames.LABELS[unlocks]
            turn = self.bag.plays[unlocks]
            if first:
                out.append(("Fortæller", f"{label} er låst op! Du kan spille det "
                                         f"fra tasken (tryk I).\nDu har {turn} ture."))
            else:
                out.append(("Fortæller", f"Du har nu {turn} ture til {label}."))
        return out

    # --- pausespil ----------------------------------------------------

    def start_breakgame(self, kind):
        if not self.bag.spend(kind):
            self.show_toast("Du har ingen ture tilbage")
            return
        self.breakgame = breakgames.GAMES[kind](self)
        self.state = "breakgame"
        self.audio.select()

    def finish_breakgame(self):
        summary = self.breakgame.summary
        self.breakgame = None
        self.state = "play"
        if summary:
            self.show_toast(summary)

    def _to_ending(self):
        self.state = "ending"
        self.audio.fanfare()

    def teacher_verdict(self):
        ratio = self.total_first_try / max(1, self.total_questions)
        if ratio >= 0.8:
            return ("Det der var ikke held. Du regnede det meste rigtigt i første "
                    "forsøg – og du forklarede, hvordan du tænkte. Sådan der.")
        if ratio >= 0.5:
            return ("Du er et helt andet sted end i går. Du gik i gang med det samme, "
                    "og du fandt fejlene, da du kiggede efter. Bliv ved med det.")
        return ("Det vigtigste er ikke, hvor mange du ramte. Det er, at du blev "
                "ved – også da det var svært. Det er præcis sådan, man lærer det her.")

    # --- interaktion --------------------------------------------------

    def interact(self):
        tx, ty = self.player.facing_tile()
        px, py = self.player.tile()
        for npc in world.npcs_for(self.map.key):
            if (npc["x"], npc["y"]) in ((tx, ty), (px, py)):
                self._talk_to(npc)
                return
        for key in ((tx, ty), (px, py)):
            sign = world.SIGNS.get((self.map.key, key[0], key[1]))
            if sign:
                self._use_sign(sign)
                return

    def _talk_to(self, npc):
        self.audio.select()

        if npc.get("sidequest"):
            if npc["id"] in self.done_quests:
                self.dialogue.start(self.lines_for(npc, "after"))
            elif self.chapter < npc.get("needs", 0):
                self.dialogue.start(self.lines_for(npc, "before"))
            else:
                key, name, after = npc["encounter"], npc["name"], npc["after"]
                app, qid = npc["app"], npc["id"]
                self.dialogue.start(
                    npc["intro"],
                    on_done=lambda: self.trigger_battle(key, name, after, app, qid))
            return

        ch = npc.get("chapter")
        if ch is None:
            if npc.get("lines"):
                self.dialogue.start(self.lines_for(npc, "lines"))
            else:
                self.dialogue.start(npc["after"] if self.chapter > 1 else npc["before"])
            return
        if self.chapter < ch:
            self.dialogue.start(self.lines_for(npc, "before"))
        elif self.chapter == ch:
            key, name, after = npc["encounter"], npc["name"], npc["after"]
            app = npc["app"]
            self.dialogue.start(
                npc["intro"],
                on_done=lambda: self.trigger_battle(key, name, after, app))
        else:
            self.dialogue.start(self.lines_for(npc, "after"))

    def _use_sign(self, sign):
        self.audio.select()
        if "text" in sign:
            speaker, body = sign["text"]
            self.dialogue.start([(speaker, body)])
            return
        ch = sign["chapter"]
        if self.chapter < ch:
            self.dialogue.start(sign["before"])
        elif self.chapter == ch:
            key, after, name = sign["encounter"], sign["after"], sign["name"]
            self.dialogue.start(
                sign["intro"],
                on_done=lambda: self.trigger_battle(key, name, after, None))
        else:
            self.dialogue.start(sign["after"])

    def check_portal(self, came_from):
        tx, ty = self.player.tile()
        p = world.PORTALS.get((self.map.key, tx, ty))
        if not p:
            return
        need = p.get("needs")
        if need is not None and self.chapter < need:
            self.show_toast(p.get("locked", "Du skal noget andet først."))
            self.player.place_tile(*came_from)
            return
        self.audio.select()
        self.goto(p["to"], p["tx"], p["ty"], p["dir"])

    # --- loop ---------------------------------------------------------

    async def run(self):
        while self.running:
            dt = min(0.05, self.clock.tick(FPS) / 1000)
            self.t += dt
            self.handle_events()
            self.update(dt)
            self.draw()
            # Giver browseren lov til at tegne billedet. På en pc koster
            # den her ingenting.
            await asyncio.sleep(0)
        pygame.quit()

    def handle_events(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                self.running = False
                return

            # Androids tilbage-knap opfører sig som Esc
            if e.type == pygame.KEYDOWN and e.key == getattr(pygame, "K_AC_BACK", -1):
                e = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_ESCAPE)

            if e.type == pygame.VIDEORESIZE:
                self.display = pygame.display.set_mode((e.w, e.h), pygame.RESIZABLE)
                continue

            if e.type in (pygame.FINGERDOWN, pygame.FINGERUP, pygame.FINGERMOTION):
                self.touch.note_finger()
                dw, dh = self.display.get_size()
                pos = self.to_logical((e.x * dw, e.y * dh))
                ident = getattr(e, "finger_id", 0)
                if e.type == pygame.FINGERDOWN:
                    if not self.touch.press(pos, self, ident):
                        self.tap(pos)
                elif e.type == pygame.FINGERUP:
                    self.touch.release(ident)
                continue

            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                # En finger giver ofte BÅDE en finger- og en musehændelse.
                # Er fingeren allerede talt med ovenfor, skal musekopien væk,
                # ellers bladrer bogen to sider og tallet skrives to gange.
                if getattr(e, "touch", False) or self.touch.recent_finger():
                    continue
                pos = self.to_logical(e.pos)
                # en rigtig mus på en pc rører ikke knapperne – klikket går
                # videre til opgaven, så man kan klikke på svarene
                finger = self.touch.device
                if not self.touch.press(pos, self, "mouse", finger=finger):
                    self.tap(pos)
                continue

            if e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                # slip altid: at slippe noget, der ikke holdes, gør ingenting,
                # mens en glemt musetast ville låse styrekrydset fast
                self.touch.release("mouse")
                continue

            if self.book.open:
                self.book.handle_event(e, self.audio)
                continue

            if e.type == pygame.KEYDOWN and e.key == pygame.K_m:
                muted = self.audio.toggle_mute()
                self.music.refresh_mute()
                self.show_toast("Lyd slået fra" if muted else "Lyd slået til")
                continue

            if self.state == "help":
                if e.type == pygame.KEYDOWN:
                    self.state = "pause"
                    self.audio.back()
                continue

            if e.type == pygame.KEYDOWN and e.key == pygame.K_j and \
                    self.state in ("play", "story", "battle", "cutscene"):
                page = self.battle.book_page() if self.state == "battle" else None
                self.book.toggle(page)
                # slå bogen op midt i et skridt, og foden skal ikke hænge fast
                self.touch.clear_dirs()
                self.audio.select()
                continue

            if e.type == pygame.KEYDOWN and e.key == pygame.K_i and \
                    self.state in ("play", "bag"):
                self.state = "bag" if self.state == "play" else "play"
                self.bag.cursor = 0
                self.audio.select()
                continue

            if self.state == "bag":
                self.bag_event(e)
                continue

            if self.state == "breakgame":
                self.breakgame.handle_event(e)
                if self.breakgame.done:
                    self.finish_breakgame()
                continue

            if self.state == "cutscene":
                if e.type == pygame.KEYDOWN and e.key in (
                        pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE, pygame.K_e):
                    self.dialogue.advance()
                continue

            if self.state == "title":
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        self.running = False
                    elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        self.audio.select()
                        self.state = "creator"
            elif self.state == "creator":
                self.creator_event(e)
            elif self.state in ("story", "play"):
                self.play_event(e)
            elif self.state == "battle":
                self.battle.handle_event(e)
                if self.battle.done:
                    self.finish_battle()
            elif self.state == "pause":
                self.pause_event(e)
            elif self.state == "ending":
                if e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_RETURN):
                    self.running = False

    def play_event(self, e):
        if e.type != pygame.KEYDOWN:
            return
        if e.key == pygame.K_ESCAPE:
            self.state = "pause"
            self.pause_index = 0
            self.audio.back()
        elif e.key in (pygame.K_e, pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            if self.dialogue.active:
                self.dialogue.advance()
            elif self.state == "play":
                self.interact()

    PAUSE_ITEMS = ["Fortsæt", "Sådan spiller du", "Slå op i Regnebogen",
                   "Musik til/fra", "Lyd til/fra", "Afslut spillet"]

    def pause_event(self, e):
        if e.type != pygame.KEYDOWN:
            return
        items = len(self.PAUSE_ITEMS)
        if e.key in (pygame.K_UP, pygame.K_LEFT):
            self.pause_index = (self.pause_index - 1) % items
            self.audio.move()
        elif e.key in (pygame.K_DOWN, pygame.K_RIGHT):
            self.pause_index = (self.pause_index + 1) % items
            self.audio.move()
        elif e.key == pygame.K_ESCAPE:
            self.state = "play"
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_e, pygame.K_SPACE):
            i = self.pause_index
            if i == 0:
                self.state = "play"
                self.audio.select()
            elif i == 1:
                self.state = "help"
                self.audio.select()
            elif i == 2:
                self.state = "play"
                self.book.toggle()
                self.audio.select()
            elif i == 3:
                on = self.music.toggle()
                self.show_toast("Musik slået til" if on else "Musik slået fra")
            elif i == 4:
                muted = self.audio.toggle_mute()
                self.music.refresh_mute()
                self.show_toast("Lyd slået fra" if muted else "Lyd slået til")
            else:
                self.running = False

    # --- tasken -------------------------------------------------------

    def bag_event(self, e):
        if e.type != pygame.KEYDOWN:
            return
        owned = self.bag.owned
        if e.key == pygame.K_ESCAPE:
            self.state = "play"
            self.audio.back()
        elif owned and e.key in (pygame.K_LEFT, pygame.K_UP):
            self.bag.cursor = (self.bag.cursor - 1) % len(owned)
            self.audio.move()
        elif owned and e.key in (pygame.K_RIGHT, pygame.K_DOWN):
            self.bag.cursor = (self.bag.cursor + 1) % len(owned)
            self.audio.move()
        elif owned and e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            item_id = owned[self.bag.cursor]
            unlocks = items_mod.ITEMS[item_id].get("unlocks")
            if not unlocks:
                self.audio.back()
            elif self.bag.has_game(unlocks):
                self.start_breakgame(unlocks)
            else:
                self.show_toast("Ingen ture tilbage – klar et opgavesæt med 85 %")
                self.audio.wrong()

    def draw_bag(self):
        veil = pygame.Surface((WINDOW_W, WINDOW_H), pygame.SRCALPHA)
        veil.fill((18, 16, 26, 200))
        self.screen.blit(veil, (0, 0))
        box = pygame.Rect(60, 50, WINDOW_W - 120, WINDOW_H - 100)
        ui.panel(self.screen, box)
        ui.text(self.screen, "Tasken", (box.centerx, box.y + 20), size=32,
                bold=True, center=True)

        owned = self.bag.owned
        if not owned:
            ui.text(self.screen, "Tasken er tom endnu.", (box.centerx, box.y + 130),
                    size=23, color=ui.MUTED, center=True)
            ui.text(self.screen, "Klar et opgavesæt med mindst 85 % rigtige i første",
                    (box.centerx, box.y + 176), size=19, color=ui.MUTED, center=True)
            ui.text(self.screen, "forsøg, så får du noget med herind.",
                    (box.centerx, box.y + 204), size=19, color=ui.MUTED, center=True)
        else:
            grid = pygame.Rect(box.x + 30, box.y + 66, 400, 250)
            self._bag_hits = []
            for i, item_id in enumerate(owned):
                cell = pygame.Rect(grid.x + (i % 4) * 96, grid.y + (i // 4) * 96, 84, 84)
                self._bag_hits.append((i, cell))
                sel = i == self.bag.cursor
                pygame.draw.rect(self.screen, (250, 240, 218) if sel else (244, 240, 232),
                                 cell, border_radius=12)
                pygame.draw.rect(self.screen, ui.ACCENT if sel else ui.PAPER_EDGE,
                                 cell, 3 if sel else 2, border_radius=12)
                icon = items_mod.icon(item_id)
                self.screen.blit(pygame.transform.scale(icon, (52, 52)),
                                 (cell.centerx - 26, cell.centery - 26))
                n = self.bag.counts[item_id]
                if n > 1:
                    ui.text(self.screen, f"x{n}", (cell.right - 20, cell.bottom - 22),
                            size=15, color=ui.MUTED, bold=True, center=True)

            item_id = owned[self.bag.cursor]
            item = items_mod.ITEMS[item_id]
            panel = pygame.Rect(box.x + 450, box.y + 66, box.w - 490, 250)
            pygame.draw.rect(self.screen, (248, 245, 238), panel, border_radius=12)
            pygame.draw.rect(self.screen, ui.PAPER_EDGE, panel, 2, border_radius=12)
            ui.text(self.screen, item["name"], (panel.x + 20, panel.y + 16),
                    size=24, bold=True)
            ui.text_block(self.screen, item["desc"], (panel.x + 20, panel.y + 54),
                          size=18, color=ui.MUTED, max_width=panel.w - 40, line_gap=4)

            unlocks = item.get("unlocks")
            if unlocks:
                left = self.bag.plays[unlocks]
                label = breakgames.LABELS[unlocks]
                col = ui.GOOD if left else ui.BAD
                ui.text(self.screen, f"{label}: {left} ture tilbage",
                        (panel.x + 20, panel.bottom - 66), size=20, bold=True, color=col)
                msg = ("ENTER for at spille" if left
                       else "Klar et opgavesæt med 85 % for at få flere ture")
                ui.text(self.screen, msg, (panel.x + 20, panel.bottom - 36),
                        size=17, color=ui.MUTED)

        y = box.bottom - 96
        pygame.draw.line(self.screen, ui.PAPER_EDGE, (box.x + 30, y), (box.right - 30, y), 1)
        ui.text(self.screen, "Pausespil får du ture til ved at regne godt – "
                             "de kan ikke spilles i det uendelige.",
                (box.centerx, y + 14), size=17, color=ui.MUTED, center=True)
        ui.keyrow(self.screen, (box.centerx - 150, y + 44),
                  [("left", ""), ("right", "vælg"), ("ENTER", "brug"), ("I", "luk")],
                  size=15)

    # --- karakterskabelse ---------------------------------------------

    CREATOR_ROWS = ["Køn", "Navn", "Alder", "Hudfarve", "Hår", "Hårfarve", "Trøje", "Start"]

    def creator_event(self, e):
        if e.type == pygame.TEXTINPUT and self.CREATOR_ROWS[self.creator_row] == "Navn":
            if len(self.name) < 12 and (e.text.isalpha() or e.text == " "):
                self.name += e.text
            return
        if e.type != pygame.KEYDOWN:
            return
        row = self.CREATOR_ROWS[self.creator_row]
        if e.key == pygame.K_ESCAPE:
            self.state = "title"
            self.audio.back()
        elif e.key == pygame.K_BACKSPACE and row == "Navn":
            self.name = self.name[:-1]
        elif e.key in (pygame.K_UP, pygame.K_DOWN):
            step = -1 if e.key == pygame.K_UP else 1
            self.creator_row = (self.creator_row + step) % len(self.CREATOR_ROWS)
            self.audio.move()
        elif e.key in (pygame.K_LEFT, pygame.K_RIGHT):
            self.creator_change(row, -1 if e.key == pygame.K_LEFT else 1)
            self.audio.move()
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if row == "Start":
                if not self.name.strip():
                    self.show_toast("Skriv lige dit navn først")
                    self.creator_row = 1
                    return
                self.name = self.name.strip()
                self.audio.select()
                self.start_game()
            else:
                self.creator_row = (self.creator_row + 1) % len(self.CREATOR_ROWS)
                self.audio.move()

    def creator_change(self, row, step):
        a = self.appearance
        if row == "Køn":
            self.gender = "dreng" if self.gender == "pige" else "pige"
            if self.gender == "dreng":
                a["hair_style"] = "kort"
                a["shirt"] = art.CLOTH_COLORS[0]
            else:
                a["hair_style"] = "lang"
                a["shirt"] = art.CLOTH_COLORS[6]
        elif row == "Alder":
            self.age = max(7, min(12, self.age + step))
        elif row == "Hudfarve":
            i = art.SKIN_TONES.index(tuple(a["skin"]))
            a["skin"] = art.SKIN_TONES[(i + step) % len(art.SKIN_TONES)]
        elif row == "Hår":
            styles = ["kort", "lang", "kroeller", "kasket"]
            i = styles.index(a["hair_style"])
            a["hair_style"] = styles[(i + step) % len(styles)]
        elif row == "Hårfarve":
            i = art.HAIR_COLORS.index(tuple(a["hair"]))
            a["hair"] = art.HAIR_COLORS[(i + step) % len(art.HAIR_COLORS)]
        elif row == "Trøje":
            i = art.CLOTH_COLORS.index(tuple(a["shirt"]))
            a["shirt"] = art.CLOTH_COLORS[(i + step) % len(art.CLOTH_COLORS)]

    # --- opdatering ---------------------------------------------------

    def _sync_text_input(self):
        """Telefontastaturet må kun være fremme, når navnet skal skrives."""
        if not ANDROID:
            return
        want = (self.state == "creator"
                and self.CREATOR_ROWS[self.creator_row] == "Navn")
        if want != self._text_input_on:
            (pygame.key.start_text_input if want else pygame.key.stop_text_input)()
            self._text_input_on = want

    def update(self, dt):
        self._sync_text_input()
        # tælles altid – også mens bogen er slået op, så knapperne falmer væk
        self.touch.update(dt)
        if self.toast_t > 0:
            self.toast_t -= dt
        if self.state in ("title", "creator"):
            self.music.play("title")
        elif self.state == "cutscene":
            self.music.play("cutscene")
        elif self.state == "battle":
            self.music.play("kamp")
        elif self.state == "breakgame":
            self.music.play("skolegaard")
        elif self.state == "ending":
            self.music.play("slut")
        elif self.map:
            self.music.for_map(self.map.key)
        self.music.update()
        self.book.update(dt)
        if self.book.open:
            return
        self.dialogue.update(dt)
        if self.state == "battle":
            self.battle.update(dt)
            return

        if self.state == "breakgame":
            self.breakgame.update(dt)
            if self.breakgame.done:
                self.finish_breakgame()
            return

        if self.state == "play" and not self.dialogue.active:
            keys = pygame.key.get_pressed()
            tdx, tdy = self.touch.direction()
            dx = (keys[pygame.K_RIGHT] or keys[pygame.K_d]) - (keys[pygame.K_LEFT] or keys[pygame.K_a]) + tdx
            dy = (keys[pygame.K_DOWN] or keys[pygame.K_s]) - (keys[pygame.K_UP] or keys[pygame.K_w]) + tdy
            dx = max(-1, min(1, dx))
            dy = max(-1, min(1, dy))
            before = self.player.tile()
            self.player.update(dt, dx, dy, self.map)
            if self.player.tile() != before:
                self.check_portal(before)
        elif self.state in ("story", "pause"):
            self.player.update(dt, 0, 0, self.map)

        if self.map:
            tx = self.player.x + CHAR_W / 2 - VIEW_W / 2
            ty = self.player.y + CHAR_H / 2 - VIEW_H / 2
            self.cam[0] += (self._clampx(tx) - self.cam[0]) * min(1.0, dt * 8)
            self.cam[1] += (self._clampy(ty) - self.cam[1]) * min(1.0, dt * 8)

    # --- tegning ------------------------------------------------------

    def draw(self):
        if self.state == "title":
            self.draw_title()
        elif self.state == "creator":
            self.draw_creator()
        elif self.state == "ending":
            self.draw_ending()
        elif self.state == "help":
            self.draw_world()
            self.draw_help()
        elif self.state == "cutscene":
            self.draw_cutscene()
        elif self.state == "breakgame":
            self.breakgame.draw(self.screen)
            self.draw_breakgame_hud()
        elif self.state == "bag":
            self.draw_world()
            self.draw_bag()
        else:
            self.draw_world()
            if self.state == "battle":
                self.battle.draw(self.screen)
            else:
                self.dialogue.draw(self.screen)
                self.draw_hud()
            if self.state == "pause":
                self.draw_pause()
        self.book.draw(self.screen)
        self.draw_toast()
        self.touch.draw(self.screen, self)
        self.present()

    def present(self):
        """Skalerer billedet ud i vinduet med sorte kanter, hvis det er nødvendigt."""
        dw, dh = self.display.get_size()
        scale = min(dw / WINDOW_W, dh / WINDOW_H)
        w, h = max(1, int(WINDOW_W * scale)), max(1, int(WINDOW_H * scale))
        ox, oy = (dw - w) // 2, (dh - h) // 2
        self._view = (ox, oy, scale)
        if (w, h) == (WINDOW_W, WINDOW_H):
            self.display.blit(self.screen, (ox, oy))
        else:
            self.display.fill((0, 0, 0))
            self.display.blit(pygame.transform.smoothscale(self.screen, (w, h)), (ox, oy))
        pygame.display.flip()

    def to_logical(self, pos):
        ox, oy, scale = self._view
        return int((pos[0] - ox) / scale), int((pos[1] - oy) / scale)

    def draw_world(self):
        cam = (int(self.cam[0]), int(self.cam[1]))
        self.map.draw_flat(self.world_surf, cam)

        actors = list(self.map.tall_prop_draws())
        for npc in world.npcs_for(self.map.key):
            img = art.character_sprite(npc["app"], npc.get("dir", "down"), 0)
            px = npc["x"] * TILE + (TILE - CHAR_W) // 2
            py = npc["y"] * TILE + TILE - CHAR_H
            actors.append((py + CHAR_H, img, px, py))
            if npc.get("chapter") == self.chapter:
                b = art.bubble("!")
                bob = int(2 * math.sin(self.t * 4))
                actors.append((py + CHAR_H + 1, b, px + 6, py - 16 + bob))

        p = self.player
        actors.append((p.y + CHAR_H, p.sprite(), int(p.x), int(p.y)))
        actors.sort(key=lambda a: a[0])
        for _, img, x, y in actors:
            self.world_surf.blit(img, (x - cam[0], y - cam[1]))

        if self.map.tint:
            overlay = pygame.Surface((VIEW_W, VIEW_H), pygame.SRCALPHA)
            overlay.fill(self.map.tint)
            self.world_surf.blit(overlay, (0, 0))

        pygame.transform.scale(self.world_surf, (WINDOW_W, WINDOW_H), self.screen)

    def draw_cutscene(self):
        cam = (int(self.cam[0]), int(self.cam[1]))
        self.map.draw_flat(self.world_surf, cam)
        actors = list(self.map.tall_prop_draws())

        for (tx, ty, app) in self.cutscene_actors:
            img = art.character_sprite(app, "up", 0)
            px = tx * TILE + (TILE - CHAR_W) // 2
            py = ty * TILE + TILE - CHAR_H
            actors.append((py + CHAR_H, img, px, py))

        teacher = [n for n in world.NPCS if n["id"] == "poulsen"][0]
        timg = art.character_sprite(teacher["app"], "down", 0)
        actors.append((4 * TILE + CHAR_H, timg, 4 * TILE + 2, 3 * TILE - 8))

        p = self.player
        actors.append((p.y + CHAR_H, p.sprite(), int(p.x), int(p.y)))
        actors.sort(key=lambda a: a[0])
        for _, img, x, y in actors:
            self.world_surf.blit(img, (x - cam[0], y - cam[1]))

        overlay = pygame.Surface((VIEW_W, VIEW_H), pygame.SRCALPHA)
        overlay.fill((40, 40, 80, 60))
        self.world_surf.blit(overlay, (0, 0))
        pygame.transform.scale(self.world_surf, (WINDOW_W, WINDOW_H), self.screen)

        # filmkanter
        for r in (pygame.Rect(0, 0, WINDOW_W, 54),
                  pygame.Rect(0, WINDOW_H - 54, WINDOW_W, 54)):
            pygame.draw.rect(self.screen, (10, 10, 16), r)
        ui.text(self.screen, "I GÅR", (WINDOW_W // 2, 18), size=20,
                color=(180, 176, 190), bold=True, center=True)
        self.dialogue.draw(self.screen)

    def draw_breakgame_hud(self):
        bar = pygame.Rect(WINDOW_W - 330, 16, 314, 58)
        ui.panel(self.screen, bar, radius=12)
        ui.text(self.screen, self.breakgame.title, (bar.x + 16, bar.y + 8),
                size=19, bold=True)
        ui.keyrow(self.screen, (bar.x + 16, bar.y + 32), self.breakgame.keys, size=13)
        ui.text(self.screen, "ESC: stop", (WINDOW_W // 2, WINDOW_H - 28), size=16,
                color=(250, 248, 242), center=True, shadow=True)

    def draw_hud(self):
        box = pygame.Rect(16, 14, 430, 74)
        ui.panel(self.screen, box, radius=12)
        ui.text(self.screen, self.name or "Dig", (box.x + 16, box.y + 10), size=20, bold=True)
        ui.text(self.screen, OBJECTIVES[min(self.chapter, len(OBJECTIVES) - 1)],
                (box.x + 16, box.y + 38), size=17, color=ui.MUTED)

        pips = pygame.Rect(WINDOW_W - 330, 14, 314, 74)
        ui.panel(self.screen, pips, radius=12)
        ui.text(self.screen, "Regnekraft", (pips.x + 16, pips.y + 8), size=15,
                color=ui.MUTED, bold=True)
        ui.bar(self.screen, (pips.x + 16, pips.y + 30, 180, 22),
               self.confidence / 100.0, label=f"{self.confidence}%")
        for i, lvl in enumerate(content.BLOOM_ORDER):
            cx = pips.x + 212 + (i % 3) * 32
            cy = pips.y + 22 + (i // 3) * 26
            col = ui.GOOD if i < self.chapter else (216, 210, 200)
            pygame.draw.circle(self.screen, col, (cx, cy), 8)
            pygame.draw.circle(self.screen, ui.PAPER_EDGE, (cx, cy), 8, 2)

        # på touch ville minikortet ligge under OK-knappen, så det rykker op
        mm = (pygame.Rect(WINDOW_W - 214, 96, 198, 176) if ui.TOUCH
              else pygame.Rect(WINDOW_W - 214, WINDOW_H - 210, 198, 180))
        minimap.draw(self.screen, mm, self.map, self.player, self.chapter,
                     self.t, title=self.map.name)

        if not self.dialogue.active:
            self.draw_interact_prompt()
            if not ui.TOUCH:
                ui.keyrow(self.screen, (24, WINDOW_H - 52),
                          [("up", ""), ("down", ""), ("left", ""), ("right", "gå"),
                           ("ENTER", "snak"), ("J", "Regnebogen"), ("I", "tasken")],
                          size=15, color=(252, 250, 244), shadow=True)

    def tap(self, pos):
        """Et tryk et sted på skærmen, som ikke ramte en touch-knap."""
        if self.book.open:
            self.book.handle_event(
                pygame.event.Event(pygame.KEYDOWN,
                                   key=pygame.K_LEFT if pos[0] < WINDOW_W // 2
                                   else pygame.K_RIGHT), self.audio)
            return
        if self.state == "battle" and self.battle:
            if self.battle.phase == "feedback":
                self.battle.handle_event(
                    pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN))
            elif hasattr(self.battle.mg, "tap"):
                self.battle.mg.tap(pos, self.audio)
                if self.battle.mg.result is not None:
                    ok, msg = self.battle.mg.result
                    self.battle.mg.result = None
                    self.battle._judge(ok, msg)
            return
        if self.state == "bag":
            for i, rect in getattr(self, "_bag_hits", []):
                if rect.collidepoint(pos):
                    if self.bag.cursor == i:
                        self.bag_event(pygame.event.Event(pygame.KEYDOWN,
                                                          key=pygame.K_RETURN))
                    else:
                        self.bag.cursor = i
                        self.audio.move()
                    return
            return
        if self.state == "pause":
            for i, rect in getattr(self, "_pause_hits", []):
                if rect.collidepoint(pos):
                    self.pause_index = i
                    self.pause_event(pygame.event.Event(pygame.KEYDOWN,
                                                        key=pygame.K_RETURN))
                    return
            return
        if self.state == "creator":
            for i, rect in getattr(self, "_creator_hits", []):
                if rect.collidepoint(pos):
                    if self.creator_row == i:
                        self.creator_event(pygame.event.Event(pygame.KEYDOWN,
                                                              key=pygame.K_RETURN))
                    else:
                        self.creator_row = i
                        self.audio.move()
                    return
            return
        # alle andre skærme: et tryk svarer til ENTER
        if self.state in ("title", "story", "cutscene", "help", "ending", "play"):
            pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN))

    def interact_target(self):
        """Den NPC eller ting, spilleren står over for lige nu."""
        tx, ty = self.player.facing_tile()
        px, py = self.player.tile()
        for npc in world.npcs_for(self.map.key):
            if (npc["x"], npc["y"]) in ((tx, ty), (px, py)):
                return npc["x"], npc["y"]
        for key in ((tx, ty), (px, py)):
            if (self.map.key, key[0], key[1]) in world.SIGNS:
                return key
        return None

    def draw_interact_prompt(self):
        target = self.interact_target()
        if not target:
            return
        tx, ty = target
        sx = (tx * TILE + TILE // 2 - int(self.cam[0])) * WORLD_SCALE
        sy = (ty * TILE - 16 - int(self.cam[1])) * WORLD_SCALE
        if not (0 < sx < WINDOW_W and 0 < sy < WINDOW_H):
            return
        bob = int(3 * math.sin(self.t * 5))
        ui.keycap(self.screen, (sx, sy + bob), "ENTER", size=15, center=True)

    def draw_toast(self):
        if self.toast_t <= 0 or not self.toast:
            return
        f = ui.font(18, True)
        w = f.size(self.toast)[0] + 40
        # i tasken ville en boks i toppen dække varens navn
        y = WINDOW_H - 118 if self.state == "bag" else 104
        r = pygame.Rect((WINDOW_W - w) // 2, y, w, 42)
        alpha = min(1.0, self.toast_t / 0.6)
        s = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
        pygame.draw.rect(s, (38, 34, 44, int(228 * alpha)), (0, 0, r.w, r.h), border_radius=12)
        pygame.draw.rect(s, (206, 138, 46, int(255 * alpha)), (0, 0, r.w, r.h), 2, border_radius=12)
        img = f.render(self.toast, True, (250, 246, 238))
        img.set_alpha(int(255 * alpha))
        s.blit(img, (20, 11))
        self.screen.blit(s, r.topleft)

    def draw_title(self):
        self.screen.fill((38, 44, 62))
        for i in range(0, WINDOW_H, 4):
            sh = 44 + int(26 * (i / WINDOW_H))
            pygame.draw.line(self.screen, (sh, sh + 6, sh + 20), (0, i), (WINDOW_W, i))
        ui.text(self.screen, "REGNEHELTEN", (WINDOW_W // 2, 168), size=78,
                color=ui.ACCENT, bold=True, center=True, shadow=True)
        ui.text(self.screen, "En helt almindelig skoledag – fuld af tal",
                (WINDOW_W // 2, 248), size=23, color=(220, 216, 206), center=True)

        demo = art.character_sprite(self.appearance, "down", int(self.t * 6) % 4)
        self.screen.blit(pygame.transform.scale(demo, (CHAR_W * 4, CHAR_H * 4)),
                         (WINDOW_W // 2 - CHAR_W * 2, 300))

        if int(self.t * 2) % 2 == 0:
            ui.text(self.screen, "Tryk ENTER for at begynde", (WINDOW_W // 2, 516),
                    size=26, color=(250, 246, 238), bold=True, center=True, shadow=True)
        ui.keyrow(self.screen, (WINDOW_W // 2 + 250, 572),
                  [("up", ""), ("down", ""), ("left", ""), ("right", "gå"),
                   ("ENTER", "snak"), ("J", "Regnebogen")],
                  size=15, right_align=True, color=(214, 218, 230), shadow=True)

    def draw_creator(self):
        self.screen.fill((44, 50, 68))
        ui.text(self.screen, "Hvem er du?", (WINDOW_W // 2, 44), size=40,
                color=(250, 244, 230), bold=True, center=True, shadow=True)

        prev = pygame.Rect(70, 110, 300, 440)
        ui.panel(self.screen, prev)
        sprite = art.character_sprite(self.appearance, "down", int(self.t * 6) % 4)
        self.screen.blit(pygame.transform.scale(sprite, (CHAR_W * 6, CHAR_H * 6)),
                         (prev.centerx - CHAR_W * 3, prev.y + 60))
        ui.text(self.screen, self.name or "...", (prev.centerx, prev.bottom - 50),
                size=26, bold=True, center=True)

        panel = pygame.Rect(410, 110, WINDOW_W - 480, 440)
        ui.panel(self.screen, panel)
        naming = self.CREATOR_ROWS[self.creator_row] == "Navn"
        values = {
            "Køn": self.gender.capitalize(),
            "Navn": self.name + ("|" if naming and (pygame.time.get_ticks() // 400) % 2 == 0 else ""),
            "Alder": f"{self.age} år",
            "Hudfarve": "", "Hårfarve": "", "Trøje": "",
            "Hår": self.appearance["hair_style"].replace("kroeller", "krøller").capitalize(),
            "Start": "Begynd dagen",
        }
        self._creator_hits = []
        for i, row in enumerate(self.CREATOR_ROWS):
            y = panel.y + 22 + i * 52
            sel = i == self.creator_row
            r = pygame.Rect(panel.x + 16, y, panel.w - 32, 44)
            self._creator_hits.append((i, r))
            if sel:
                pygame.draw.rect(self.screen, (246, 234, 208), r, border_radius=10)
                pygame.draw.rect(self.screen, ui.ACCENT, r, 3, border_radius=10)
            ui.text(self.screen, row, (r.x + 16, r.y + 10), size=21, bold=sel,
                    color=ui.INK if sel else (110, 104, 98))
            if row in ("Hudfarve", "Hårfarve", "Trøje"):
                key = {"Hudfarve": "skin", "Hårfarve": "hair", "Trøje": "shirt"}[row]
                sw = pygame.Rect(r.right - 120, r.y + 10, 46, 24)
                pygame.draw.rect(self.screen, self.appearance[key], sw, border_radius=6)
                pygame.draw.rect(self.screen, ui.INK, sw, 2, border_radius=6)
                ui.arrow(self.screen, (r.right - 138, r.y + 22), "left")
                ui.arrow(self.screen, (r.right - 56, r.y + 22), "right")
            else:
                val = values[row]
                ui.text(self.screen, val,
                        (r.right - 20 - ui.font(21, sel).size(val)[0], r.y + 10),
                        size=21, bold=sel, color=ui.INK if sel else (110, 104, 98))

        if ui.TOUCH:
            hint = ("Tryk på et bogstav – Færdig, når navnet står der" if naming
                    else "Tryk på en linje – pilene skifter værdien, Navn åbner tastaturet")
        else:
            hint = "Piletaster op/ned: vælg     venstre/højre: skift     ENTER: videre"
        # mens bogstaverne er fremme, fylder de ned til 588 – så ligger
        # linjen lige under dem i stedet for at blive dækket
        hy = 610 if (ui.TOUCH and naming) else 588
        ui.text(self.screen, hint, (WINDOW_W // 2, hy), size=18,
                color=(206, 202, 194), center=True)

    def draw_pause(self):
        veil = pygame.Surface((WINDOW_W, WINDOW_H), pygame.SRCALPHA)
        veil.fill((16, 16, 24, 170))
        self.screen.blit(veil, (0, 0))
        box = pygame.Rect(WINDOW_W // 2 - 200, 130, 400, 372)
        ui.panel(self.screen, box)
        ui.text(self.screen, "Pause", (box.centerx, box.y + 22), size=32, bold=True, center=True)
        self._pause_hits = []
        for i, it in enumerate(self.PAUSE_ITEMS):
            y = box.y + 78 + i * 46
            sel = i == self.pause_index
            r = pygame.Rect(box.x + 30, y, box.w - 60, 40)
            self._pause_hits.append((i, r))
            if sel:
                pygame.draw.rect(self.screen, (246, 234, 208), r, border_radius=10)
                pygame.draw.rect(self.screen, ui.ACCENT, r, 3, border_radius=10)
            ui.text(self.screen, it, (r.centerx, r.y + 11), size=21, bold=sel,
                    center=True, color=ui.INK if sel else (110, 104, 98))

    HELP_ROWS = [
        (["up", "down", "left", "right"], "Gå rundt",
         "Du kan også bruge W A S D"),
        (["ENTER"], "Snak og svar",
         "Gå hen til en med ! over hovedet og tryk ENTER"),
        (["MELLEMRUM"], "Vælg en brik",
         "Bruges i de opgaver, hvor du samler noget"),
        (["J"], "Regnebogen",
         "Slår op på den side, opgaven handler om"),
        (["M"], "Lyd til og fra", ""),
        (["ESC"], "Menuen", "Her kan du også slå musikken fra"),
    ]

    def draw_help(self):
        veil = pygame.Surface((WINDOW_W, WINDOW_H), pygame.SRCALPHA)
        veil.fill((16, 16, 24, 200))
        self.screen.blit(veil, (0, 0))
        box = pygame.Rect(80, 50, WINDOW_W - 160, WINDOW_H - 100)
        ui.panel(self.screen, box)
        ui.text(self.screen, "Sådan spiller du", (box.centerx, box.y + 22),
                size=34, bold=True, center=True)

        y = box.y + 84
        for keys, title, note in self.HELP_ROWS:
            x = box.x + 36
            for k in keys:
                r = ui.keycap(self.screen, (x, y), k, size=15)
                x = r.right + 8
            ui.text(self.screen, title, (box.x + 250, y + 2), size=21, bold=True)
            if note:
                ui.text(self.screen, note, (box.x + 250, y + 26), size=16, color=ui.MUTED)
            y += 68

        ui.text(self.screen, "Tryk på en vilkårlig tast for at gå tilbage",
                (box.centerx, box.bottom - 40), size=18, color=ui.MUTED, center=True)

    def draw_ending(self):
        self.screen.fill((40, 48, 66))
        ui.text(self.screen, "Det, du kan nu", (WINDOW_W // 2, 34), size=36,
                color=(250, 244, 230), bold=True, center=True, shadow=True)

        box = pygame.Rect(40, 82, WINDOW_W - 80, 500)
        ui.panel(self.screen, box)

        quote = self.teacher_verdict()
        ui.name_tag(self.screen, "Hr. Poulsen", (box.x + 24, box.y - 14))
        y = box.y + 26
        for line in ui.wrap(quote, 20, box.w - 80):
            ui.text(self.screen, line, (box.x + 34, y), size=20)
            y += 28

        y += 10
        pygame.draw.line(self.screen, ui.PAPER_EDGE, (box.x + 34, y), (box.right - 34, y), 1)
        y += 16

        for bloom, sentence in content.CAN_STATEMENTS:
            stars = self.mastery.get(bloom, 0)
            col = ui.INK if stars else (168, 162, 154)
            pygame.draw.circle(self.screen, ui.GOOD if stars else (214, 208, 198),
                               (box.x + 44, y + 11), 9)
            if stars:
                pygame.draw.lines(self.screen, (255, 255, 255), False,
                                  [(box.x + 39, y + 11), (box.x + 43, y + 15),
                                   (box.x + 50, y + 6)], 3)
            ui.text(self.screen, sentence, (box.x + 66, y), size=20, color=col)
            for s in range(3):
                sx = box.right - 120 + s * 30
                on = s < stars
                pygame.draw.circle(self.screen, ui.ACCENT if on else (224, 218, 208),
                                   (sx, y + 11), 9)
                if on:
                    pygame.draw.circle(self.screen, (255, 244, 214), (sx - 2, y + 8), 3)
            y += 38

        y += 6
        ui.bar(self.screen, (box.x + 34, y, box.w - 68, 26), self.confidence / 100.0,
               label=f"Regnekraft: {self.confidence}%")

        ui.text(self.screen, "Tryk ENTER for at slutte", (box.centerx, box.bottom - 34),
                size=19, bold=True, center=True, color=ui.MUTED)


async def main():
    await Game().run()


if __name__ == "__main__":
    asyncio.run(main())
