"""
Touch-styring til telefon og tablet.

Knapperne hører til en skærm, man rører ved. På en pc bliver de aldrig
tændt: et museklik går direkte videre til spillet, så man stadig kan
klikke på svarene i en opgave, mens billedet ser ud præcis som før.

På en telefon eller tablet dukker knapperne op, så snart skærmen bliver
rørt, og falmer stille væk igen, når fingeren har ligget stille et par
sekunder. Felterne virker hele tiden – også mens knapperne er usynlige –
så et tryk aldrig går tabt. Et tryk bliver lavet om til den samme
tastebegivenhed, som tastaturet ville sende, så resten af spillet ikke
behøver vide, om der blev trykket eller tastet.
"""

import math

import pygame

import ui

# Styrepinden. Et styrekryds kræver, at fingeren rammer den rigtige arm, og
# det er svært, når man ikke kan mærke knapperne – derfor er det en pind,
# man trækker i: fingeren kan lande hvor som helst på den, og retningen er
# den vej, man trækker.
STICK_HOME = (126, 498)
STICK_R = 82        # den store ring, pinden bor i
KNOB_R = 38         # selve pinden
GRAB = STICK_R + 26  # så langt fra midten må fingeren lande og stadig gribe
DEAD = 0.24         # under det her rører figuren sig ikke
# Et træk i menuerne gentager sig selv, hvis fingeren bliver liggende –
# ellers skal man løfte og trykke for hver linje, man vil ned ad.
REPEAT_FIRST = 0.5
REPEAT_NEXT = 0.2

FACE = (250, 248, 242, 210)
FACE_DOWN = (240, 214, 160, 235)
EDGE = (60, 56, 52, 200)
LABEL = (46, 42, 38)

DIGITS = ["7", "8", "9", "4", "5", "6", "1", "2", "3", "0"]

# Bogstavtastatur til navnet. Uden det kan man ikke skrive sit navn på en
# telefon – der er ikke noget rigtigt tastatur at skrive med.
ALPHABET = ["ABCDEFGHIJ", "KLMNOPQRST", "UVWXYZÆØÅ"]
KEY_W, KEY_H, KEY_GAP = 84, 56, 8
ABC_TOP = 318
ABC_PANEL = pygame.Rect(44, 300, 936, 288)
ABC_SPACE = pygame.Rect(134, 510, 320, 60)
ABC_ERASE = pygame.Rect(472, 510, 180, 60)
ABC_DONE = pygame.Rect(670, 510, 220, 60)
NUM_PANEL = pygame.Rect(317, 300, 394, 232)

# Knapperne bliver stående så mange sekunder efter sidste berøring og
# falmer så væk over et lille øjeblik.
HOLD = 3.0
FADE = 0.6

# Regnebogen fylder 119..905 i bredden, så dens knapper ligger i kanterne.
BOOK_CLOSE = pygame.Rect(920, 52, 88, 62)
BOOK_PREV = pygame.Rect(16, 292, 88, 88)
BOOK_NEXT = pygame.Rect(920, 292, 88, 88)


# hvordan svaret nedenfor blev fundet – skrives i browserens konsol, så det
# kan slås efter, hvis knapperne en dag opfører sig mærkeligt
HOW = "ikke spurgt"


def report(msg):
    """Skriv en linje i browserens konsol.

    Spillets almindelige print havner i pygbags egen terminal, og den
    findes ikke på en telefon. Konsollen kan læses med en fjernfejlsøger,
    og det er dér, man skal kigge, hvis knapperne driller.
    """
    try:
        import platform as _platform
        _platform.window.console.log(msg)
    except Exception:
        print(msg)


def browser_is_touch():
    """True hvis browseren sidder på en telefon eller tablet.

    Kun pygbag har `platform.window`. På en pc findes den ikke, og så er
    svaret nej – det er dét, der holder knapperne væk fra en pc-skærm.
    """
    global HOW
    try:
        import platform as _platform
        win = getattr(_platform, "window", None)
        if win is None:
            HOW = "ingen browser"
            return False
        try:
            svar = bool(win.eval(
                "(window.matchMedia && window.matchMedia('(pointer: coarse)')"
                ".matches) || (navigator.maxTouchPoints || 0) > 0"))
            HOW = "pointer/maxTouchPoints"
            return svar
        except Exception:
            pass
        try:
            svar = bool(win.navigator.maxTouchPoints)
            HOW = "maxTouchPoints"
            return svar
        except Exception:
            HOW = "browseren svarede ikke"
            return False
    except Exception:
        HOW = "fejl"
        return False


def _round_rect(surface, rect, color, radius=12, border=EDGE, width=3):
    s = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
    pygame.draw.rect(s, color, (0, 0, rect.w, rect.h), border_radius=radius)
    pygame.draw.rect(s, border, (0, 0, rect.w, rect.h), width, border_radius=radius)
    surface.blit(s, rect.topleft)


def _circle(surface, center, r, color, border=EDGE, width=3):
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, color, (r, r), r)
    pygame.draw.circle(s, border, (r, r), r, width)
    surface.blit(s, (center[0] - r, center[1] - r))


def _book_open(game):
    book = getattr(game, "book", None)
    return bool(book and book.open)


def naming(game):
    """Står markøren på Navn-linjen i 'Hvem er du?'"""
    if game.state != "creator" or _book_open(game):
        return False
    try:
        return game.CREATOR_ROWS[game.creator_row] == "Navn"
    except (AttributeError, IndexError):
        return False


class TouchControls:
    def __init__(self, device=False):
        # device: skærmen er en telefon eller tablet. På en pc bliver den
        # aldrig sat, og så tænder et museklik ikke knapperne.
        self.device = device
        self.enabled = False
        self.saw_finger = False     # har vi fået rigtige finger-hændelser?
        self.finger_ms = -10000     # hvornår sidst (browserens ur)
        self.idle = 0.0             # sekunder siden sidste berøring
        self.stick_id = None        # hvilken finger der holder styrepinden
        self.stick = (0.0, 0.0)     # hvor langt og hvilken vej, den er trukket
        self.stick_menu = False     # i en menu sender pinden piletaster
        self.stick_dir = None       # den vej, menuen sidst fik besked om
        self.repeat_in = 0.0        # sekunder til næste gentagelse
        self.held = {}              # finger/muse-id -> hvad der holdes nede
        self.held_ms = {}           # og hvornår det blev trykket ned (spillets ur)
        self.tid = 0.0              # sekunder, spillet har kørt
        self._layer = None          # bruges kun, mens knapperne falmer

    # --- opsætning ----------------------------------------------------

    def activate(self):
        if not self.enabled:
            self.enabled = True
            ui.TOUCH = True

    def wake(self):
        """Tænd knapperne igen – kaldes ved enhver berøring."""
        self.idle = 0.0

    def note_finger(self):
        """En rigtig finger-hændelse er lige kommet ind."""
        self.saw_finger = True
        self.finger_ms = pygame.time.get_ticks()
        self.idle = 0.0

    def recent_finger(self, ms=250):
        """En finger giver ofte både en finger- og en musehændelse.

        Er fingeren lige blevet talt med, er musehændelsen en kopi, og
        den skal smides væk – ellers bladrer bogen to sider på ét tryk.
        """
        return self.saw_finger and \
            pygame.time.get_ticks() - self.finger_ms < ms

    def update(self, dt):
        # En finger, der aldrig bliver sluppet, ville holde knapperne tændt
        # for altid – og så ligger styrepinden oven på replikkerne resten
        # af spillet. Det sker, hvis browseren taber et FINGERUP, og det gør
        # den. Ingen holder en knap nede i otte sekunder, så efter dét
        # slipper vi den selv. Styrepinden får længere snor: man kan sagtens
        # gå tværs over kortet uden at løfte fingeren.
        self.tid += dt
        if self.held:
            for ident, (slags, vaerdi) in list(self.held.items()):
                graense = 20.0 if slags == "stick" else 8.0
                if self.tid - self.held_ms.get(ident, 0.0) > graense:
                    self.held.pop(ident, None)
                    self.held_ms.pop(ident, None)
                    if slags == "stick":
                        self._slip_stick()

        # Bliver pinden holdt ude til siden i en menu, gentager retningen
        # sig selv – som når man holder en piletast nede.
        if self.stick_menu and self.stick_dir and self.stick_id is not None:
            self.repeat_in -= dt
            if self.repeat_in <= 0:
                _post_key(_KEYS[self.stick_dir])
                self.repeat_in = REPEAT_NEXT

        if self.held:
            self.idle = 0.0
        else:
            self.idle += dt

    def visibility(self):
        """0 = usynlig, 1 = helt tændt."""
        if not self.enabled:
            return 0.0
        if self.held or self.idle <= HOLD:
            return 1.0
        if self.idle >= HOLD + FADE:
            return 0.0
        return 1.0 - (self.idle - HOLD) / FADE

    def clear_dirs(self):
        self._slip_stick()

    def wants_space(self, game):
        if game.state != "battle" or not game.battle:
            return False
        return any(k[0] == "MELLEMRUM" for k in game.battle.mg.key_items)

    def numpad_kind(self, game):
        if _book_open(game):
            return None
        if game.state != "battle" or not game.battle:
            return None
        if game.battle.phase != "play":
            return None
        return game.battle.mg.spec["kind"] if \
            game.battle.mg.spec["kind"] in ("write", "sequence") else None

    # --- hvad findes hvor ---------------------------------------------

    def letterpad(self, game):
        """[(tegn, rect)] – bogstavtastatur, mens navnet bliver skrevet.

        Det her tastatur er en nødudgang, og derfor er det ikke bundet til,
        om touch-knapperne er tændt: har spilleren ikke et rigtigt tastatur,
        er navnefeltet den eneste vej videre, og så SKAL der være bogstaver.
        Vi viser dem med det samme på en berøringsskærm, og efter et par
        sekunder alle andre steder, hvis der stadig ikke er rørt en tast.
        """
        if not naming(game):
            return []
        if not (self.enabled or self.device or getattr(game, "navn_redning", False)):
            return []
        out = []
        for row, bogstaver in enumerate(ALPHABET):
            bredde = len(bogstaver) * KEY_W + (len(bogstaver) - 1) * KEY_GAP
            x0 = (1024 - bredde) // 2
            y = ABC_TOP + row * (KEY_H + KEY_GAP)
            for col, ch in enumerate(bogstaver):
                out.append((ch, pygame.Rect(x0 + col * (KEY_W + KEY_GAP), y,
                                            KEY_W, KEY_H)))
        out.append((" ", ABC_SPACE))
        out.append(("slet", ABC_ERASE))
        out.append(("faerdig", ABC_DONE))
        return out

    def buttons(self, game):
        """[(tast, mærkat, rect)] for den aktuelle skærm."""
        # Mens navnet bliver skrevet, fylder bogstaverne skærmen. Styrekrydset
        # og OK-knappen ligger oven i tasterne, så de venter til bagefter.
        if naming(game):
            return []
        # Mens Regnebogen er slået op, er den det eneste, man kan styre.
        # Ellers ville styrekrydset og taltastaturet ligge oven på siderne
        # og stjæle de tryk, der skulle have bladret.
        if _book_open(game):
            return [("ESC", "Luk", BOOK_CLOSE),
                    ("left", "Forrige", BOOK_PREV),
                    ("right", "Næste", BOOK_NEXT)]

        st = game.state
        out = []
        if st in ("play", "story", "cutscene", "battle", "breakgame",
                  "bag", "pause", "help", "ending", "creator", "title"):
            out.append(("ENTER", "OK", pygame.Rect(884, 478, 116, 116)))
        # de små knapper ligger øverst til venstre, så de ikke kommer i vejen
        # for minikortet, styrekrydset eller den store OK-knap
        x = 16
        if st == "battle":
            # i en opgave fylder spørgsmålet toppen – bogen ligger i højre kant
            out.append(("J", "Bog", pygame.Rect(950, 214, 58, 56)))
        elif st in ("play", "story", "cutscene"):
            out.append(("J", "Bog", pygame.Rect(x, 98, 62, 56)))
            x += 70
        if st == "play":
            out.append(("I", "Taske", pygame.Rect(x, 98, 62, 56)))
            x += 70
        if st in ("play", "bag", "breakgame", "help", "pause"):
            out.append(("ESC", "Tilbage" if st != "play" else "Menu",
                        pygame.Rect(x, 98, 74, 56)))
        if self.wants_space(game):
            out.append(("MELLEMRUM", "Vælg", pygame.Rect(748, 506, 108, 76)))
        return out

    def numpad(self, game):
        """[(tegn, rect)] – taltastatur til de opgaver, hvor man skriver."""
        if not self.numpad_kind(game):
            return []
        out = []
        bw, bh, gap = 76, 44, 8
        x0, y0 = 333, 316
        for i, d in enumerate(DIGITS):
            col, row = i % 3, i // 3
            out.append((d, pygame.Rect(x0 + col * (bw + gap), y0 + row * (bh + gap), bw, bh)))
        side = x0 + 3 * (bw + gap)
        out.append(("slet", pygame.Rect(side, y0, 106, bh)))
        out.append(("ok", pygame.Rect(side, y0 + (bh + gap), 106, bh * 3 + gap * 2)))
        return out

    def show_stick(self, game):
        if _book_open(game) or naming(game):
            return False
        return game.state in ("play", "battle", "breakgame", "bag", "pause",
                              "creator", "ending")

    def _greb(self, pos):
        """Landede fingeren på styrepinden?"""
        dx = pos[0] - STICK_HOME[0]
        dy = pos[1] - STICK_HOME[1]
        return dx * dx + dy * dy <= GRAB * GRAB

    def _traek(self, pos):
        """Hvor langt og hvilken vej pinden er trukket – længst 1,0."""
        dx = (pos[0] - STICK_HOME[0]) / float(STICK_R)
        dy = (pos[1] - STICK_HOME[1]) / float(STICK_R)
        laengde = math.hypot(dx, dy)
        if laengde > 1.0:
            dx, dy = dx / laengde, dy / laengde
            laengde = 1.0
        if laengde < DEAD:
            return 0.0, 0.0
        return dx, dy

    def _stick_navn(self):
        """Den vej, pinden peger mest – eller None, hvis den står i midten."""
        dx, dy = self.stick
        if not dx and not dy:
            return None
        if abs(dx) >= abs(dy):
            return "right" if dx > 0 else "left"
        return "down" if dy > 0 else "up"

    def _saet_stick(self, pos):
        self.stick = self._traek(pos)
        navn = self._stick_navn()
        if self.stick_menu and navn != self.stick_dir:
            # i en menu er pinden en piletast: ét tryk, når retningen skifter
            if navn:
                _post_key(_KEYS[navn])
                self.repeat_in = REPEAT_FIRST
            self.stick_dir = navn

    def _slip_stick(self):
        self.stick_id = None
        self.stick = (0.0, 0.0)
        self.stick_dir = None
        self.stick_menu = False

    # --- input --------------------------------------------------------

    def press(self, pos, game, ident=0, finger=True):
        """Returnerer True hvis berøringen blev brugt af en knap.

        `finger` er False, når det er en rigtig mus. Så tænder trykket
        ikke knapperne, og på en pc, hvor de aldrig har været tændt,
        rører musen dem heller ikke – klikket går videre til spillet.
        """
        # Bogstaverne bliver spurgt FØR alt andet: de skal virke, også når
        # touch-knapperne er slukkede, og også for en mus. Ellers kan en
        # spiller uden tastatur ikke komme forbi navnefeltet.
        abc = self.letterpad(game)
        for ch, rect in abc:
            if rect.collidepoint(pos):
                self.wake()
                self.held[ident] = ("abc", ch)
                self.held_ms[ident] = self.tid
                if ch == "slet":
                    _post_key(pygame.K_BACKSPACE)
                elif ch == "faerdig":
                    _post_key(pygame.K_RETURN)
                else:
                    # stort forbogstav, små bogstaver derefter – så bliver
                    # det "Ida Marie" og ikke "IDA MARIE"
                    navn = getattr(game, "name", "")
                    if navn and not navn.endswith(" "):
                        ch = ch.lower()
                    pygame.event.post(pygame.event.Event(pygame.TEXTINPUT, text=ch))
                return True
        if abc and ABC_PANEL.collidepoint(pos):
            # faldt mellem to taster – så skal det ikke ramme linjen bagved
            return True

        if finger:
            self.activate()
        elif not self.enabled:
            return False
        self.wake()

        if self.show_stick(game) and self._greb(pos):
            self.stick_id = ident
            # ude i verdenen går figuren efter, hvor langt pinden er trukket.
            # I en menu er der ingen halv fart – dér er pinden en piletast.
            self.stick_menu = game.state != "play"
            self.stick_dir = None
            self.held[ident] = ("stick", None)
            self.held_ms[ident] = self.tid
            self._saet_stick(pos)
            return True

        for key, _label, rect in self.buttons(game):
            if rect.collidepoint(pos):
                self.held[ident] = ("key", key)
                self.held_ms[ident] = self.tid
                _post_key(_KEYS[key])
                return True

        pad = self.numpad(game)
        for ch, rect in pad:
            if rect.collidepoint(pos):
                self.held[ident] = ("pad", ch)
                self.held_ms[ident] = self.tid
                if ch == "slet":
                    _post_key(pygame.K_BACKSPACE)
                elif ch == "ok":
                    _post_key(pygame.K_RETURN)
                else:
                    pygame.event.post(pygame.event.Event(pygame.TEXTINPUT, text=ch))
                return True
        if pad and NUM_PANEL.collidepoint(pos):
            # samme som ved bogstaverne: mellemrummet mellem to taster
            # hører til tastaturet, ikke til opgaven bagved
            return True
        return False

    def move(self, pos, ident=0):
        """Fingeren gled hen over skærmen – styrepinden følger med.

        Uden det her ville pinden stå fast, dér hvor fingeren landede, og
        så var den bare et styrekryds med en anden tegning.
        """
        if self.stick_id is None or ident != self.stick_id:
            return False
        self.wake()
        self.held_ms[ident] = self.tid
        self._saet_stick(pos)
        return True

    def release(self, ident=0):
        self.wake()
        self.held_ms.pop(ident, None)
        what = self.held.pop(ident, None)
        if (what and what[0] == "stick") or ident == self.stick_id:
            self._slip_stick()

    def direction(self):
        """Hvor langt og hvilken vej der bliver trukket.

        Tallene er ikke kun -1, 0 og 1: trækker man pinden halvt ud, går
        figuren halv fart, og så er det til at ramme en dør.
        """
        return self.stick

    def _is_down(self, kind, value):
        return any(h == (kind, value) for h in self.held.values())

    # --- tegning ------------------------------------------------------

    def draw(self, surface, game):
        # bogstaverne falmer aldrig: man skal kunne se dem for at lede
        # efter det næste bogstav i sit navn
        level = 1.0 if self.letterpad(game) else self.visibility()
        if level <= 0.01:
            return
        if level > 0.99:
            self._paint(surface, game)
            return
        # mens knapperne falmer, tegnes de på et lag, der kan gøres svagere
        if self._layer is None or self._layer.get_size() != surface.get_size():
            self._layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        self._layer.fill((0, 0, 0, 0))
        self._paint(self._layer, game)
        self._layer.set_alpha(int(255 * level))
        surface.blit(self._layer, (0, 0))

    def _paint(self, surface, game):
        if self.show_stick(game):
            cx, cy = STICK_HOME
            _circle(surface, (cx, cy), STICK_R, (250, 248, 242, 90), EDGE, 2)
            # fire små pile inde i ringen, så det kan ses, hvad den er til
            for navn, (ax, ay) in (("up", (0, -1)), ("down", (0, 1)),
                                   ("left", (-1, 0)), ("right", (1, 0))):
                ui.arrow(surface, (cx + ax * (STICK_R - 15),
                                   cy + ay * (STICK_R - 15)), navn,
                         (96, 90, 82), 9)
            dx, dy = self.stick
            knop = (int(cx + dx * (STICK_R - KNOB_R)),
                    int(cy + dy * (STICK_R - KNOB_R)))
            holdt = self.stick_id is not None
            _circle(surface, knop, KNOB_R, FACE_DOWN if holdt else FACE)

        book = _book_open(game)
        for key, label, rect in self.buttons(game):
            down = self._is_down("key", key)
            if rect.w == rect.h and rect.w > 100:
                _circle(surface, rect.center, rect.w // 2,
                        FACE_DOWN if down else FACE)
                ui.text(surface, label, rect.center, size=26, color=LABEL,
                        bold=True, center=True)
            else:
                _round_rect(surface, rect, FACE_DOWN if down else FACE, 12)
                if book and key in ("left", "right"):
                    # en pil over ordet gør knappen til at se på afstand
                    ui.arrow(surface, (rect.centerx, rect.centery - 14),
                             key, LABEL, 13)
                    ui.text(surface, label, (rect.centerx, rect.centery + 18),
                            size=15, color=LABEL, bold=True, center=True)
                else:
                    ui.text(surface, label, rect.center, size=15, color=LABEL,
                            bold=True, center=True)

        abc = self.letterpad(game)
        if abc:
            # næsten uigennemsigtig: ellers skinner linjerne bagved igennem
            # mellem tasterne, og så bliver det svært at se bogstaverne
            _round_rect(surface, ABC_PANEL, (30, 28, 38, 242), 18,
                        (250, 248, 242, 70), 2)
            for ch, rect in abc:
                down = self._is_down("abc", ch)
                _round_rect(surface, rect, FACE_DOWN if down else FACE, 10)
                label = {" ": "Mellemrum", "slet": "Slet",
                         "faerdig": "Færdig"}.get(ch, ch)
                ui.text(surface, label, rect.center,
                        size=26 if len(label) == 1 else 20,
                        color=LABEL, bold=True, center=True)

        pad = self.numpad(game)
        if pad:
            _round_rect(surface, NUM_PANEL, (36, 34, 44, 150), 16, (0, 0, 0, 0), 0)
            for ch, rect in pad:
                down = self._is_down("pad", ch)
                _round_rect(surface, rect, FACE_DOWN if down else FACE, 10)
                label = {"slet": "Slet", "ok": "OK"}.get(ch, ch)
                ui.text(surface, label, rect.center,
                        size=26 if ch not in ("slet", "ok") else 20,
                        color=LABEL, bold=True, center=True)


_KEYS = {
    "ENTER": pygame.K_RETURN, "MELLEMRUM": pygame.K_SPACE,
    "J": pygame.K_j, "I": pygame.K_i, "ESC": pygame.K_ESCAPE,
    "up": pygame.K_UP, "down": pygame.K_DOWN,
    "left": pygame.K_LEFT, "right": pygame.K_RIGHT,
}


def _post_key(key):
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=key))
