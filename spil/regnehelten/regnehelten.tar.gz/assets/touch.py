"""
Touch-styring til telefon og tablet.

Knapperne tegnes kun, når spillet har set en berøring (eller et museklik),
så det ser ud som før på en computer. Et tryk bliver lavet om til den
samme tastebegivenhed, som tastaturet ville sende, så resten af spillet
ikke behøver vide, om der blev trykket eller tastet.
"""

import pygame

import ui

DPAD_CENTER = (118, 512)
DPAD_ARM = 52

FACE = (250, 248, 242, 210)
FACE_DOWN = (240, 214, 160, 235)
EDGE = (60, 56, 52, 200)
LABEL = (46, 42, 38)

DIGITS = ["7", "8", "9", "4", "5", "6", "1", "2", "3", "0"]


def _round_rect(surface, rect, color, radius=12, border=EDGE, width=3):
    s = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
    pygame.draw.rect(s, color, (0, 0, rect.w, rect.h), border_radius=radius)
    pygame.draw.rect(s, border, (0, 0, rect.w, rect.h), width, border_radius=radius)
    surface.blit(s, rect.topleft)


def _circle(surface, center, r, color, border=EDGE, width=3):
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, color, (r, r), r)
    pygame.draw.circle(s, border, (r, r), r, width)
    surface.blit(s, (center[0] - r, center[1] - r))


class TouchControls:
    def __init__(self):
        self.enabled = False
        self.dirs = {"up": False, "down": False, "left": False, "right": False}
        self.held = {}              # finger/muse-id -> hvad der holdes nede
        self._hits = []             # [(rect_eller_None, slags, data)]

    # --- opsætning ----------------------------------------------------

    def activate(self):
        if not self.enabled:
            self.enabled = True
            ui.TOUCH = True

    def clear_dirs(self):
        for k in self.dirs:
            self.dirs[k] = False

    def wants_space(self, game):
        if game.state != "battle" or not game.battle:
            return False
        return any(k[0] == "MELLEMRUM" for k in game.battle.mg.key_items)

    def numpad_kind(self, game):
        if game.state != "battle" or not game.battle:
            return None
        if game.battle.phase != "play":
            return None
        return game.battle.mg.spec["kind"] if \
            game.battle.mg.spec["kind"] in ("write", "sequence") else None

    # --- hvad findes hvor ---------------------------------------------

    def buttons(self, game):
        """[(tast, mærkat, rect)] for den aktuelle skærm."""
        st = game.state
        out = []
        if st in ("play", "story", "cutscene", "battle", "breakgame",
                  "bag", "pause", "help", "ending", "creator", "title"):
            out.append(("ENTER", "OK", pygame.Rect(884, 478, 116, 116)))
        # de små knapper ligger øverst til venstre, så de ikke kommer i vejen
        # for minikortet, styrekrydset eller den store OK-knap
        x = 16
        if st == "battle":
            # i en opgave fylder spørgsmålet toppen – bogen ligger i højre kant
            out.append(("J", "Bog", pygame.Rect(950, 214, 58, 56)))
        elif st in ("play", "story", "cutscene"):
            out.append(("J", "Bog", pygame.Rect(x, 98, 62, 56)))
            x += 70
        if st == "play":
            out.append(("I", "Taske", pygame.Rect(x, 98, 62, 56)))
            x += 70
        if st in ("play", "bag", "breakgame", "help", "pause"):
            out.append(("ESC", "Tilbage" if st != "play" else "Menu",
                        pygame.Rect(x, 98, 74, 56)))
        if self.wants_space(game):
            out.append(("MELLEMRUM", "Vælg", pygame.Rect(748, 506, 108, 76)))
        return out

    def numpad(self, game):
        """[(tegn, rect)] – taltastatur til de opgaver, hvor man skriver."""
        if not self.numpad_kind(game):
            return []
        out = []
        bw, bh, gap = 76, 44, 8
        x0, y0 = 333, 316
        for i, d in enumerate(DIGITS):
            col, row = i % 3, i // 3
            out.append((d, pygame.Rect(x0 + col * (bw + gap), y0 + row * (bh + gap), bw, bh)))
        side = x0 + 3 * (bw + gap)
        out.append(("slet", pygame.Rect(side, y0, 106, bh)))
        out.append(("ok", pygame.Rect(side, y0 + (bh + gap), 106, bh * 3 + gap * 2)))
        return out

    def dpad_zones(self):
        cx, cy = DPAD_CENTER
        a = DPAD_ARM
        return {
            "up": pygame.Rect(cx - a // 2, cy - a - a // 2, a, a),
            "down": pygame.Rect(cx - a // 2, cy + a // 2, a, a),
            "left": pygame.Rect(cx - a - a // 2, cy - a // 2, a, a),
            "right": pygame.Rect(cx + a // 2, cy - a // 2, a, a),
        }

    def show_dpad(self, game):
        return game.state in ("play", "battle", "breakgame", "bag", "pause",
                              "creator", "ending")

    # --- input --------------------------------------------------------

    def press(self, pos, game, ident=0):
        """Returnerer True hvis berøringen blev brugt af en knap."""
        self.activate()

        if self.show_dpad(game):
            for name, rect in self.dpad_zones().items():
                if rect.collidepoint(pos):
                    self.dirs[name] = True
                    self.held[ident] = ("dir", name)
                    if game.state != "play":
                        _post_key(_KEYS[name])
                    return True

        for key, _label, rect in self.buttons(game):
            if rect.collidepoint(pos):
                self.held[ident] = ("key", key)
                _post_key(_KEYS[key])
                return True

        for ch, rect in self.numpad(game):
            if rect.collidepoint(pos):
                self.held[ident] = ("pad", ch)
                if ch == "slet":
                    _post_key(pygame.K_BACKSPACE)
                elif ch == "ok":
                    _post_key(pygame.K_RETURN)
                else:
                    pygame.event.post(pygame.event.Event(pygame.TEXTINPUT, text=ch))
                return True
        return False

    def release(self, ident=0):
        what = self.held.pop(ident, None)
        if what and what[0] == "dir":
            self.dirs[what[1]] = False

    def direction(self):
        dx = (1 if self.dirs["right"] else 0) - (1 if self.dirs["left"] else 0)
        dy = (1 if self.dirs["down"] else 0) - (1 if self.dirs["up"] else 0)
        return dx, dy

    def _is_down(self, kind, value):
        return any(h == (kind, value) for h in self.held.values())

    # --- tegning ------------------------------------------------------

    def draw(self, surface, game):
        if not self.enabled:
            return

        if self.show_dpad(game):
            cx, cy = DPAD_CENTER
            _circle(surface, (cx, cy), DPAD_ARM + 26, (250, 248, 242, 90), EDGE, 2)
            for name, rect in self.dpad_zones().items():
                down = self.dirs[name]
                _round_rect(surface, rect, FACE_DOWN if down else FACE, 10)
                ui.arrow(surface, rect.center, name, LABEL, 11)

        for key, label, rect in self.buttons(game):
            down = self._is_down("key", key)
            if rect.w == rect.h and rect.w > 100:
                _circle(surface, rect.center, rect.w // 2,
                        FACE_DOWN if down else FACE)
                ui.text(surface, label, rect.center, size=26, color=LABEL,
                        bold=True, center=True)
            else:
                _round_rect(surface, rect, FACE_DOWN if down else FACE, 12)
                ui.text(surface, label, rect.center, size=15, color=LABEL,
                        bold=True, center=True)

        pad = self.numpad(game)
        if pad:
            back = pygame.Rect(317, 300, 394, 232)
            _round_rect(surface, back, (36, 34, 44, 150), 16, (0, 0, 0, 0), 0)
            for ch, rect in pad:
                down = self._is_down("pad", ch)
                _round_rect(surface, rect, FACE_DOWN if down else FACE, 10)
                label = {"slet": "Slet", "ok": "OK"}.get(ch, ch)
                ui.text(surface, label, rect.center,
                        size=26 if ch not in ("slet", "ok") else 20,
                        color=LABEL, bold=True, center=True)


_KEYS = {
    "ENTER": pygame.K_RETURN, "MELLEMRUM": pygame.K_SPACE,
    "J": pygame.K_j, "I": pygame.K_i, "ESC": pygame.K_ESCAPE,
    "up": pygame.K_UP, "down": pygame.K_DOWN,
    "left": pygame.K_LEFT, "right": pygame.K_RIGHT,
}


def _post_key(key):
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=key))
