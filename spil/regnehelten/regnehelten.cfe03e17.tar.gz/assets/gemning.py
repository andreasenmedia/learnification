"""
Autogem – og fortsæt på en anden skærm.

Spillet gemmer af sig selv ved de rolige øjeblikke: når en runde er ovre,
når man går gennem en dør, efter et pausespil, og jævnligt, mens man går
rundt. Aldrig midt i en opgave – kommer man tilbage, står man
foran den, man var i gang med, og tager runden forfra.

HVOR DET LIGGER
* I browseren (pygbag) hos learnification.dk: på serveren, på den
  spiller, der er logget ind (barnets egen kode eller den voksnes konto),
  så man kan fortsætte på en anden computer eller tablet. Der ligger også
  en kopi i browserens localStorage, så intet går tabt uden net.
  Er ingen logget ind, eller svarer serveren ikke, er det kun kopien.
* På en pc (python main.py / exe) og på Android: en fil i brugerens mappe.

Browser-delen er JavaScript (JS nedenfor), som spillet lægger ind i sin
egen side ved start. Den taler med /api/gem.php og holder styr på, hvilken
udgave der er gemt – så en glemt fane på en anden skærm ikke kan gemme
oven i nyere fremskridt. Sker det, siger spillet til og henter det nyeste.
"""

import json
import os
import sys
import time

WEB = sys.platform == "emscripten"
ANDROID = "ANDROID_ARGUMENT" in os.environ

VERSION = 1
SPIL = "regnehelten"
VENT_PAA_SERVER = 6.0      # sekunder, før vi giver op og spiller videre lokalt


JS = r"""
(function () {
  if (window.LFGem) return;
  var SPIL = '%(spil)s';
  var inde = (document.cookie.match(/(?:^|;\s*)lf_in=([^;]*)/) || [])[1] || '';
  var NOEGLE = SPIL + '-gem:' + (inde || 'gaest');
  var enhed = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  var udgave = 0, nyesteUdgave = 0, venter = null, timer = null, sender = false;
  var G = { status: 'henter', data: '', server: !!inde, konflikt: false, nyeste: '' };
  window.LFGem = G;

  function lokal() {
    try {
      var x = JSON.parse(localStorage.getItem(NOEGLE) || 'null');
      return x && typeof x.data === 'string' ? x : null;
    } catch (e) { return null; }
  }
  function skrivLokal(data, synket) {
    try { localStorage.setItem(NOEGLE, JSON.stringify({ data: data, udgave: udgave, synket: synket })); }
    catch (e) { /* privat vindue eller fyldt lager */ }
  }
  function klar(data) { G.data = data || ''; G.status = 'klar'; }

  function hent() {
    var l = lokal();
    if (!G.server) { klar(l && l.data); return; }
    fetch('/api/gem.php?handling=hent&spil=' + SPIL, { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json().then(function (d) { return { r: r, d: d }; }); })
      .then(function (x) {
        if (x.r.status === 401) { G.server = false; klar(l && l.data); return; }
        if (!x.d.ok) throw new Error(x.d.besked);
        udgave = x.d.udgave || 0;
        // Den lokale kopi vinder kun, hvis den bygger videre på netop den
        // udgave, serveren har, og aldrig nåede op – fx fordi nettet røg.
        if (l && !l.synket && l.udgave === udgave && l.data) { klar(l.data); planlaeg(l.data); return; }
        klar(x.d.data || '');
      })
      .catch(function () { klar(l && l.data); });   // intet net: spil videre lokalt
  }

  function planlaeg(data) {
    venter = data;
    skrivLokal(data, false);
    clearTimeout(timer);
    timer = setTimeout(send, 1500);
  }

  function send(keepalive) {
    if (!G.server || G.konflikt || venter === null || (sender && !keepalive)) return;
    var data = venter, fejlede = false;
    venter = null;
    sender = true;
    fetch('/api/gem.php', {
      method: 'POST', credentials: 'same-origin', keepalive: !!keepalive,
      headers: { 'Content-Type': 'application/json', 'X-LF': '1' },
      body: JSON.stringify({ handling: 'gem', spil: SPIL, data: data, udgave: udgave, enhed: enhed })
    }).then(function (r) { return r.json().then(function (d) { return { r: r, d: d }; }); })
      .then(function (x) {
        if (x.d.ok) {
          udgave = x.d.udgave;
          if (venter === null) skrivLokal(data, true);
        } else if (x.r.status === 409 && x.d.konflikt) {
          G.nyeste = x.d.data; nyesteUdgave = x.d.udgave; G.konflikt = true;
        } else if (x.r.status === 401) {
          G.server = false;                       // logget ud: kun lokalt fra nu af
        } else { fejlede = true; if (venter === null) venter = data; }
      })
      .catch(function () { fejlede = true; if (venter === null) venter = data; })
      .then(function () {
        sender = false;
        if (venter !== null && G.server && !G.konflikt) {
          clearTimeout(timer);
          timer = setTimeout(send, fejlede ? 20000 : 1500);
        }
      });
  }

  G.gem = function (data) { if (typeof data === 'string' && data) planlaeg(data); };
  G.tagNyeste = function () {
    udgave = nyesteUdgave; venter = null; G.konflikt = false;
    skrivLokal(G.nyeste, true);
    var d = G.nyeste; G.nyeste = '';
    return d;
  };

  // Når fanen lukkes eller man skifter app, skal det sidste af sted nu
  function nu() { if (venter !== null) send(true); }
  window.addEventListener('pagehide', nu);
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') nu();
  });
  hent();
})();
""" % {"spil": SPIL}


def _vindue():
    try:
        import platform as _platform
        return getattr(_platform, "window", None)
    except Exception:
        return None


def _fil():
    """Hvor det gemte spil ligger uden for browseren."""
    if ANDROID:
        mappe = os.environ.get("ANDROID_PRIVATE") or os.getcwd()
    elif os.name == "nt":
        mappe = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "Regnehelten")
    else:
        mappe = os.path.join(os.path.expanduser("~"), ".regnehelten")
    return os.path.join(mappe, "gemt-spil.json")


def _laes_json(tekst):
    try:
        d = json.loads(tekst) if tekst else None
    except ValueError:
        return None
    if isinstance(d, dict) and d.get("version") == VERSION and d.get("navn"):
        return d
    return None


class Gemning:
    """Spillets side af autogemningen. Se modulets beskrivelse."""

    def __init__(self):
        self.win = _vindue() if WEB else None
        self.klar = False
        self.data = None          # det gemte spil, når det er hentet
        self.konflikt = False     # en anden skærm har gemt noget nyere
        self._ventet = 0.0
        self._tjek = 0.0
        self._sidst = ""
        if self.win is None:
            self.data = self._fra_fil()
            self.klar = True
            return
        try:
            self.win.eval(JS)
        except Exception as e:
            self._fortael("kunne ikke starte: %r" % (e,))
            self.klar = True

    # --- hente ---------------------------------------------------------

    def _js(self, udtryk):
        try:
            v = self.win.eval(udtryk)
        except Exception:
            return ""
        return v if isinstance(v, str) else ("" if v is None else str(v))

    def update(self, dt):
        """Kaldes hvert billede. Spørger browseren et par gange i sekundet."""
        if self.win is None:
            return
        self._tjek -= dt
        if self._tjek > 0:
            return
        self._tjek = 0.4
        if not self.klar:
            self._ventet += 0.4
            status = self._js("window.LFGem ? LFGem.status : ''")
            if status == "klar":
                self.data = _laes_json(self._js("LFGem.data"))
                self.klar = True
                self._fortael("klar (%s)" % ("gemt spil fundet" if self.data else "intet gemt"))
            elif self._ventet > VENT_PAA_SERVER:
                self.klar = True
                self._fortael("gav op at vente på serveren")
        else:
            self.konflikt = self._js("window.LFGem && LFGem.konflikt ? '1' : ''") == "1"

    def tag_nyeste(self):
        """Hent det, der er gemt på den anden skærm (efter en konflikt)."""
        self.konflikt = False
        self.data = _laes_json(self._js("LFGem.tagNyeste()"))
        return self.data

    # --- gemme ---------------------------------------------------------

    def gem(self, data):
        data = dict(data, version=VERSION, gemt=int(time.time()))
        # Er intet ændret siden sidst (ud over klokken og den spilletid, der
        # tikker), sparer vi turen – ellers ville en stillestående spiller
        # blive gemt hvert tyvende sekund
        ens = dict(data, gemt=0)
        ens["resultat"] = {k: v for k, v in (ens.get("resultat") or {}).items()
                           if k != "sekunder"}
        sammenlign = json.dumps(ens, sort_keys=True)
        if sammenlign == self._sidst:
            return
        self._sidst = sammenlign
        self.data = data
        tekst = json.dumps(data, ensure_ascii=True, separators=(",", ":"))
        if self.win is None:
            self._til_fil(tekst)
            return
        if self.konflikt:
            return                       # først skal spilleren tage stilling
        try:
            self.win.eval("window.LFGem && LFGem.gem(" + json.dumps(tekst) + ")")
        except Exception as e:
            self._fortael("kunne ikke gemme: %r" % (e,))

    # --- på en pc -------------------------------------------------------

    def _fra_fil(self):
        try:
            with open(_fil(), encoding="utf-8") as f:
                return _laes_json(f.read())
        except OSError:
            return None

    def _til_fil(self, tekst):
        sti = _fil()
        try:
            os.makedirs(os.path.dirname(sti), exist_ok=True)
            tmp = sti + ".ny"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(tekst)
            os.replace(tmp, sti)     # hele filen eller ingenting
        except OSError as e:
            print("Regnehelten: kunne ikke gemme:", e)

    def _fortael(self, msg):
        try:
            import touch
            touch.report("Regnehelten, gemning: " + msg)
        except Exception:
            pass
